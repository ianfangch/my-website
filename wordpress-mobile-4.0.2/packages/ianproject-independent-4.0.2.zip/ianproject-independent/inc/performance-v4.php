<?php
defined( 'ABSPATH' ) || exit;

// Local derivatives only: saved core blocks and original media stay editable.
function ianperf_hero_block( $blocks ) {
    foreach ( $blocks as $block ) {
        if ( 'core/group' === $block['blockName'] && in_array( 'ih-hero-photo', explode( ' ', $block['attrs']['className'] ?? '' ), true ) ) { return $block; }
        $found = ianperf_hero_block( $block['innerBlocks'] ?? array() );
        if ( $found ) { return $found; }
    }
    return null;
}
function ianperf_image_source( $html ) {
    $tag = new WP_HTML_Tag_Processor( $html );
    if ( ! $tag->next_tag( 'IMG' ) ) { return null; }
    $src = $tag->get_attribute( 'src' );
    if ( ! is_string( $src ) ) { return null; }
    $url = html_entity_decode( $src, ENT_QUOTES, 'UTF-8' );
    $uploads = wp_get_upload_dir();
    foreach ( array( array( $uploads['baseurl'], $uploads['basedir'] ), array( get_theme_file_uri( 'assets' ), get_theme_file_path( 'assets' ) ) ) as $root ) {
        $base = wp_parse_url( $root[0] ); $parts = wp_parse_url( $url );
        if ( ! is_array( $parts ) || ! isset( $parts['host'] ) || strtolower( $parts['host'] ) !== strtolower( $base['host'] ?? '' ) ) { continue; }
        $prefix = trailingslashit( $base['path'] ?? '' ); $path = $parts['path'] ?? '';
        if ( ! str_starts_with( $path, $prefix ) ) { continue; }
        $file = realpath( trailingslashit( $root[1] ) . rawurldecode( substr( $path, strlen( $prefix ) ) ) );
        $allowed = realpath( $root[1] );
        if ( ! $file || ! $allowed || ! str_starts_with( $file, trailingslashit( $allowed ) ) || ! is_file( $file ) ) { continue; }
        if ( ! in_array( strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ), array( 'jpg', 'jpeg', 'png', 'webp' ), true ) ) { continue; }
        $key = substr( hash( 'sha256', $file . '|' . filesize( $file ) . '|' . filemtime( $file ) . '|4.0.2' ), 0, 24 );
        return array( 'key' => $key, 'file' => $file, 'url' => $url );
    }
    return null;
}
function ianperf_prepare_hero() {
    $id = (int) get_option( 'page_on_front' );
    $post = $id ? get_post( $id ) : null;
    $block = $post ? ianperf_hero_block( parse_blocks( $post->post_content ) ) : null;
    if ( ! $block ) { return false; }
    $source = ianperf_image_source( ianproject_tokens( serialize_block( $block ) ) );
    if ( ! $source ) { return false; }
    $cache = (array) get_option( 'ianperf_hero', array() );
    if ( ( $cache['key'] ?? '' ) === $source['key'] && ianperf_derivatives( $source ) ) { return true; }
    if ( ! wp_image_editor_supports( array( 'mime_type' => 'image/webp', 'methods' => array( 'resize', 'save' ) ) ) ) { return false; }
    $size = wp_getimagesize( $source['file'] );
    if ( ! $size || $size[0] * $size[1] > 40000000 || max( $size[0], $size[1] ) > 10000 ) { return false; }
    $uploads = wp_upload_dir();
    if ( $uploads['error'] ) { return false; }
    $directory = trailingslashit( $uploads['basedir'] ) . 'ianproject-cache';
    if ( ! wp_mkdir_p( $directory ) ) { return false; }
    $files = array();
    foreach ( array( 'mobile' => array( 1280, 78 ), 'desktop' => array( 1920, 82 ) ) as $name => $settings ) {
        $editor = wp_get_image_editor( $source['file'] );
        if ( is_wp_error( $editor ) ) { return false; }
        $width = min( $size[0], $settings[0] );
        if ( $width < $size[0] ) {
            $result = $editor->resize( $width, null, false );
            if ( is_wp_error( $result ) ) { return false; }
        }
        $editor->set_quality( $settings[1] );
        $filename = 'hero-' . $source['key'] . '-' . $name . '.webp';
        $saved = $editor->save( $directory . '/' . $filename, 'image/webp' );
        if ( is_wp_error( $saved ) ) { return false; }
        $files[ $name ] = array( 'file' => 'ianproject-cache/' . $filename, 'width' => $saved['width'], 'height' => $saved['height'] );
    }
    update_option( 'ianperf_hero', array( 'key' => $source['key'], 'files' => $files ), false );
    do_action( 'litespeed_purge_all' );
    return true;
}
function ianperf_derivatives( $source ) {
    $cache = (array) get_option( 'ianperf_hero', array() );
    if ( ( $cache['key'] ?? '' ) !== $source['key'] ) { return null; }
    $uploads = wp_get_upload_dir(); $urls = array();
    foreach ( array( 'mobile', 'desktop' ) as $name ) {
        $entry = $cache['files'][ $name ] ?? array();
        $relative = $entry['file'] ?? '';
        if ( ! preg_match( '~^ianproject-cache/hero-[a-f0-9]{24}-(?:mobile|desktop)\.webp$~', $relative ) || ! is_file( trailingslashit( $uploads['basedir'] ) . $relative ) ) { return null; }
        $urls[ $name ] = trailingslashit( $uploads['baseurl'] ) . $relative;
    }
    return $urls;
}
add_action( 'admin_init', function () {
    if ( current_user_can( 'manage_options' ) && ! wp_doing_ajax() && ! get_transient( 'ianperf_checked' ) ) {
        ianperf_prepare_hero();
        set_transient( 'ianperf_checked', IANPROJECT_VERSION, 5 * MINUTE_IN_SECONDS );
    }
} );
add_action( 'save_post_page', function ( $id ) {
    if ( $id === (int) get_option( 'page_on_front' ) && ! wp_is_post_revision( $id ) && ! wp_is_post_autosave( $id ) && current_user_can( 'edit_post', $id ) ) { delete_transient( 'ianperf_checked' ); ianperf_prepare_hero(); }
} );
add_filter( 'render_block_core/group', function ( $html, $block ) {
    if ( is_admin() || ! is_front_page() || ! in_array( 'ih-hero-photo', explode( ' ', $block['attrs']['className'] ?? '' ), true ) ) { return $html; }
    $source = ianperf_image_source( $html );
    $urls = $source ? ianperf_derivatives( $source ) : null;
    if ( ! $urls ) { return $html; }
    return preg_replace_callback( '~<img\b[^>]*>~i', function ( $match ) use ( $urls ) {
        $img = new WP_HTML_Tag_Processor( $match[0] ); $img->next_tag( 'IMG' );
        $img->set_attribute( 'src', $urls['desktop'] );
        $img->set_attribute( 'fetchpriority', 'high' ); $img->set_attribute( 'loading', 'eager' );
        $img->remove_attribute( 'srcset' ); $img->remove_attribute( 'sizes' );
        return '<picture><source media="(max-width: 767px)" type="image/webp" srcset="' . esc_url( $urls['mobile'] ) . '">' . $img->get_updated_html() . '</picture>';
    }, $html, 1 );
}, 20, 2 );
add_filter( 'render_block_core/html', function ( $html ) {
    if ( is_admin() || ! is_front_page() || ! str_contains( $html, 'ih-original-cover' ) ) { return $html; }
    $tags = new WP_HTML_Tag_Processor( $html );
    while ( $tags->next_tag( 'IMG' ) ) {
        if ( ! $tags->has_class( 'ih-original-cover' ) ) { continue; }
        $tags->set_attribute( 'loading', 'lazy' );
        $tags->set_attribute( 'decoding', 'async' );
        $tags->set_attribute( 'fetchpriority', 'low' );
        $source = ianperf_image_source( '<img src="' . esc_attr( (string) $tags->get_attribute( 'src' ) ) . '">' );
        $urls = $source ? ianperf_derivatives( $source ) : null;
        if ( $urls ) {
            $cache = get_option( 'ianperf_hero' );
            $tags->set_attribute( 'src', $urls['desktop'] );
            $tags->set_attribute( 'srcset', $urls['mobile'] . ' ' . $cache['files']['mobile']['width'] . 'w, ' . $urls['desktop'] . ' ' . $cache['files']['desktop']['width'] . 'w' );
            $tags->set_attribute( 'sizes', '(max-width: 767px) 100vw, 50vw' );
        }
    }
    return $tags->get_updated_html();
}, 20 );
add_action( 'wp_head', function () {
    foreach ( array( 0, 4 ) as $font ) { echo '<link rel="preload" href="' . esc_url( get_theme_file_uri( 'assets/vendor/fonts/ian-font-' . $font . '.woff2?v=4.0.2' ) ) . '" as="font" type="font/woff2" crossorigin>' . "\n"; }
}, 1 );
