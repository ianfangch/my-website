<?php
/**
 * Plugin Name: IanProject 增强工具
 * Description: 可选的产品资料批量编辑工具。不接管网站模板，不包含旧资料迁移，也不删除商品。
 * Version: 2.0.0
 * Requires at least: 6.7
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 */
defined( 'ABSPATH' ) || exit;
function iant_fields() { return array( 'moq'=>'最小起订量（商品属性）', 'lead_time'=>'生产交期（商品属性）', 'unit'=>'计价单位（商品属性）', 'regular_price'=>'正常价格（原生价格；留空清除）' ); }
function iant_value( $field, $value ) {
    if ( ! is_scalar( $value ) ) { return new WP_Error( 'iant_value', '字段格式不正确。' ); }
    $value = trim( (string) $value );
    if ( 'unit' === $field && ! in_array( $value, array( 'unit','set','metre','square metre' ), true ) ) { return new WP_Error( 'iant_unit', '使用 unit、set、metre 或 square metre。' ); }
    if ( 'regular_price' === $field ) { if ( '' === $value ) { return ''; } if ( ! is_numeric( $value ) || (float) $value <= 0 ) { return new WP_Error( 'iant_price', '价格必须为正数；未确定请留空。' ); } return wc_format_decimal( $value ); }
    return sanitize_text_field( $value );
}
function iant_attribute_name( $field ) { return array( 'moq'=>'Minimum order', 'lead_time'=>'Production lead time', 'unit'=>'Pricing unit' )[ $field ] ?? ''; }
function iant_read( $product, $field ) { return 'regular_price' === $field ? $product->get_regular_price( 'edit' ) : $product->get_attribute( iant_attribute_name( $field ) ); }
function iant_write( $product, $field, $value ) {
    if ( 'regular_price' === $field ) { $product->set_regular_price( $value ); if ( '' === $value ) { $product->set_sale_price( '' ); $product->set_price( '' ); } }
    else {
        $attrs=$product->get_attributes();$name=iant_attribute_name($field);$key=sanitize_title($name);
        foreach($attrs as $k=>$a){if(is_object($a)&&strcasecmp($a->get_name(),$name)===0){$key=$k;break;}}
        if(''===$value){unset($attrs[$key]);}else{$a=new WC_Product_Attribute();$a->set_name($name);$a->set_options(array($value));$a->set_visible(true);$a->set_variation(false);$attrs[$key]=$a;}$product->set_attributes($attrs);
    }
    $product->save();
}
function iant_plan( $ids, $field, $value ) {
    if ( ! function_exists( 'wc_get_product' ) || ! isset( iant_fields()[ $field ] ) ) { return new WP_Error( 'iant_fields', '请启用 WooCommerce，并选择有效字段。' ); }
    $value = iant_value( $field, $value ); if ( is_wp_error( $value ) ) { return $value; }
    $plan = array( 'owner' => get_current_user_id(), 'field' => $field, 'value' => $value, 'items' => array() );
    foreach ( array_slice( array_unique( array_filter( array_map( 'absint', $ids ) ) ), 0, 100 ) as $id ) {
        $p = wc_get_product( $id ); if ( ! $p || ! current_user_can( 'edit_post', $id ) ) { return new WP_Error( 'iant_product', '没有编辑权限或商品不存在：' . $id ); }
        if ( $p->is_type( 'variable' ) && 'regular_price' === $field || $p->is_type( 'variation' ) && 'regular_price' !== $field ) { return new WP_Error( 'iant_type', '父商品的价格请按规格分别填写；MOQ、交期、单位请在父商品属性中填写。' ); }
        $old = iant_read( $p, $field ); $plan['items'][] = array( 'id' => $id, 'title' => $p->get_name(), 'old' => $old );
    }
    if ( ! $plan['items'] ) { return new WP_Error( 'iant_empty', '请填写商品 ID。' ); }
    $plan['hash'] = hash( 'sha256', wp_json_encode( $plan ) );
    return $plan;
}
function iant_apply( $plan ) {
    if ( (int) $plan['owner'] !== get_current_user_id() ) { return new WP_Error( 'iant_owner', '计划不属于当前账号。' ); }
    foreach ( $plan['items'] as $item ) { if ( ! current_user_can( 'edit_post', $item['id'] ) || iant_read( wc_get_product( $item['id'] ), $plan['field'] ) !== $item['old'] ) { return new WP_Error( 'iant_changed', '商品已变化或权限不足，请重新预览：' . $item['id'] ); } }
    foreach ( $plan['items'] as $item ) { $p = wc_get_product( $item['id'] ); iant_write( $p, $plan['field'], $plan['value'] ); }
    return count( $plan['items'] );
}
add_action( 'admin_menu', function () { add_management_page( 'IanProject 增强工具', 'IanProject 增强工具', 'manage_woocommerce', 'ianproject-tools', 'iant_admin' ); } );
function iant_admin() {
    if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
    $key = 'iant_plan_' . get_current_user_id(); $plan = get_option( $key );
    if ( isset( $_POST['iant_preview'] ) ) { check_admin_referer( 'iant_edit' ); $plan = iant_plan( preg_split( '/[\s,，]+/u', sanitize_text_field( wp_unslash( $_POST['ids'] ?? '' ) ) ), sanitize_key( $_POST['field'] ?? '' ), wp_unslash( $_POST['value'] ?? '' ) ); if ( ! is_wp_error( $plan ) ) { update_option( $key, $plan, false ); } }
    if ( isset( $_POST['iant_apply'] ) ) { check_admin_referer( 'iant_edit' ); $plan = get_option( $key ); $r = is_array( $plan ) && hash_equals( $plan['hash'], sanitize_text_field( wp_unslash( $_POST['plan'] ?? '' ) ) ) ? iant_apply( $plan ) : new WP_Error( 'iant_plan', '请重新预览修改。' ); echo '<div class="notice ' . ( is_wp_error( $r ) ? 'notice-error' : 'notice-success' ) . '"><p>' . esc_html( is_wp_error( $r ) ? $r->get_error_message() : '已更新 ' . $r . ' 项。' ) . '</p></div>'; if ( ! is_wp_error( $r ) ) { delete_option( $key ); $plan = null; } }
    echo '<div class="wrap" style="max-width:1000px"><h1>IanProject 增强工具</h1><p>只批量编辑 WooCommerce 原生属性与价格。包装、定制及图片请使用商品原生描述和媒体入口。停用或删除插件不影响已保存资料。</p>';
    if ( is_wp_error( $plan ) ) { echo '<div class="notice notice-error"><p>' . esc_html( $plan->get_error_message() ) . '</p></div>'; $plan = null; }
    echo '<form method="post">'; wp_nonce_field( 'iant_edit' ); echo '<p><label>商品或规格 ID（逗号分隔，最多 100 项）<br><input class="large-text" name="ids" required></label></p><p><label>修改字段 <select name="field">'; foreach ( iant_fields() as $field => $label ) { echo '<option value="' . esc_attr( $field ) . '">' . esc_html( $label ) . '</option>'; } echo '</select></label></p><p><label>新的值<br><textarea name="value" class="large-text" rows="5"></textarea></label></p><button name="iant_preview" class="button">预览修改清单</button></form>';
    if ( is_array( $plan ) ) { echo '<h2>待应用清单</h2><table class="widefat striped"><tr><th>商品</th><th>原值</th><th>新值</th></tr>'; foreach ( $plan['items'] as $item ) { echo '<tr><td>' . esc_html( $item['title'] . ' (#' . $item['id'] . ')' ) . '</td><td><pre>' . esc_html( is_array( $item['old'] ) ? wp_json_encode( $item['old'], JSON_UNESCAPED_UNICODE ) : $item['old'] ) . '</pre></td><td><pre>' . esc_html( is_array( $plan['value'] ) ? wp_json_encode( $plan['value'], JSON_UNESCAPED_UNICODE ) : $plan['value'] ) . '</pre></td></tr>'; } echo '</table><form method="post" style="margin-top:20px">'; wp_nonce_field( 'iant_edit' ); echo '<input type="hidden" name="plan" value="' . esc_attr( $plan['hash'] ) . '"><button name="iant_apply" class="button button-primary">应用上述修改</button></form>'; }
    echo '</div>';
}
