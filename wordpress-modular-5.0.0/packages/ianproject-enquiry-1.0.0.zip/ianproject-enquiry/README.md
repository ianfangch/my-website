# IanProject 询价扩展 1.0.0

只负责询价业务，不依赖 IanProject 主题函数。WooCommerce 商品、规格、原生价格和购物车是唯一数据来源。

- Contact 页放置 `[ian_quote_form]`。
- 设置 → IanProject 询价：选择联系页、接收邮箱、WhatsApp 号码。联系方式与 IanProject 主题使用同一份 `iansf_contacts` 设置，修改一处即可。
- 单品或购物车资料传入 Contact；客户查看草稿后，在自己的邮件应用或 WhatsApp 中按发送。
- 不在网站自动发送邮件或保存询价记录，不创建在线付款订单。
- 结算入口转 Contact，传统结算和 Store API 结算由插件阻止。
- EXW 直接读取 WooCommerce 价格后缀，不另设价格说明，不追加费用排除文字。
- 切换标准 WooCommerce 主题后，联系表单、原生商品 Contact 按钮及结算规则继续工作。
- 停用后恢复 WooCommerce 的标准结算行为；不会自动启用付款方式，也不清空商品、购物车或联系方式。

插件不会注册第二套商品类型，不删除商品或媒体，不自动修改税费设置和价格。
