<?php
/**
 * Plugin Name: IanProject 询价扩展
 * Description: 使用 WooCommerce 原生购物车整理询价，转到 Contact 并生成客户自己的邮件或 WhatsApp 草稿。不保存第二套商品和价格。
 * Version: 1.0.0
 * Requires at least: 6.7
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 */
defined( 'ABSPATH' ) || exit;
define( 'IANQ_VERSION', '1.0.0' );
require_once __DIR__ . '/includes/core.php';
require_once __DIR__ . '/includes/cart.php';
require_once __DIR__ . '/includes/contact.php';
add_action( 'admin_notices', function () {
    if ( current_user_can( 'activate_plugins' ) && ! class_exists( 'WooCommerce' ) ) {
        echo '<div class="notice notice-warning"><p>IanProject 询价扩展：请启用 WooCommerce 以使用商品和购物车询价。联系草稿功能仍可使用。</p></div>';
    }
} );
