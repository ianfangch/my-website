(()=>{const bootNode=document.getElementById('ian4-product-data');if(!bootNode)return;const BOOT=JSON.parse(bootNode.textContent),DATA=BOOT.data,PRODUCT_KEY=BOOT.key,CART_STATE=BOOT.state;const product=DATA.products[PRODUCT_KEY],assets=DATA.assets;let currentImage=0,currentModel=0,showAll=false,modelSearch='';const $=id=>document.getElementById(id),text=(id,s)=>$(id).textContent=s;const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const place=el=>{const a=assets[el.dataset.asset];if(!a)return;const img=el.querySelector('img');if(!img||!a.bounds)return;const[l,t,r,b]=a.bounds,w=el.clientWidth,h=el.clientHeight,bw=r-l,bh=b-t;if(!w||!h)return;const fill=el.classList.contains('lightbox-image')?.88:.85,scale=Math.min(w*fill/bw,h*fill/bh);Object.assign(img.style,{width:a.width*scale+'px',height:a.height*scale+'px',left:(w-bw*scale)/2-l*scale+'px',top:(h-bh*scale)/2-t*scale+'px'});};const observer=new ResizeObserver(es=>es.forEach(e=>place(e.target)));
function mount(el,key,alt){const a=assets[key];el.querySelector('img')?.remove();el.dataset.asset=key;el.classList.toggle('has-crop',!!a.bounds);const img=document.createElement('img');img.src=a.src;img.alt=alt;img.decoding='async';el.prepend(img);observer.observe(el);requestAnimationFrame(()=>place(el));}
text('breadcrumb-category',product.category);text('breadcrumb-name',product.name);text('product-title',product.name);text('product-summary',product.summary);text('overview-copy',product.overview);text('minimum-order',product.moq);text('lead-time',product.leadTime);
$('highlights').innerHTML=product.highlights.map(x=>`<li>${esc(x)}</li>`).join('');$('custom-list').innerHTML=product.customisation.map((s,i)=>`<div class="custom-item"><span>${String(i+1).padStart(2,'0')}</span>${esc(s)}</div>`).join('');if(!product.models.length){$('purchase-reference').hidden=false;text('purchase-reference','Model: '+product.code);}
$('detail-gallery').innerHTML=product.detailGallery.map((d,i)=>`<figure class="detail-view"><button class="detail-visual media-frame ${d.fit==='cover'?'is-scene':''}" type="button" id="detail-visual-${i}" aria-label="Enlarge ${esc(d.caption)}"><span class="detail-enlarge" aria-hidden="true"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M9 4H4v5m11-5h5v5M4 15v5h5m11-5v5h-5"/></svg></span></button><figcaption>${esc(d.caption)}</figcaption></figure>`).join('');product.detailGallery.forEach((d,i)=>{const el=$('detail-visual-'+i);el.style.aspectRatio=assets[d.image].width+'/'+assets[d.image].height;mount(el,d.image,product.name+' — '+d.caption);el.querySelector('img').loading='lazy';el.addEventListener('click',()=>{dialog.showModal();mount($('lightbox-image'),d.image,product.name+' — '+d.caption);text('lightbox-caption',d.caption);});});
function galleryFor(p,model=null){return Number.isInteger(model)&&p.models[model]?.images?.length?p.models[model].images:p.images;}
let currentGallery=galleryFor(product,product.models.length?0:null);
function renderGallery(){
  document.querySelectorAll('#thumbnails .media-frame').forEach(el=>observer.unobserve(el));
  $('thumbnails').innerHTML='';currentGallery=galleryFor(product,product.models.length?currentModel:null);
  currentGallery.forEach((key,i)=>{const b=document.createElement('button');b.className='thumbnail';b.type='button';b.setAttribute('aria-label','Show image '+(i+1)+' of '+currentGallery.length);b.setAttribute('aria-pressed',String(i===0));const frame=document.createElement('span');frame.className='media-frame';frame.style.display='block';b.append(frame);$('thumbnails').append(b);mount(frame,key,product.name+' — image '+(i+1));b.addEventListener('click',()=>selectImage(i));});
  document.querySelector('.gallery-prev').disabled=currentGallery.length<2;document.querySelector('.gallery-next').disabled=currentGallery.length<2;
  document.querySelector('.image-note').textContent=product.galleryScope==='series'?'Series reference images · confirm selected configuration':product.models.length?'Available reference view for the selected model · click to enlarge':'Click an image to enlarge';
  selectImage(0);
}
function selectImage(i){
  currentImage=(i+currentGallery.length)%currentGallery.length;
  const model=product.models[currentModel];
  mount($('main-image'),currentGallery[currentImage],product.name+(model?' — '+model.label:'')+' — image '+(currentImage+1));
  if(!assets[currentGallery[currentImage]].bounds)$('main-image').querySelector('img').style.objectFit=product.imageFit||'contain';
  $('main-image').style.setProperty('--image-focus',product.imageFocus[currentImage]||'50% 50%');
  text('image-counter',String(currentImage+1).padStart(2,'0')+' / '+String(currentGallery.length).padStart(2,'0'));
  document.querySelectorAll('.thumbnail').forEach((b,j)=>b.setAttribute('aria-pressed',String(j===currentImage)));
  const active=$('thumbnails').children[currentImage];
  if(getComputedStyle($('thumbnails')).flexDirection==='column')$('thumbnails').scrollTo({top:Math.max(0,active.offsetTop-$('thumbnails').offsetTop-8),behavior:'smooth'});
  else $('thumbnails').scrollTo({left:Math.max(0,active.offsetLeft-$('thumbnails').offsetLeft-10),behavior:'smooth'});
}
renderGallery();
document.querySelector('.gallery-prev').addEventListener('click',()=>selectImage(currentImage-1));document.querySelector('.gallery-next').addEventListener('click',()=>selectImage(currentImage+1));
$('thumbnails').addEventListener('keydown',e=>{if(['ArrowRight','ArrowLeft','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();selectImage(currentImage+(['ArrowRight','ArrowDown'].includes(e.key)?1:-1));$('thumbnails').children[currentImage].focus()}});

const dialog=$('image-dialog');$('main-image').addEventListener('click',()=>{dialog.showModal();mount($('lightbox-image'),currentGallery[currentImage],product.name);text('lightbox-caption',product.name+' · '+(currentImage+1)+' / '+currentGallery.length)});document.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
function renderAttributes(){
  $('packing-body').querySelectorAll('.media-frame').forEach(el=>observer.unobserve(el));
  const m=product.models[currentModel];
  const attrs=m?m.attrs:product.specs;
  $('selected-attributes').innerHTML='<dl class="spec-grid">'+Object.entries(attrs).filter(([,v])=>v&&v!=='Confirm with enquiry').map(([k,v])=>`<div class="spec-row"><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')+'</dl>';
  document.querySelector('.ian-native-packing').innerHTML=m?.packingHtml||product.packingHtml||'';
}
function chooseModel(i){
  if(!Number.isInteger(i)||i<0||i>=product.models.length)return;
  currentModel=i;
  $('hero-model').value=String(i);
  const m=product.models[i];
  text('selected-configuration',product.key==='bins'?m.attrs['Cabinet width']+' cabinet · '+m.attrs['Bin configuration']+' · '+m.size:m.size+' · Cutout: '+m.cutout);
  if(i>=6)showAll=true;
  renderGallery();renderAttributes();updateModelRows();
  dispatchEvent(new CustomEvent('configuration-change'));
}
function updateModelRows(){
  const matched=product.models.map((m,i)=>({m,i})).filter(({m})=>Object.values(m.attrs).join(' ').toLowerCase().includes(modelSearch)).map(x=>x.i);
  document.querySelectorAll('[data-model]').forEach((r,i)=>{r.hidden=!matched.includes(i)||(!showAll&&matched.indexOf(i)>=6);r.classList.toggle('is-selected',i===currentModel);r.querySelector('button').setAttribute('aria-pressed',String(i===currentModel));});
  const toggle=document.querySelector('.show-models');toggle.hidden=matched.length<=6;toggle.textContent=showAll?'Show fewer configurations':'Show all '+matched.length+(modelSearch?' matching':'')+' configurations';toggle.setAttribute('aria-expanded',String(showAll));
  document.querySelector('.model-count').textContent=modelSearch?matched.length+' of '+product.models.length+' configurations':product.models.length+' configurations';$('model-empty').hidden=matched.length>0;
}
$('spec-body').innerHTML='<div id="selected-attributes" aria-live="polite"></div>';
text('spec-title','Product attributes');
text('spec-description',product.models.length?'Select a model here or in the purchase panel. Its attributes and available reference images update together.':'Materials, finishes and dimensions are reviewed against your own project.');
if(product.models.length){
  $('configuration').hidden=false;
  $('hero-model').innerHTML=product.models.map((m,i)=>`<option value="${i}">${esc(m.label)}</option>`).join('');
  const compare=document.createElement('div');compare.className='configuration-comparison';
  compare.innerHTML=`<div class="model-intro"><h3>All configurations</h3><span class="model-count">${product.models.length} configurations</span></div><label class="model-search-label" for="model-search">Find a model or size</label><input class="model-search" id="model-search" type="search" placeholder="Search model, size or configuration"><div class="model-scroll"><table class="model-table"><thead><tr>${product.columns.map(h=>`<th scope="col">${esc(h)}</th>`).join('')}</tr></thead><tbody>${product.models.map((m,i)=>`<tr data-model="${i}"><td><button class="model-pick" type="button" data-pick="${i}" aria-pressed="${i===0}">${esc(m.cells[0])}</button></td>${m.cells.slice(1).map(v=>`<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><p class="model-empty" id="model-empty" hidden>No matching configuration. Try another model or size.</p><button class="show-models" type="button" aria-expanded="false"></button>`;
  $('spec-body').append(compare);
  $('hero-model').addEventListener('change',e=>chooseModel(Number(e.target.value)));
  compare.querySelectorAll('[data-pick]').forEach(b=>b.addEventListener('click',()=>chooseModel(Number(b.dataset.pick))));
  $('model-search').addEventListener('input',e=>{modelSearch=e.target.value.trim().toLowerCase();showAll=false;updateModelRows()});
  compare.querySelector('.show-models').addEventListener('click',()=>{showAll=!showAll;updateModelRows()});
  const m=product.models[0];
  text('selected-configuration',product.key==='bins'?m.attrs['Cabinet width']+' cabinet · '+m.attrs['Bin configuration']+' · '+m.size:m.size+' · Cutout: '+m.cutout);
  updateModelRows();
}
renderAttributes();

$('related-grid').innerHTML=product.related.map((r,i)=>`<a class="related-card" href="${esc(r.url)}" target="_blank" rel="noopener"><div class="related-image media-frame" id="related-${i}"></div><h3>${esc(r.name)}</h3><p>${esc(r.code.length>65?'Product collection':r.code)}</p></a>`).join('');product.related.forEach((r,i)=>mount($('related-'+i),r.image,r.name));

// Marketplace-style selection controls share the same model table and native product facts.
text('order-minimum',product.moq);text('order-lead',product.leadTime);text('mobile-product-label','Item subtotal');
function normalQty(p,value){const step=p.pricing.step,n=Number(value);return Math.max(step,Math.round((Number.isFinite(n)?n:step)/step)*step).toFixed(step<1?1:0)*1;}
function money(n,c='USD'){return(c==='USD'?'US$':c+' ')+new Intl.NumberFormat('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}).format(n);}
function pricingFor(p,model=null){if(Number.isInteger(model)&&p.models[model])return p.models[model].pricing?{...p.pricing,...p.models[model].pricing}:{...p.pricing,min:null,max:null,prefix:'',source:'unpriced'};return p.pricing;}
function moneyRange(lo,hi,c){return money(lo,c)+'–'+new Intl.NumberFormat('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}).format(hi);}
function priceText(p,qty=1,model=null){const a=pricingFor(p,model);if(a.min===null)return 'Price to be confirmed';const lo=a.min*qty,hi=(a.max??a.min)*qty;const value=/^from$/i.test(a.prefix)?'From '+money(lo,a.currency):hi>lo?moneyRange(lo,hi,a.currency):money(lo,a.currency);return value+(a.suffix?' '+a.suffix:'');}
function quantityText(p,qty){const singular=p.pricing.quantityUnit==='metres'?'metre':p.pricing.quantityUnit==='sets'?'set':'unit';return new Intl.NumberFormat('en-US',{maximumFractionDigits:1}).format(qty)+' '+(qty===1?singular:p.pricing.quantityUnit);}
function updateEnquiry(){const input=$('order-quantity'),qty=normalQty(product,input.value),m=product.models[currentModel],model=m?currentModel:null,a=pricingFor(product,model);input.value=String(qty);text('order-selection',quantityText(product,qty)+' · '+(m?m.label:product.code));text('order-subtotal',priceText(product,qty,model));text('mobile-selection',priceText(product,qty,model));text('product-price',priceText(product,1,model));text('product-price-unit',' / '+a.unit.replace(/^per\s+/,''));document.querySelector('.price-caption').textContent=a.min===null?'Price on enquiry':'Product price';text('product-price-note',a.min===null?'Contact us to confirm the selected model price.':'');$('product-price-note').hidden=a.min!==null;const canBuy=m?m.purchasable:product.purchasable;$('add-cart').hidden=!canBuy;document.querySelectorAll('[data-add-cart]').forEach(b=>b.hidden=!canBuy);$('quantity-minus').disabled=qty<=product.pricing.step;}
$('order-quantity').setAttribute('aria-label','Quantity in '+product.pricing.quantityUnit);$('order-quantity').min=product.pricing.step;$('order-quantity').step=product.pricing.step;$('quantity-label').innerHTML='Quantity <span>('+esc(product.pricing.quantityUnit)+')</span>';text('product-price',priceText(product));text('product-price-unit',' / '+product.pricing.unit.replace(/^per\s+/,''));text('product-price-note','');
$('quantity-plus').addEventListener('click',()=>{$('order-quantity').value=String(normalQty(product,Number($('order-quantity').value||1)+product.pricing.step));updateEnquiry()});$('quantity-minus').addEventListener('click',()=>{$('order-quantity').value=String(normalQty(product,Number($('order-quantity').value||1)-product.pricing.step));updateEnquiry()});$('order-quantity').addEventListener('change',updateEnquiry);addEventListener('configuration-change',updateEnquiry);
updateEnquiry();
const visibleContacts=new Map();const contactObserver=new IntersectionObserver(entries=>{entries.forEach(e=>visibleContacts.set(e.target,e.isIntersecting));$('mobile-contact-bar').classList.toggle('is-visible',![...visibleContacts.values()].some(Boolean))},{threshold:.2});[document.querySelector('#add-cart'),document.querySelector('#contact-product')].forEach(el=>{visibleContacts.set(el,false);contactObserver.observe(el)});

let cartItems=Array.isArray(CART_STATE?.items)?CART_STATE.items.filter(i=>DATA.products[i.key]&&Number.isFinite(Number(i.qty))):[];let contactView=false;

function persistCart(){}
function itemLabel(item){const p=DATA.products[item.key];if(p.models.length){const m=p.models[item.model]||p.models[0];return m.label+(m.label.includes(m.size)?'':' · '+m.size);}return p.code;}
function totalText(){if(!cartItems.length)return'—';const groups={};for(const i of cartItems){const p=DATA.products[i.key],a=pricingFor(p,i.model);if(a.min===null)continue;const g=groups[a.currency]??={lo:0,hi:0,from:false};g.lo+=a.min*i.qty;g.hi+=(a.max??a.min)*i.qty;g.from||=/^from$/i.test(a.prefix);}const suffixes=[...new Set(cartItems.filter(i=>pricingFor(DATA.products[i.key],i.model).min!==null).map(i=>pricingFor(DATA.products[i.key],i.model).suffix||''))],suffix=suffixes.length===1&&suffixes[0]?' '+suffixes[0]:'';return Object.entries(groups).map(([c,g])=>(g.from?'From '+money(g.lo,c):g.hi>g.lo?moneyRange(g.lo,g.hi,c):money(g.lo,c))+suffix).join('\n')+(cartItems.some(i=>pricingFor(DATA.products[i.key],i.model).min===null)?'\nAdditional items require a quotation.':'');}
function renderCart(){const count=cartItems.length;text('cart-count',count);document.querySelector('.header-cart')?.setAttribute('aria-label','Open cart, '+count+' product configurations');$('cart-empty').hidden=count>0;$('cart-checkout').disabled=!count;const html=cartItems.map((i,n)=>{const p=DATA.products[i.key];return`<article class="cart-item"><div class="cart-item-image media-frame" id="cart-image-${n}"></div><div class="cart-item-info"><h3>${esc(p.name)}</h3><p>${esc(itemLabel(i))}</p><p class="cart-item-price">${esc(priceText(p,1,i.model))} <span>/ ${esc(pricingFor(p,i.model).unit.replace(/^per\s+/,''))}</span></p><div class="cart-item-actions"><div class="cart-line-quantity"><button type="button" data-qty-down="${n}" aria-label="Decrease ${esc(p.name)} quantity">−</button><input type="number" min="${p.pricing.step}" step="${p.pricing.step}" value="${i.qty}" data-cart-quantity="${n}" aria-label="${esc(p.name)} quantity"><button type="button" data-qty-up="${n}" aria-label="Increase ${esc(p.name)} quantity">+</button></div><span>${esc(p.pricing.quantityUnit)}</span><button type="button" class="remove-cart-item" data-remove-item="${n}">Remove</button></div><strong class="cart-line-total">${esc(priceText(p,i.qty,i.model))}</strong></div></article>`}).join('');$('cart-items').innerHTML=html;cartItems.forEach((i,n)=>mount($('cart-image-'+n),galleryFor(DATA.products[i.key],i.model)[0],DATA.products[i.key].name));text('cart-total',totalText());$('cart-items').querySelectorAll('[data-remove-item]').forEach(b=>b.addEventListener('click',()=>changeCart({op:'remove',key:cartItems[Number(b.dataset.removeItem)].cartKey})));
$('cart-items').querySelectorAll('[data-qty-up],[data-qty-down]').forEach(b=>b.addEventListener('click',()=>{const n=Number(b.dataset.qtyUp??b.dataset.qtyDown),i=cartItems[n],p=DATA.products[i.key];changeCart({op:'update',key:i.cartKey,qty:normalQty(p,i.qty+(b.dataset.qtyUp!==undefined?1:-1)*p.pricing.step)})}));
$('cart-items').querySelectorAll('[data-cart-quantity]').forEach(input=>input.addEventListener('change',()=>{const i=cartItems[Number(input.dataset.cartQuantity)];changeCart({op:'update',key:i.cartKey,qty:normalQty(DATA.products[i.key],input.value)})}));}
async function api(args){const res=await fetch(BOOT.ajax,{method:'POST',credentials:'same-origin',body:new URLSearchParams({action:'ian4_cart',nonce:BOOT.nonce,...args})});const json=await res.json();if(!json.success)throw Error(json.data?.message||'Unable to update the cart. Refresh and try again.');Object.assign(DATA.products,json.data.products);Object.assign(DATA.assets,json.data.assets);cartItems=json.data.items;renderCart();return json.data;}
function errorMessage(e){$('commerce-status').textContent=e.message;const intro=document.querySelector('.cart-intro');if(cartDialog.open)intro.textContent=e.message;}
let cartBusy=false;
async function changeCart(args){if(cartBusy)return;cartBusy=true;try{await api(args);$('commerce-status').textContent='';}catch(e){errorMessage(e)}finally{cartBusy=false}}
const cartDialog=$('cart-dialog');async function openCart(){if(cartBusy)return;try{await api({op:'get'});if(!cartDialog.open)cartDialog.showModal();}catch(e){errorMessage(e)}}document.querySelectorAll('[data-open-cart]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();openCart()}));document.querySelectorAll('.cart-close,[data-close-cart]').forEach(b=>b.addEventListener('click',()=>cartDialog.close()));cartDialog.addEventListener('click',e=>{if(e.target===cartDialog)cartDialog.close()});
async function addToCart(){if(cartBusy)return;cartBusy=true;try{await api({op:'add',product:product.id,variation:product.models[currentModel]?.id||0,qty:normalQty(product,$('order-quantity').value)});if(!cartDialog.open)cartDialog.showModal();$('commerce-status').textContent='';}catch(e){errorMessage(e)}finally{cartBusy=false}}
$('add-cart').addEventListener('click',addToCart);document.querySelectorAll('[data-add-cart]').forEach(b=>b.addEventListener('click',addToCart));
function checkout(){if(cartItems.length)location.assign(BOOT.contact);}
async function contactProduct(){const model=product.models[currentModel],canBuy=model?model.purchasable:product.purchasable;if(!canBuy){const url=new URL(BOOT.directContact,location.href);if(model)url.searchParams.set('ian_variation',String(model.id));url.searchParams.set('ian_quantity',String(normalQty(product,$('order-quantity').value)));location.assign(url.href);return;}if(cartBusy)return;cartBusy=true;try{await api({op:'contact',product:product.id,variation:product.models[currentModel]?.id||0,qty:normalQty(product,$('order-quantity').value)});checkout();}catch(e){errorMessage(e)}finally{cartBusy=false}}
$('contact-product').addEventListener('click',contactProduct);$('mobile-contact-product').addEventListener('click',contactProduct);
const rail=document.querySelector('.enquiry-card'),layout=document.querySelector('.product-layout'),content=document.querySelector('.product-content'),railMedia=matchMedia('(max-width:900px)');function placePurchaseRail(){if(railMedia.matches)content.insertBefore(rail,document.querySelector('.section-nav'));else layout.append(rail);}placePurchaseRail();railMedia.addEventListener('change',placePurchaseRail);function fitPurchaseRail(){rail.classList.toggle('is-tall',rail.offsetHeight>innerHeight-40);}const railObserver=new ResizeObserver(fitPurchaseRail);railObserver.observe(rail);addEventListener('resize',fitPurchaseRail);document.fonts.ready.then(fitPurchaseRail);fitPurchaseRail();
$('cart-checkout').addEventListener('click',checkout);renderCart();
document.addEventListener('click',e=>{const a=e.target.closest?.('a[href^="#"]');if(!a)return;const target=document.getElementById(a.getAttribute('href').slice(1));if(!target)return;e.preventDefault();target.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});const focusTarget=target.querySelector('h2')||target;if(!focusTarget.hasAttribute('tabindex'))focusTarget.setAttribute('tabindex','-1');focusTarget.focus({preventScroll:true});});
const sections=[...document.querySelectorAll('main section[id]')],links=[...document.querySelectorAll('.section-nav a')];function activeSection(){let active=sections[0]?.id;for(const s of sections)if(s.getBoundingClientRect().top<140)active=s.id;links.forEach(a=>a.setAttribute('aria-current',String(a.hash==='#'+active)));}addEventListener('scroll',activeSection,{passive:true});activeSection();})();
