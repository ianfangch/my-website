<?php
defined( 'ABSPATH' ) || exit;
function ian3_contact_actions( $html ) {
    if ( is_admin() || is_front_page() || is_page( ian3_id( 'home' ) ) || is_page( ian3_id( 'contact' ) ) || ! str_contains( $html, '<a' ) ) { return $html; }
    $contact = ian3_url( 'contact' );
    $html = preg_replace_callback( '~<a\b([^>]*)>(.*?)</a>~is', function ( $match ) use ( $contact ) {
        $label = trim( wp_strip_all_tags( $match[2] ) ); $attrs = $match[1];
        $button = preg_match( '~class=["\'][^"\']*(?:btn|button|ip-inline-link)[^"\']*["\']~i', $attrs );
        $catalogue = preg_match( '~^(?:view|request|browse|download|get|ask for)\b.*\bcatalog(?:ue)?s?\b~i', $label );
        $own_contact = $button && ( preg_match( '~href=["\'](?:mailto:|https?://(?:wa\.me|api\.whatsapp\.com)/)~i', $attrs ) || preg_match( '~^(?:contact|discuss|request|email|start|check installation)\b~i', $label ) );
        if ( ! $catalogue && ! $own_contact ) { return $match[0]; }
        $class = 'ip-button ian-contact-action';
        return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $contact ) . '">Contact</a>';
    }, $html );
    // Collapse the old paired catalogue/email buttons within each paragraph into one Contact action.
    return preg_replace_callback( '~<p\b([^>]*)>(.*?)</p>~is', function ( $p ) use ( $contact ) {
        $seen = false;
        $inner = preg_replace_callback( '~<a\b([^>]*)>Contact</a>~i', function ( $a ) use ( &$seen, $contact ) {
            if ( ! str_contains( html_entity_decode( $a[1], ENT_QUOTES ), $contact ) ) { return $a[0]; }
            if ( $seen ) { return ''; } $seen = true; return $a[0];
        }, $p[2] );
        return '<p' . $p[1] . '>' . $inner . '</p>';
    }, $html );
}
add_filter( 'render_block', 'ian3_contact_actions', 40 );
add_filter( 'the_content', 'ian3_contact_actions', 40 );

/** Check rendered legacy content before adding any fallback action. */
function ian3_has_contact_action( $html ) {
    $tags = new WP_HTML_Tag_Processor( $html ); $contact = untrailingslashit( ian3_url( 'contact' ) );
    while ( $tags->next_tag( 'A' ) ) {
        $url = $tags->get_attribute( 'href' ); $class = (string) $tags->get_attribute( 'class' );
        if ( is_string( $url ) && $url && untrailingslashit( strtok( html_entity_decode( $url, ENT_QUOTES ), '?#' ) ) === $contact && preg_match( '/(?:btn|button|ian-contact-action)/', $class ) ) { return true; }
    }
    return false;
}
// This line of statistics already precedes the full-width Contact section.
add_filter( 'render_block', function ( $html, $block ) {
    if ( is_admin() || ! str_contains( $block['attrs']['className'] ?? '', 'ia-capability-footer' ) ) { return $html; }
    return preg_replace_callback( '~<a\b([^>]*)>.*?</a>~is', function ( $a ) { return preg_match( '~class=["\'][^"\']*(?:btn|button|ian-contact-action)~i', $a[1] ) ? '' : $a[0]; }, $html );
}, 45, 2 );
// A quote-only product needs one Contact action, rather than a second quotation heading.
add_filter( 'do_shortcode_tag', function ( $html, $tag ) {
    if ( 'ian_product_price' === $tag && is_singular( array( 'product', 'ian_product' ) ) && 'Request a Quote' === trim( wp_strip_all_tags( $html ) ) ) { return ''; }
    return $html;
}, 45, 2 );
