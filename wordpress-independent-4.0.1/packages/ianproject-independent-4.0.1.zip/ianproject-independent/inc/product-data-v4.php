<?php
defined( 'ABSPATH' ) || exit;

/** Persistent data uses WooCommerce products/variations and ordinary post meta. */
function ian4_meta( $product, $name, $fallback = '' ) {
    $id = is_object( $product ) ? $product->get_id() : absint( $product );
    return metadata_exists( 'post', $id, '_ian4_' . $name ) ? get_post_meta( $id, '_ian4_' . $name, true ) : $fallback;
}
function ian4_pairs( $text ) {
    $out = array();
    foreach ( preg_split( '/\R/u', (string) $text ) as $line ) {
        $parts = preg_split( '/[:：]/u', $line, 2 );
        if ( count( $parts ) === 2 && trim( $parts[0] ) && trim( $parts[1] ) ) { $out[ sanitize_text_field( trim( $parts[0] ) ) ] = sanitize_text_field( trim( $parts[1] ) ); }
    }
    return $out;
}
function ian4_pair_text( $pairs ) { $out = array(); foreach ( (array) $pairs as $k => $v ) { if ( is_scalar( $v ) ) { $out[] = $k . ': ' . $v; } } return implode( "\n", $out ); }
function ian4_image_ids( $text ) { return array_values( array_unique( array_filter( array_map( 'absint', is_array( $text ) ? $text : explode( ',', (string) $text ) ), fn( $id ) => wp_attachment_is_image( $id ) ) ) ); }
function ian4_pricing( $product, $parent = null ) {
    $unit = ian4_meta( $product, 'unit', $parent ? ian4_meta( $parent, 'unit', 'unit' ) : 'unit' );
    $unit = in_array( $unit, array( 'unit', 'set', 'metre' ), true ) ? $unit : 'unit';
    $base = array( 'currency' => get_woocommerce_currency(), 'min' => null, 'max' => null, 'prefix' => '', 'unit' => 'per ' . $unit, 'quantityUnit' => $unit . 's', 'step' => 'metre' === $unit ? 0.1 : 1 );
    if ( '' !== $product->get_price( 'edit' ) && ! ian4_meta( $product, 'quote_only', false ) ) {
        $base['min'] = (float) wc_get_price_to_display( $product );
        $base['prefix'] = ian4_meta( $product, 'price_prefix', '' );
        return $base;
    }
    $source = '' !== (string) ian4_meta( $product, 'reference_min', '' ) ? $product : $parent;
    if ( $source ) {
        $lo = ian4_meta( $source, 'reference_min', '' );
        $hi = ian4_meta( $source, 'reference_max', '' );
        $base['min'] = is_numeric( $lo ) ? (float) $lo : null;
        $base['max'] = is_numeric( $hi ) ? (float) $hi : null;
        $base['currency'] = strtoupper( (string) ian4_meta( $source, 'reference_currency', get_woocommerce_currency() ) );
        $base['prefix'] = ian4_meta( $source, 'price_prefix', '' );
    }
    return $base;
}
function ian4_price_text( $pricing, $qty = 1 ) {
    if ( null === $pricing['min'] ) { return 'Price to be confirmed'; }
    $prefix = 'USD' === $pricing['currency'] ? 'US$' : $pricing['currency'] . ' ';
    $lo = $pricing['min'] * $qty; $hi = ( $pricing['max'] ?? $pricing['min'] ) * $qty;
    return ( 'from' === strtolower( $pricing['prefix'] ) ? 'From ' : '' ) . $prefix . number_format( $lo, 2, '.', ',' ) . ( $hi > $lo && 'from' !== strtolower( $pricing['prefix'] ) ? '–' . number_format( $hi, 2, '.', ',' ) : '' );
}
function ian4_attributes( $product ) {
    $out = array();
    foreach ( $product->get_attributes() as $name => $attr ) {
        if ( is_object( $attr ) ) {
            if ( ! $attr->get_visible() || $attr->get_variation() ) { continue; }
            $out[ wc_attribute_label( $name ) ] = $product->get_attribute( $name );
        } elseif ( is_scalar( $attr ) && '' !== (string) $attr ) { $out[ wc_attribute_label( $name ) ] = $product->get_attribute( $name ) ?: (string) $attr; }
    }
    foreach ( (array) ian4_meta( $product, 'attributes', array() ) as $name => $value ) { if ( is_scalar( $value ) && '' !== (string) $value ) { $out[ $name ] = (string) $value; } }
    return $out;
}
function ian4_asset( $id, &$assets ) {
    $id = absint( $id ); $image = wp_get_attachment_image_src( $id, 'full' );
    if ( ! $image ) { return ''; }
    $key = 'attachment-' . $id;
    $assets[ $key ] = array( 'src' => $image[0], 'width' => $image[1], 'height' => $image[2], 'bounds' => get_post_meta( $id, '_ian4_subject_box', true ) ?: null );
    return $key;
}
function ian4_product_payload( $product, &$assets ) {
    $id = $product->get_id(); $pricing = ian4_pricing( $product );
    $assets['placeholder']=array('src'=>wc_placeholder_img_src('full'),'width'=>800,'height'=>600,'bounds'=>null);
    $images = array_values( array_filter( array_map( function($i) use (&$assets){return ian4_asset($i,$assets);}, array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) ) ) );
    if ( ! $images ) { $key = 'placeholder'; $assets[ $key ] = array( 'src' => wc_placeholder_img_src( 'full' ), 'width' => 800, 'height' => 600, 'bounds' => null ); $images[] = $key; }
    $models = array();
    if ( $product->is_type( 'variable' ) ) {
        foreach ( $product->get_children() as $vid ) {
            $v = wc_get_product( $vid ); if ( ! $v || 'publish' !== $v->get_status() || ! $v->variation_is_active() || ! $v->is_in_stock() ) { continue; }
            $attrs = array_merge( ian4_attributes( $product ), ian4_attributes( $v ) );
            $label = implode( ' · ', array_values( array_filter( array_map( fn( $name ) => $v->get_attribute( $name ), array_keys( $v->get_attributes() ) ) ) ) );
            if ( ! $label ) { $label = $v->get_sku() ?: 'Configuration ' . $vid; }
            $model_images = array_values( array_filter( array_map( function($i) use (&$assets){return ian4_asset($i,$assets);}, ian4_image_ids( array_merge( array( $v->get_image_id() ), (array) ian4_meta( $v, 'gallery', array() ) ) ) ) ) );
            $own_price = ( '' !== $v->get_price( 'edit' ) && ! ian4_meta( $v, 'quote_only', false ) ) || '' !== (string) ian4_meta( $v, 'reference_min', '' ) ? ian4_pricing( $v, $product ) : null;
            $code = ian4_meta( $v, 'model', '' ) ?: $v->get_sku() ?: $label;
            $size = $attrs['Overall dimensions'] ?? $attrs['Product dimensions'] ?? $attrs['Dimensions'] ?? $v->get_dimensions( false );
            if ( is_array( $size ) ) { $size = implode( ' × ', array_filter( $size ) ); }
            $models[] = array( 'id' => $vid, 'code' => $code, 'size' => $size, 'cutout' => $attrs['Cutout'] ?? '', 'note' => $attrs['Features'] ?? '', 'label' => $label, 'attrs' => $attrs, 'images' => $model_images ?: $images, 'pricing' => $own_price, 'packaging' => (array) ian4_meta( $v, 'packaging', array() ), 'packagingMedia' => ian4_packing_media( $v, $assets ), 'cells' => array( $code, $label, $size ?: '—', $attrs['Features'] ?? $attrs['Bin configuration'] ?? '—' ) );
        }
    }
    $terms = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'names' ) );
    $related = array();
    foreach ( wc_get_related_products( $id, 3 ) as $rid ) { $rp = wc_get_product( $rid ); if ( $rp && $rp->is_visible() ) { $related[] = array( 'name' => $rp->get_name(), 'code' => $rp->get_sku(), 'image' => ian4_asset( $rp->get_image_id(), $assets ) ?: 'placeholder', 'url' => get_permalink( $rid ) ); } }
    return array( 'key' => 'p' . $id, 'id' => $id, 'name' => $product->get_name(), 'category' => is_wp_error( $terms ) ? '' : implode( ', ', $terms ), 'code' => $product->get_sku(), 'summary' => wp_strip_all_tags( $product->get_short_description() ), 'images' => $images, 'imageFocus' => array(), 'imageFit'=>ian4_meta($product,'image_fit','contain'), 'galleryScope' => ian4_meta( $product, 'image_scope', 'product' ), 'models' => $models, 'specs' => ian4_attributes( $product ), 'packaging' => (array) ian4_meta( $product, 'packaging', array() ), 'packagingMedia' => ian4_packing_media( $product, $assets ), 'moq' => ian4_meta( $product, 'moq', '' ), 'leadTime' => ian4_meta( $product, 'lead_time', '' ), 'pricing' => $pricing, 'highlights' => array(), 'customisation' => array_values( array_filter( preg_split( '/\R/u', (string) ian4_meta( $product, 'customisation', '' ) ) ) ), 'related' => $related, 'columns' => array( 'Model', 'Configuration', 'Dimensions', 'Features' ), 'overview' => '', 'detailGallery' => array() );
}
function ian4_packing_media( $product, &$assets ) {
    $id = absint( ian4_meta( $product, 'packing_image', 0 ) );
    $key = $id ? ian4_asset( $id, $assets ) : '';
    return $key ? array( 'image' => $key, 'caption' => ian4_meta( $product, 'packing_caption', 'Packaging reference. Final packing is confirmed in the quotation.' ) ) : null;
}

add_filter( 'woocommerce_product_data_tabs', function ( $tabs ) { $tabs['ianproject'] = array( 'label' => 'IanProject 资料', 'target' => 'ian4-product-data', 'priority' => 60 ); return $tabs; } );
function ian4_admin_media_field( $name, $value, $label, $multiple = false ) {
    echo '<p class="form-field"><label>' . esc_html( $label ) . '</label><input type="text" class="short ian4-media-value" name="' . esc_attr( $name ) . '" value="' . esc_attr( is_array( $value ) ? implode( ',', $value ) : $value ) . '"><button type="button" class="button ian4-media-select" data-multiple="' . ( $multiple ? '1' : '0' ) . '">选择图片</button><span class="description">媒体库附件 ID；可用选择器修改。</span></p>';
}
add_action( 'woocommerce_product_data_panels', function () {
    global $product_object; if ( ! $product_object ) { return; }
    echo '<div id="ian4-product-data" class="panel woocommerce_options_panel hidden">'; wp_nonce_field( 'ian4_product_data', 'ian4_product_nonce' );
    foreach ( array( 'moq' => '最小起订量', 'lead_time' => '生产交期', 'reference_min' => '系列参考最低价', 'reference_max' => '系列参考最高价', 'reference_currency' => '参考价币种（如 USD / CNY）', 'price_prefix' => '起价前缀（From 或留空）' ) as $key => $label ) { woocommerce_wp_text_input( array( 'id' => 'ian4_' . $key, 'label' => $label, 'value' => ian4_meta( $product_object, $key ) ) ); }
    woocommerce_wp_select(array('id'=>'ian4_image_fit','label'=>'主图展示','value'=>ian4_meta($product_object,'image_fit','contain'),'options'=>array('contain'=>'完整商品','cover'=>'填满场景画框')));
    woocommerce_wp_select( array( 'id' => 'ian4_unit', 'label' => '计价单位', 'value' => ian4_meta( $product_object, 'unit', 'unit' ), 'options' => array( 'unit' => '件', 'set' => '套', 'metre' => '米' ) ) );
    woocommerce_wp_checkbox( array( 'id' => 'ian4_quote_only', 'label' => '询价商品', 'description' => '没有确认的型号价格时可加入询价购物车；不会按零元下单。', 'value' => ian4_meta( $product_object, 'quote_only' ) ? 'yes' : 'no' ) );
    woocommerce_wp_textarea_input( array( 'id' => 'ian4_packaging', 'label' => '包装资料', 'description' => '每行“字段: 值”，例如 Packing method: Carton；没有资料时留空。', 'value' => ian4_pair_text( ian4_meta( $product_object, 'packaging', array() ) ) ) );
    ian4_admin_media_field( 'ian4_packing_image', ian4_meta( $product_object, 'packing_image' ), '包装图片' );
    woocommerce_wp_textarea_input( array( 'id' => 'ian4_customisation', 'label' => '定制说明', 'description' => '每行一项。商品详情的图文请直接编辑正文。', 'value' => ian4_meta( $product_object, 'customisation' ) ) );
    echo '</div>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $p ) {
    if ( ! isset( $_POST['ian4_product_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ian4_product_nonce'] ) ), 'ian4_product_data' ) || ! current_user_can( 'edit_post', $p->get_id() ) ) { return; }
    foreach ( array( 'moq', 'lead_time', 'unit', 'reference_currency', 'price_prefix', 'image_fit' ) as $key ) { $p->update_meta_data( '_ian4_' . $key, sanitize_text_field( wp_unslash( $_POST[ 'ian4_' . $key ] ?? '' ) ) ); }
    foreach ( array( 'reference_min', 'reference_max' ) as $key ) { $raw = wp_unslash( $_POST[ 'ian4_' . $key ] ?? '' ); $p->update_meta_data( '_ian4_' . $key, '' === $raw ? '' : max( 0, (float) wc_format_decimal( $raw ) ) ); }
    $p->update_meta_data( '_ian4_quote_only', isset( $_POST['ian4_quote_only'] ) ? 1 : 0 );
    $p->update_meta_data( '_ian4_packaging', ian4_pairs( wp_unslash( $_POST['ian4_packaging'] ?? '' ) ) );
    $p->update_meta_data( '_ian4_packing_image', absint( $_POST['ian4_packing_image'] ?? 0 ) );
    $p->update_meta_data( '_ian4_customisation', sanitize_textarea_field( wp_unslash( $_POST['ian4_customisation'] ?? '' ) ) );
} );
add_action( 'woocommerce_product_after_variable_attributes', function ( $loop, $data, $variation ) {
    $id = $variation->ID;
    echo '<div class="ian4-variation-data" style="clear:both"><h4>IanProject 规格资料</h4>'; wp_nonce_field( 'ian4_variation_' . $id, 'ian4_variation_nonce[' . $id . ']' );
    foreach ( array( 'model' => '型号 / 参考代码', 'reference_min' => '规格参考最低价（留空沿用系列）', 'reference_max' => '规格参考最高价', 'reference_currency' => '规格参考币种' ) as $key => $label ) { echo '<p class="form-row form-row-full"><label>' . esc_html( $label ) . '</label><input class="short" name="ian4_variation[' . esc_attr( $id ) . '][' . esc_attr( $key ) . ']" value="' . esc_attr( ian4_meta( $id, $key ) ) . '"></p>'; }
    foreach ( array( 'attributes' => '规格参数（每行 字段: 值）', 'packaging' => '规格包装资料（留空沿用商品资料）' ) as $key => $label ) { echo '<p class="form-row form-row-full"><label>' . esc_html( $label ) . '</label><textarea class="widefat" rows="4" name="ian4_variation[' . esc_attr( $id ) . '][' . esc_attr( $key ) . ']">' . esc_textarea( ian4_pair_text( ian4_meta( $id, $key, array() ) ) ) . '</textarea></p>'; }
    ian4_admin_media_field( 'ian4_variation[' . $id . '][gallery]', ian4_meta( $id, 'gallery', array() ), '此规格的额外图片', true );
    ian4_admin_media_field( 'ian4_variation[' . $id . '][packing_image]', ian4_meta( $id, 'packing_image' ), '此规格包装图' );
    echo '</div>';
}, 10, 3 );
add_action( 'woocommerce_save_product_variation', function ( $id ) {
    $nonce = $_POST['ian4_variation_nonce'][ $id ] ?? '';
    if ( ! is_scalar( $nonce ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $nonce ) ), 'ian4_variation_' . $id ) || ! current_user_can( 'edit_post', $id ) ) { return; }
    $data = wp_unslash( $_POST['ian4_variation'][ $id ] ?? array() );
    foreach ( array( 'model', 'reference_currency' ) as $key ) { update_post_meta( $id, '_ian4_' . $key, sanitize_text_field( $data[ $key ] ?? '' ) ); }
    foreach ( array( 'reference_min', 'reference_max' ) as $key ) { $raw = $data[ $key ] ?? ''; update_post_meta( $id, '_ian4_' . $key, '' === $raw ? '' : max( 0, (float) wc_format_decimal( $raw ) ) ); }
    foreach ( array( 'attributes', 'packaging' ) as $key ) { update_post_meta( $id, '_ian4_' . $key, ian4_pairs( $data[ $key ] ?? '' ) ); }
    update_post_meta( $id, '_ian4_gallery', ian4_image_ids( $data['gallery'] ?? '' ) );
    update_post_meta( $id, '_ian4_packing_image', absint( $data['packing_image'] ?? 0 ) );
}, 10, 1 );
add_action( 'admin_enqueue_scripts', function () {
    if ( ! get_current_screen() || 'product' !== get_current_screen()->post_type ) { return; }
    wp_enqueue_media(); wp_add_inline_script( 'media-editor', "document.addEventListener('click',function(e){const b=e.target.closest('.ian4-media-select');if(!b)return;e.preventDefault();const input=b.parentElement.querySelector('input'),multiple=b.dataset.multiple==='1',frame=wp.media({title:'选择产品图片',library:{type:'image'},multiple:multiple});frame.on('select',function(){const selected=frame.state().get('selection').toJSON();input.value=selected.map(i=>i.id).join(',');input.dispatchEvent(new Event('change',{bubbles:true}));});frame.open();});" );
} );
