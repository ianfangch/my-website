<?php
defined( 'ABSPATH' ) || exit;
function ian4_enquiry_form() {
    $requirements = '';
    if ( ! empty( $_GET['cart'] ) ) { $requirements = ian4_cart_summary_text(); }
    if ( ! $requirements && isset( $_GET['product'] ) && is_scalar( $_GET['product'] ) ) { $id = absint( $_GET['product'] ); if ( 'publish' === get_post_status( $id ) && 'product' === get_post_type( $id ) ) { $requirements = 'Product: ' . get_the_title( $id ) . "\nModel: " . get_post_meta( $id, '_sku', true ) . "\nQuantity:\nRequirements:"; } }
    $status = sanitize_key( is_scalar( $_GET['request_status'] ?? '' ) ? ( $_GET['request_status'] ?? '' ) : '' );
    ob_start();
    if ( 'sent' === $status ) { echo '<p role="status" class="alert alert-success">Your request has been submitted. We will review your requirements.</p>'; }
    elseif ( 'failed' === $status ) { echo '<p role="alert" class="alert alert-warning">We could not send your request. Please try again or email ' . esc_html( iansf_contacts()['email'] ) . '.</p>'; }
    ?>
    <form id="quote-builder-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
    <input type="hidden" name="action" value="ian4_enquiry"><?php wp_nonce_field( 'ian4_enquiry', 'ian4_nonce' ); ?>
    <div style="position:absolute;left:-10000px" aria-hidden="true"><label>Leave this blank<input name="ian4_website_check" tabindex="-1" autocomplete="off"></label></div>
    <div class="row g-4">
    <div class="col-md-6"><label class="form-label" for="request-name">Name *</label><input class="form-control" id="request-name" name="name" maxlength="120" autocomplete="name" required></div>
    <div class="col-md-6"><label class="form-label" for="request-website">Company website <span class="text-muted small">(optional)</span></label><input class="form-control" id="request-website" name="website" inputmode="url" maxlength="240" autocomplete="url" placeholder="yourcompany.com"></div>
    <div class="col-md-6"><label class="form-label" for="request-country">Country *</label><input class="form-control" id="request-country" name="country" autocomplete="country-name" maxlength="100" required></div>
    <div class="col-md-6"><label class="form-label" for="request-terms">Trade terms *</label><select class="form-select" id="request-terms" name="terms" required><option value="">Select trade terms</option><?php foreach ( array( 'EXW', 'FOB', 'CIF', 'DDP' ) as $term ) { echo '<option>' . esc_html( $term ) . '</option>'; } ?></select></div>
    <div class="col-12"><label class="form-label" for="request-requirements">Requirements *</label><textarea class="form-control" id="request-requirements" name="requirements" rows="9" maxlength="12000" required><?php echo esc_textarea( $requirements ); ?></textarea><p class="small text-muted mt-2">Include the product name, model, quantity and a reply email in your requirements. For custom products, send drawings and a bill of materials by email.</p></div>
    </div><button class="btn btn-primary px-4 py-3 mt-4" type="submit">Send project request</button>
    </form>
    <?php return ob_get_clean();
}
function ian4_send_enquiry( $data, $nonce ) {
    if ( ! wp_verify_nonce( $nonce, 'ian4_enquiry' ) ) { return new WP_Error( 'ian_nonce', 'Please refresh the form and try again.' ); }
    if ( ! empty( $data['ian4_website_check'] ) ) { return new WP_Error( 'ian_spam', 'Unable to submit this request.' ); }
    $safe = array(); foreach ( array( 'name', 'website', 'country', 'terms', 'requirements' ) as $key ) { if ( ! is_scalar( $data[ $key ] ?? '' ) ) { return new WP_Error( 'ian_form', 'Invalid form data.' ); } $safe[ $key ] = 'requirements' === $key ? sanitize_textarea_field( $data[ $key ] ?? '' ) : sanitize_text_field( $data[ $key ] ?? '' ); }
    foreach ( array( 'name', 'country', 'requirements' ) as $key ) { if ( '' === trim( $safe[ $key ] ) ) { return new WP_Error( 'ian_form', 'Please complete all required fields.' ); } }
    if ( strlen( $safe['name'] ) > 480 || strlen( $safe['country'] ) > 400 || strlen( $safe['requirements'] ) > 48000 || ! in_array( $safe['terms'], array( 'EXW', 'FOB', 'CIF', 'DDP' ), true ) ) { return new WP_Error( 'ian_form', 'Invalid request fields.' ); }
    if ( $safe['website'] ) { $url = preg_match( '~^https?://~i', $safe['website'] ) ? $safe['website'] : 'https://' . $safe['website']; if ( ! filter_var( $url, FILTER_VALIDATE_URL ) || ! in_array( wp_parse_url( $url, PHP_URL_SCHEME ), array( 'http', 'https' ), true ) ) { return new WP_Error( 'ian_website', 'Enter a valid company website or leave it blank.' ); } $safe['website'] = esc_url_raw( $url ); }
    $ip = sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? 'local' ); $rate_key = 'ian4_mail_' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 32 ); $count = (int) get_transient( $rate_key );
    if ( $count >= 5 ) { return new WP_Error( 'ian_rate', 'Please wait before sending another request.' ); }
    $email = sanitize_email( iansf_contacts()['email'] ); if ( ! is_email( $email ) ) { return new WP_Error( 'ian_email', 'The receiving email is not configured.' ); }
    $cart = function_exists( 'ian4_cart_summary_text' ) ? ian4_cart_summary_text() : '';
    $body = 'Name: ' . $safe['name'] . "\nCompany website: " . ( $safe['website'] ?: 'Not provided' ) . "\nCountry: " . $safe['country'] . "\nTrade terms: " . $safe['terms'] . "\n\nRequirements:\n" . $safe['requirements'] . ( $cart ? "\n\nCurrent cart (server reference):\n" . $cart : '' ) . "\n\nFinal pricing, packing and delivery require confirmation.";
    set_transient( $rate_key, $count + 1, 10 * MINUTE_IN_SECONDS );
    $sent = wp_mail( $email, 'IanProject request — ' . $safe['name'], $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
    do_action( 'ian4_enquiry_result', $sent, $safe );
    return $sent ? true : new WP_Error( 'ian_mail', 'The mail service did not accept the message.' );
}
foreach ( array( 'admin_post_ian4_enquiry', 'admin_post_nopriv_ian4_enquiry' ) as $hook ) {
    add_action( $hook, function () { $nonce = isset( $_POST['ian4_nonce'] ) && is_scalar( $_POST['ian4_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['ian4_nonce'] ) ) : ''; $result = ian4_send_enquiry( wp_unslash( $_POST ), $nonce ); wp_safe_redirect( add_query_arg( 'request_status', is_wp_error( $result ) ? 'failed' : 'sent', ian3_url( 'contact' ) ) ); exit; } );
}
add_action( 'init', function () { add_shortcode( 'ian_quote_form', 'ian4_enquiry_form' ); }, 1001 );
