<?php
defined( 'ABSPATH' ) || exit;
add_action( 'admin_menu', function () { add_submenu_page( 'edit.php?post_type=product', 'IanProject 产品目录设置', 'IanProject 目录', 'manage_woocommerce', 'ian-catalog-settings', 'ianc_admin' ); } );
function ianc_admin() {
    if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
    if ( isset( $_POST['ianc_save'] ) ) { check_admin_referer( 'ianc_settings' ); update_option( 'ian_catalog_show_prices', isset( $_POST['ianc_prices'] ) ); do_action( 'litespeed_purge_all' ); echo '<div class="notice notice-success"><p>目录设置已保存。</p></div>'; }
    if ( isset( $_POST['ianc_restore'] ) ) { check_admin_referer( 'ianc_restore' ); $errors = array(); foreach ( get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'meta_key' => '_ian_catalog_migrated', 'posts_per_page' => -1, 'fields' => 'ids' ) ) as $id ) { $r = ianc_restore_product( $id ); if ( is_wp_error( $r ) ) { $errors[] = $r->get_error_message(); } } flush_rewrite_rules( false ); echo '<div class="notice ' . ( $errors ? 'notice-error' : 'notice-success' ) . '"><p>' . esc_html( $errors ? implode( '；', $errors ) : '已恢复迁移前的产品。WooCommerce 中其他产品不受影响。' ) . '</p></div>'; }
    $old = get_posts( array( 'post_type' => 'ian_product', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'posts_per_page' => -1, 'fields' => 'ids' ) );
    ?><div class="wrap" style="max-width:950px"><h1>IanProject 产品目录 3.0</h1><p>产品使用 WooCommerce 原生产品与分类，主题不包含产品样例。默认只询价，关闭加入购物车与在线购买。停用或删除本模块不会删除产品、分类或媒体。</p>
    <form method="post"><?php wp_nonce_field( 'ianc_settings' ); ?><label><input type="checkbox" name="ianc_prices" value="1" <?php checked( get_option( 'ian_catalog_show_prices', false ) ); ?>>在前台目录显示已设置的 WooCommerce 价格</label><p>迁移保留原币种与原价格，不做未经确认的汇率换算；仅在原币种与商店币种一致时写入 WooCommerce 价格。不同币种的原价保存在产品自定义资料中。</p><button class="button button-primary" name="ianc_save">保存设置</button></form>
    <h2>分类与单个产品显示</h2><p>在“产品 → 分类”编辑分类，勾选“从目录隐藏”；分类及子分类会从菜单、筛选、首页和目录列表中同步移除。空分类自动隐藏。单个产品使用 WooCommerce 的“目录可见性”设置；要完全不公开，请保存为草稿。仅隐藏目录不限制原链接访问。</p>
    <h2>旧产品迁移</h2><p>检测到 <?php echo count( $old ); ?> 个旧 IanProject 产品。逐项转为 WooCommerce 产品，保留 ID、名称、正文、状态、分类、封面、图库和原始资料，并保存迁移前备份。SKU 冲突时保留原型号，WooCommerce SKU 会加 ID 后缀。迁移完成前不要删除旧主题文件。</p><button id="ianc-migrate" class="button button-primary">合并旧产品到 WooCommerce</button><p id="ianc-status" role="status"></p>
    <details><summary>恢复旧产品备份</summary><p>恢复迁移前的数据会替换迁移后的产品编辑，请仅在确需回退时使用。</p><form method="post"><?php wp_nonce_field( 'ianc_restore' ); ?><button class="button" name="ianc_restore">恢复迁移前产品</button></form></details></div>
    <script>(()=>{const b=document.getElementById('ianc-migrate'),s=document.getElementById('ianc-status');b.addEventListener('click',async()=>{b.disabled=true;let n=0;try{while(true){const r=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:new URLSearchParams({action:'ianc_migrate',nonce:<?php echo wp_json_encode( wp_create_nonce( 'ianc_migrate' ) ); ?>})});const j=await r.json();if(!j.success)throw Error(j.data?.message||'迁移失败');n+=j.data.migrated;s.textContent='已迁移 '+n+' 个；剩余 '+j.data.remaining;if(!j.data.remaining){s.textContent='迁移完成。产品均在 WooCommerce 原生产品菜单中管理。';break;}}}catch(e){s.textContent='暂停：'+e.message+'。可重试，已迁移产品不会重复创建。';}finally{b.disabled=false;}});})();</script><?php
}
add_action( 'wp_ajax_ianc_migrate', function () {
    if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_send_json_error( array( 'message' => '没有迁移权限。' ), 403 ); } check_ajax_referer( 'ianc_migrate', 'nonce' );
    $ids = get_posts( array( 'post_type' => 'ian_product', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'posts_per_page' => 1, 'fields' => 'ids' ) );
    foreach ( $ids as $id ) { $r = ianc_migrate_product( $id ); if ( is_wp_error( $r ) ) { wp_send_json_error( array( 'message' => $r->get_error_message() ), 400 ); } }
    $query = new WP_Query( array( 'post_type' => 'ian_product', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'posts_per_page' => 1, 'fields' => 'ids' ) ); flush_rewrite_rules( false ); wp_send_json_success( array( 'migrated' => count( $ids ), 'remaining' => $query->found_posts ) );
} );
add_action( 'product_cat_add_form_fields', function () { wp_nonce_field( 'ianc_term', 'ianc_term_nonce' ); echo '<div class="form-field"><label><input type="checkbox" name="ianc_hide" value="1"> 从 IanProject 目录隐藏此分类及子分类</label><p>不删除产品，仅隐藏目录、筛选、菜单及首页入口。</p></div>'; } );
add_action( 'product_cat_edit_form_fields', function ( $term ) { ?><tr class="form-field"><th>IanProject 目录显示</th><td><?php wp_nonce_field( 'ianc_term', 'ianc_term_nonce' ); ?><label><input type="checkbox" name="ianc_hide" value="1" <?php checked( get_term_meta( $term->term_id, '_ian_hide_catalog', true ), '1' ); ?>>从目录隐藏此分类及子分类</label><p class="description">原产品链接仍可访问；完全不公开请将产品设为草稿。</p></td></tr><?php } );
function ianc_save_term( $id ) {
    if ( ! current_user_can( 'manage_product_terms' ) || ! isset( $_POST['ianc_term_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ianc_term_nonce'] ) ), 'ianc_term' ) ) { return; }
    update_term_meta( $id, '_ian_hide_catalog', isset( $_POST['ianc_hide'] ) ? '1' : '0' ); do_action( 'litespeed_purge_all' );
}
add_action( 'created_product_cat', 'ianc_save_term' ); add_action( 'edited_product_cat', 'ianc_save_term' );
