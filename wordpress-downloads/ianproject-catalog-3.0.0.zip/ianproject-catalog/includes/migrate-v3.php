<?php
defined( 'ABSPATH' ) || exit;
add_action( 'init', function () {
    register_post_type( 'ian_product', array( 'public' => false, 'show_ui' => false, 'show_in_rest' => false, 'rewrite' => false, 'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'revisions' ) ) );
    register_taxonomy( 'ian_product_category', 'ian_product', array( 'public' => false, 'show_ui' => false, 'hierarchical' => true, 'rewrite' => false ) );
} );
function ianc_migrate_term( $id ) {
    $term = get_term( $id, 'ian_product_category' ); if ( ! $term || is_wp_error( $term ) ) { return 0; }
    $found = get_term_by( 'slug', $term->slug, 'product_cat' ); if ( $found ) { return $found->term_id; }
    $parent = $term->parent ? ianc_migrate_term( $term->parent ) : 0;
    $new = wp_insert_term( $term->name, 'product_cat', array( 'slug' => $term->slug, 'description' => $term->description, 'parent' => $parent ) );
    return is_wp_error( $new ) ? 0 : (int) $new['term_id'];
}
function ianc_local_attachment( $source ) {
    if ( ! is_string( $source ) || ! $source ) { return 0; }
    $url = $source;
    if ( str_starts_with( $url, '{{IAN_ASSET}}/' ) || str_starts_with( $url, 'img/' ) ) {
        $relative = str_replace( '{{IAN_ASSET}}/', '', $url ); $legacy = get_option( 'ian_legacy_stylesheet_v2', get_stylesheet() );
        $url = trailingslashit( get_theme_root_uri() ) . $legacy . '/assets/' . $relative;
    }
    $id = attachment_url_to_postid( $url ); if ( $id ) { return $id; }
    if ( function_exists( 'ianproject_media_source' ) ) {
        $file = ianproject_media_source( $url );
        if ( is_string( $file ) ) { $created = 0; $new = ianproject_media_copy( $file, $created ); if ( ! is_wp_error( $new ) ) { return attachment_url_to_postid( $new ); } }
    }
    return 0;
}
function ianc_migrate_product( $id ) {
    $post = get_post( $id ); if ( ! $post || 'ian_product' !== $post->post_type ) { return true; }
    if ( ! class_exists( 'WC_Product_Simple' ) ) { return new WP_Error( 'ian_woo_missing', '请先安装并启用兼容的 WooCommerce。' ); }
    $data = get_post_meta( $id, '_ian_product_data', true ); $data = is_array( $data ) ? $data : array();
    $old_terms = wp_get_post_terms( $id, 'ian_product_category', array( 'fields' => 'ids' ) ); if ( is_wp_error( $old_terms ) ) { $old_terms = array(); }
    if ( ! metadata_exists( 'post', $id, '_ian_catalog_backup' ) ) {
        $keys = array( '_sku', '_price', '_regular_price', '_sale_price', '_stock', '_stock_status', '_manage_stock', '_product_image_gallery', '_thumbnail_id', '_product_attributes' ); $meta = array();
        foreach ( $keys as $key ) { $meta[ $key ] = get_post_meta( $id, $key, false ); }
        add_post_meta( $id, '_ian_catalog_backup', wp_slash( array( 'post' => array_intersect_key( get_object_vars( $post ), array_flip( array( 'ID', 'post_type', 'post_status', 'post_title', 'post_content', 'post_excerpt', 'post_name', 'post_parent', 'menu_order', 'post_date', 'post_date_gmt' ) ) ), 'terms' => $old_terms, 'wc_meta' => $meta, 'data' => $data ) ), true );
    }
    $content = $post->post_content;
    if ( function_exists( 'ianproject_media_rewrite' ) ) {
        $created = 0; $errors = array(); $content = ianproject_media_rewrite( $content, $created, $errors ); $data = ianproject_media_rewrite( $data, $created, $errors );
        if ( $errors ) { return new WP_Error( 'ian_product_media', implode( '；', array_unique( $errors ) ) ); }
    }
    $cats = array_filter( array_map( 'ianc_migrate_term', $old_terms ) ); $images = array();
    foreach ( array_merge( array( $data['image'] ?? '' ), is_array( $data['images'] ?? null ) ? $data['images'] : array() ) as $image ) {
        if ( is_array( $image ) ) { $image = $image['src'] ?? $image['url'] ?? ''; }
        $attachment = ianc_local_attachment( $image ); if ( $attachment ) { $images[] = $attachment; }
    }
    $images = array_values( array_unique( $images ) );
    $r = wp_update_post( wp_slash( array( 'ID' => $id, 'post_type' => 'product', 'post_content' => $content ) ), true ); if ( is_wp_error( $r ) ) { return $r; } clean_post_cache( $id );
    try {
        $product = new WC_Product_Simple( $id ); $sku = sanitize_text_field( $data['code'] ?? get_post_meta( $id, '_ian_sku', true ) );
        if ( $sku ) { $collision = wc_get_product_id_by_sku( $sku ); $product->set_sku( $collision && $collision !== $id ? $sku . '-IAN-' . $id : $sku ); update_post_meta( $id, '_ian_sku', $sku ); }
        $product->set_category_ids( array_map( 'absint', $cats ) );
        if ( ! $product->get_attributes() && is_array( $data['specifications'] ?? null ) ) {
            $attributes = array();
            foreach ( $data['specifications'] as $label => $value ) {
                if ( is_array( $value ) ) { $label = $value['label'] ?? $value['name'] ?? $label; $value = $value['value'] ?? ''; }
                if ( ! is_string( $label ) || ! is_scalar( $value ) || '' === (string) $value ) { continue; }
                $attribute = new WC_Product_Attribute(); $attribute->set_name( sanitize_text_field( $label ) ); $attribute->set_options( array( sanitize_text_field( (string) $value ) ) ); $attribute->set_visible( true ); $attributes[] = $attribute;
            }
            $product->set_attributes( $attributes );
        }
        if ( ! $product->get_image_id() && $images ) { $product->set_image_id( array_shift( $images ) ); }
        $product->set_gallery_image_ids( array_values( array_unique( array_diff( array_merge( $product->get_gallery_image_ids(), $images ), array( $product->get_image_id() ) ) ) ) );
        $currency = strtoupper( sanitize_text_field( $data['currency'] ?? 'USD' ) );
        update_post_meta( $id, '_ian_original_currency', $currency );
        update_post_meta( $id, '_ian_original_price', $data['price'] ?? '' );
        update_post_meta( $id, '_ian_price_max', $data['priceMax'] ?? '' ); update_post_meta( $id, '_ian_price_unit', sanitize_text_field( $data['unit'] ?? $data['priceUnit'] ?? '' ) );
        if ( $currency === get_woocommerce_currency() && isset( $data['price'] ) && is_numeric( $data['price'] ) ) { $product->set_regular_price( wc_format_decimal( $data['price'] ) ); $product->set_price( wc_format_decimal( $data['price'] ) ); }
        $product->save();
        if ( 'publish' === $product->get_status() && in_array( $product->get_catalog_visibility(), array( 'visible', 'catalog' ), true ) && $product->get_image_id() ) { foreach ( $cats as $term ) { if ( ! get_term_meta( $term, 'thumbnail_id', true ) ) { update_term_meta( $term, 'thumbnail_id', $product->get_image_id() ); } } }
        update_post_meta( $id, '_ian_product_data', wp_slash( $data ) ); update_post_meta( $id, '_ian_catalog_migrated', '3.0.0' ); wc_delete_product_transients( $id );
        return $id;
    } catch ( Throwable $error ) {
        wp_update_post( array( 'ID' => $id, 'post_type' => 'ian_product' ) ); clean_post_cache( $id );
        return new WP_Error( 'ian_product_migrate', $error->getMessage() );
    }
}
function ianc_restore_product( $id ) {
    $backup = get_post_meta( $id, '_ian_catalog_backup', true ); if ( ! is_array( $backup ) || empty( $backup['post'] ) ) { return new WP_Error( 'ian_backup', '找不到产品备份。' ); }
    $r = wp_update_post( wp_slash( $backup['post'] ), true ); if ( is_wp_error( $r ) ) { return $r; }
    foreach ( $backup['wc_meta'] as $key => $values ) { delete_post_meta( $id, $key ); foreach ( $values as $value ) { add_post_meta( $id, $key, wp_slash( $value ) ); } }
    update_post_meta( $id, '_ian_product_data', wp_slash( $backup['data'] ) ); wp_set_post_terms( $id, $backup['terms'], 'ian_product_category' ); wp_set_post_terms( $id, array(), 'product_cat' );
    delete_post_meta( $id, '_ian_catalog_migrated' ); wc_delete_product_transients( $id ); clean_post_cache( $id ); return true;
}
