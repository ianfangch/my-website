<?php
defined( 'ABSPATH' ) || exit;
function ian3_contact_actions( $html ) {
    if ( is_admin() || is_front_page() || is_page( ian3_id( 'home' ) ) || is_page( ian3_id( 'contact' ) ) || ! str_contains( $html, '<a' ) ) { return $html; }
    $contact = ian3_url( 'contact' );
    $html = preg_replace_callback( '~<a\b([^>]*)>(.*?)</a>~is', function ( $match ) use ( $contact ) {
        $label = trim( wp_strip_all_tags( $match[2] ) ); $attrs = $match[1];
        $button = preg_match( '~class=["\'][^"\']*(?:btn|button|ip-inline-link)[^"\']*["\']~i', $attrs );
        $catalogue = preg_match( '~^(?:view|request|browse|download|get|ask for)\b.*\bcatalog(?:ue)?s?\b~i', $label );
        $own_contact = $button && ( preg_match( '~href=["\'](?:mailto:|https?://(?:wa\.me|api\.whatsapp\.com)/)~i', $attrs ) || preg_match( '~^(?:contact|discuss|request|email|start|check installation)\b~i', $label ) );
        if ( ! $catalogue && ! $own_contact ) { return $match[0]; }
        $class = preg_match( '~class=["\']([^"\']*)["\']~i', $attrs, $m ) ? $m[1] : 'ip-button';
        return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $contact ) . '">Contact</a>';
    }, $html );
    // Collapse the old paired catalogue/email buttons within each paragraph into one Contact action.
    return preg_replace_callback( '~<p\b([^>]*)>(.*?)</p>~is', function ( $p ) use ( $contact ) {
        $seen = false;
        $inner = preg_replace_callback( '~<a\b([^>]*)>Contact</a>~i', function ( $a ) use ( &$seen, $contact ) {
            if ( ! str_contains( html_entity_decode( $a[1], ENT_QUOTES ), $contact ) ) { return $a[0]; }
            if ( $seen ) { return ''; } $seen = true; return $a[0];
        }, $p[2] );
        return '<p' . $p[1] . '>' . $inner . '</p>';
    }, $html );
}
add_filter( 'render_block', 'ian3_contact_actions', 40 );
add_filter( 'the_content', 'ian3_contact_actions', 40 );
