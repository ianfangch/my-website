<?php
defined( 'ABSPATH' ) || exit;
/** Basic native WooCommerce display remains usable if the optional catalogue module is inactive. */
function ian3_saved_product_details( $id, $has_native_attributes = false ) {
    $data = get_post_meta( $id, '_ian_product_data', true ); if ( ! is_array( $data ) ) { return ''; }
    $html = ''; $highlights = array_filter( (array) ( $data['highlights'] ?? array() ), 'is_scalar' );
    if ( $highlights ) { $html .= '<h2>Product details</h2><ul>'; foreach ( $highlights as $item ) { $html .= '<li>' . esc_html( $item ) . '</li>'; } $html .= '</ul>'; }
    $models = array(); foreach ( $data['catalogueRows'] ?? array() as $row ) { if ( is_array( $row ) ) { foreach ( $row['models'] ?? array() as $model ) { if ( is_array( $model ) ) { $models[] = $model; } } } }
    if ( $models ) {
        $fields = array( 'code' => 'Model', 'size' => 'Dimensions', 'cutout' => 'Cutout', 'material' => 'Material', 'note' => 'Notes' ); $used = array();
        foreach ( $fields as $key => $label ) { foreach ( $models as $model ) { if ( isset( $model[ $key ] ) && is_scalar( $model[ $key ] ) && '' !== (string) $model[ $key ] ) { $used[ $key ] = $label; break; } } }
        if ( $used ) { $html .= '<h2>Available models</h2><div class="ian-spec-scroll"><table class="ian-model-table"><thead><tr>'; foreach ( $used as $label ) { $html .= '<th scope="col">' . esc_html( $label ) . '</th>'; } $html .= '</tr></thead><tbody>'; foreach ( $models as $model ) { $html .= '<tr>'; foreach ( $used as $key => $label ) { $html .= '<td>' . esc_html( is_scalar( $model[ $key ] ?? '' ) ? (string) ( $model[ $key ] ?? '' ) : '' ) . '</td>'; } $html .= '</tr>'; } $html .= '</tbody></table></div>'; }
    }
    if ( ! $has_native_attributes && is_array( $data['specifications'] ?? null ) && $data['specifications'] ) { $html .= '<h2>Specifications</h2><dl class="ian-product-facts">'; foreach ( $data['specifications'] as $label => $value ) { if ( is_scalar( $value ) ) { $html .= '<div><dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( (string) $value ) . '</dd></div>'; } } $html .= '</dl>'; }
    return $html;
}
function ian3_product_detail() {
    if ( ! function_exists( 'wc_get_product' ) ) { return ''; }
    $id = get_queried_object_id(); $product = wc_get_product( $id ); if ( ! $product ) { return ''; }
    $description = get_post_field( 'post_content', $id );
    if ( has_block( 'core/post-title', $description ) ) { return '<main class="ian-legacy-product">' . apply_filters( 'the_content', $description ) . '<div class="ip-shell py-4">' . ian3_link( 'contact', 'Contact', 'ip-button' ) . '</div></main>'; }
    $images = ''; $ids = array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) );
    foreach ( $ids as $index => $image ) { $url = wp_get_attachment_image_url( $image, 'full' ); $images .= '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . wp_get_attachment_image( $image, 'large', false, array( 'loading' => $index ? 'lazy' : 'eager', 'decoding' => 'async' ) ) . '</a>'; }
    $body = apply_filters( 'the_content', $description );
    if ( ! trim( wp_strip_all_tags( $body ) ) ) { $body .= ian3_saved_product_details( $id, $product->has_attributes() ); }
    if ( $product->has_attributes() || $product->has_weight() || $product->has_dimensions() ) { ob_start(); wc_display_product_attributes( $product ); $specs = ob_get_clean(); if ( $specs ) { $body .= '<h2>Specifications</h2>' . $specs; } }
    $price = function_exists( 'ianc_price_html' ) ? ianc_price_html( $id ) : '<div class="catalog-price"><strong>Request a Quote</strong></div>';
    return '<main class="ip-page ian-product-page"><section class="ip-detail-head"><div class="ip-shell"><nav class="ip-breadcrumb" aria-label="Breadcrumb"><a href="' . esc_url( ian3_url( 'products' ) ) . '">Products</a><span>/</span><span>' . esc_html( $product->get_name() ) . '</span></nav><div class="ip-detail-title"><span class="ip-kicker">' . esc_html( $product->get_sku() ) . '</span><h1>' . esc_html( $product->get_name() ) . '</h1><p>' . esc_html( wp_strip_all_tags( $product->get_short_description() ) ) . '</p></div></div></section><div class="ip-shell ian-product-layout"><div class="ian-product-gallery">' . ( $images ?: $product->get_image() ) . '</div><aside class="ian-product-summary">' . $price . '<p>Confirm specifications, quantities and delivery terms with IanProject.</p>' . ian3_link( 'contact', 'Contact', 'ip-button' ) . '</aside></div><section class="ip-shell ip-article ian-product-description">' . $body . '</section></main>';
}
function ian3_basic_catalogue() {
    if ( ! function_exists( 'wc_get_products' ) ) { return '<div class="catalog-empty"><h2>Let’s find the products for your project.</h2>' . ian3_link( 'contact', 'Contact', 'ip-button' ) . '</div>'; }
    $page = max( 1, absint( $_GET['catalog_page'] ?? 1 ) ); $args = array( 'status' => 'publish', 'visibility' => 'catalog', 'limit' => 12, 'page' => $page, 'paginate' => true );
    if ( isset( $_GET['category'] ) && is_scalar( $_GET['category'] ) ) { $args['category'] = array( sanitize_title( wp_unslash( $_GET['category'] ) ) ); }
    $hidden_terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'fields' => 'ids', 'meta_query' => array( array( 'key' => '_ian_hide_catalog', 'value' => '1' ) ) ) );
    if ( ! is_wp_error( $hidden_terms ) && $hidden_terms ) { $args['exclude'] = get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'tax_query' => array( array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $hidden_terms, 'include_children' => true ) ) ) ); }
    $results = wc_get_products( $args ); $html = '<section class="ian-catalog"><div class="catalog-grid">';
    foreach ( $results->products as $product ) { $html .= '<article class="catalog-card"><a class="catalog-card-image" href="' . esc_url( get_permalink( $product->get_id() ) ) . '">' . $product->get_image( 'woocommerce_thumbnail' ) . '</a><div class="catalog-card-body"><p class="catalog-card-meta">' . esc_html( $product->get_sku() ) . '</p><h3><a href="' . esc_url( get_permalink( $product->get_id() ) ) . '">' . esc_html( $product->get_name() ) . '</a></h3><p>' . esc_html( wp_trim_words( wp_strip_all_tags( $product->get_short_description() ), 26 ) ) . '</p><a class="catalog-details" href="' . esc_url( get_permalink( $product->get_id() ) ) . '">View details ↗</a></div></article>'; }
    $html .= '</div>'; if ( ! $results->total ) { $html .= '<div class="catalog-empty">' . ian3_link( 'contact', 'Contact', 'ip-button' ) . '</div>'; }
    if ( $results->max_num_pages > 1 ) { $html .= '<nav class="ian-pagination" aria-label="Product pages">' . paginate_links( array( 'base' => add_query_arg( 'catalog_page', '%#%' ), 'current' => $page, 'total' => $results->max_num_pages ) ) . '</nav>'; }
    return $html . '</section>';
}
add_action( 'admin_notices', function () { if ( current_user_can( 'activate_plugins' ) && class_exists( 'WooCommerce' ) && ! function_exists( 'ianc_visible_terms' ) ) { echo '<div class="notice notice-warning"><p>IanProject 产品目录模块未启用：目前使用基础产品展示。请在“插件”中启用新版 IanProject 产品目录，恢复分类显示控制、型号搜索与完整目录功能。产品数据未删除。</p></div>'; } } );
