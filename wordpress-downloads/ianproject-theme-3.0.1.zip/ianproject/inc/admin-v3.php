<?php
defined( 'ABSPATH' ) || exit;
add_action( 'admin_menu', function () { add_theme_page( 'IanProject 整站设置', 'IanProject 设置', 'manage_options', 'ianproject-setup', 'ian3_admin_page' ); } );
function ian3_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    if ( isset( $_POST['ian3_save_visibility'] ) ) {
        check_admin_referer( 'ian3_visibility' ); $values = array();
        foreach ( array( 'products', 'project', 'insights', 'about', 'factory', 'showroom', 'services' ) as $key ) { $values[ $key ] = isset( $_POST['ian3_show'][ $key ] ) ? 1 : 0; }
        update_option( 'ian3_visibility', $values, false ); do_action( 'litespeed_purge_all' ); echo '<div class="notice notice-success"><p>显示设置已保存，导航、页内入口及页尾已同步。</p></div>';
    }
    if ( isset( $_POST['ian3_restore'] ) ) {
        check_admin_referer( 'ian3_restore' ); $errors = array();
        foreach ( get_posts( array( 'post_type' => array( 'page', 'post', 'ian_insight', 'wp_template', 'wp_template_part' ), 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'meta_key' => '_ian_v3_backup', 'posts_per_page' => -1 ) ) as $post ) {
            $backup = get_post_meta( $post->ID, '_ian_v3_backup', true ); if ( ! is_array( $backup ) ) { continue; }
            $source = $backup['_source'] ?? ''; $cats = $backup['_categories'] ?? array(); unset( $backup['_source'], $backup['_categories'] );
            $r = wp_update_post( wp_slash( $backup ), true ); if ( is_wp_error( $r ) ) { $errors[] = $r->get_error_message(); continue; }
            update_post_meta( $post->ID, '_ian_source', $source ); if ( 'post' === $backup['post_type'] ) { wp_set_post_categories( $post->ID, $cats ); }
            delete_post_meta( $post->ID, '_ian3_applied_release' );
        }
        $front = get_option( 'ian3_previous_front' ); if ( is_array( $front ) ) { foreach ( $front as $key => $value ) { update_option( $key, $value ); } }
        if ( ! $errors ) { delete_option( 'ian3_install_tasks' ); delete_option( 'ian3_install_offset' ); delete_option( 'ian3_install_complete' ); }
        flush_rewrite_rules( false ); do_action( 'litespeed_purge_all' ); echo '<div class="notice ' . ( $errors ? 'notice-error' : 'notice-success' ) . '"><p>' . esc_html( $errors ? implode( '；', $errors ) : '已恢复升级前的正文和首页设置。新增页面、文章和媒体仍保留；产品迁移在产品模块内单独恢复。' ) . '</p></div>';
    }
    $settings = (array) get_option( 'ian3_visibility', array() );
    ?><div class="wrap" style="max-width:1000px"><h1>IanProject 3.0 整站设置</h1>
    <p>统一页眉与页尾、已确认首页、Project / Insights 原生文章、About 四页，以及精简 Contact 表单。主题不附带产品数据。产品使用独立模块及 WooCommerce 管理。</p>
    <h2>1. 安装 / 升级已确认页面</h2><p>首次执行会备份被替换的页面和旧行业文章，再分批导入。已有 Contact 页面正文不改动，仅共享表单更新为五项；已导入后的人工编辑会保留。旧首页和无关页面不会删除。完成后会将新版 Home 设为首页。</p>
    <p><button id="ian3-start" class="button button-primary">安装 / 升级已确认整站</button> <span id="ian3-status" role="status" aria-live="polite"><?php echo get_option( 'ian3_install_complete' ) ? '已安装 3.0；重复执行不会覆盖后续人工编辑。' : ''; ?></span></p><progress id="ian3-progress" value="0" max="100" style="width:100%;display:none"></progress>
    <?php if ( get_posts( array( 'post_type' => 'ian_product', 'posts_per_page' => 1 ) ) && ! function_exists( 'ianc_migrate_product' ) ) : ?><p><strong>检测到旧产品：请安装兼容的 WooCommerce 和 3.0 产品模块后，在产品模块中迁移。旧产品不会删除。</strong></p><?php endif; ?>
    <h2>2. 页面入口显示</h2><p>关闭后同步隐藏导航、页内导航、关联卡片入口和页尾链接。仅隐藏入口不改变页面发布状态，原链接仍可能访问；不想公开时请将页面保存为草稿。只显示 IanProject 时，About 直接进入公司页并自动收起箭头。</p>
    <form method="post"><?php wp_nonce_field( 'ian3_visibility' ); ?><table class="form-table"><tbody><?php foreach ( array( 'products', 'project', 'insights', 'about', 'factory', 'showroom', 'services' ) as $key ) : ?><tr><th><?php echo esc_html( ian3_roles()[ $key ] ); ?></th><td><label><input type="checkbox" name="ian3_show[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( ! isset( $settings[ $key ] ) || $settings[ $key ] ); ?>>显示入口</label> <?php $id = ian3_id( $key ); if ( $id ) { echo '<a href="' . esc_url( get_edit_post_link( $id ) ) . '">编辑页面</a> · ' . esc_html( get_post_status( $id ) ); } ?></td></tr><?php endforeach; ?></tbody></table><button name="ian3_save_visibility" class="button button-primary">保存显示设置</button></form>
    <h2>3. 增加工厂 / 展厅</h2><p>使用原生子页面，支持国家、城市、地址、产品类别、特色图片、相册及多个视频。草稿不进入目录；发布后自动显示，可按地区筛选。</p>
    <?php foreach ( array( 'factory' => '新增工厂资料', 'showroom' => '新增展厅资料' ) as $kind => $label ) { echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ian3_add_profile&kind=' . $kind ), 'ian3_profile' ) ) . '">' . esc_html( $label ) . '</a> '; } ?>
    <h2>4. 联系方式和产品</h2><p><a class="button" href="<?php echo esc_url( admin_url( 'options-general.php?page=ianproject-contacts' ) ); ?>">统一修改全站联系方式</a> <?php if ( class_exists( 'WooCommerce' ) ) : ?><a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=product&page=ian-catalog-settings' ) ); ?>">产品目录设置 / 旧产品迁移</a><?php endif; ?></p><p>文章 → 新增：选择 Project 或 Insights 分类，设置特色图片后发布。产品分类的显示开关位于 WooCommerce 产品 → 分类。空分类自动隐藏。客户评价仍在 Home 编辑器填写，空评价不显示。</p>
    <h2>5. 旧主题图片迁移</h2><p>如果旧正文或旧产品仍引用其他主题文件夹，请先迁移图片，再删除旧主题。</p><button id="ian-media-start" class="button">迁移并检查旧主题图片</button><p id="ian-media-status" role="status"></p>
    <details style="margin-top:30px"><summary>恢复本次页面升级前的备份</summary><p>会恢复已备份的原正文和首页设置；新增数据不删除，产品迁移单独恢复。</p><form method="post"><?php wp_nonce_field( 'ian3_restore' ); ?><button class="button" name="ian3_restore" value="1">恢复升级前页面</button></form></details>
    </div><script>(()=>{const b=document.getElementById('ian3-start'),s=document.getElementById('ian3-status'),p=document.getElementById('ian3-progress');b.addEventListener('click',async()=>{b.disabled=true;p.style.display='block';try{while(true){const r=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:new URLSearchParams({action:'ian3_install',nonce:<?php echo wp_json_encode( wp_create_nonce( 'ian3_install' ) ); ?>})});const j=await r.json();if(!j.success)throw Error(j.data?.message||'安装失败');const d=j.data;p.value=100*d.offset/Math.max(1,d.total);s.textContent='已处理 '+d.offset+' / '+d.total;if(d.done){s.textContent='整站安装完成。刷新页面可编辑页面、显示开关和资料。';break;}}}catch(e){s.textContent='已暂停：'+e.message+'。可重试，已完成的数据不会重复创建。';}finally{b.disabled=false;}});})();</script><?php
}
add_action( 'admin_notices', function () { if ( current_user_can( 'manage_options' ) && ! get_option( 'ian3_install_complete' ) ) { echo '<div class="notice notice-info"><p>IanProject 3.0：请在 <a href="' . esc_url( admin_url( 'themes.php?page=ianproject-setup' ) ) . '">外观 → IanProject 设置</a> 安装 / 升级已确认页面。主题启用不会自动覆盖正文。</p></div>'; } } );
