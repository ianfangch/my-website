<?php
defined( 'ABSPATH' ) || exit;
function ian3_manifest() { static $data; if ( null === $data ) { $data = json_decode( file_get_contents( get_theme_file_path( 'data/release.json' ) ), true ); } return is_array( $data ) ? $data : array(); }
function ianproject_imported_post( $source, $type = 'page' ) { $items = get_posts( array( 'post_type' => $type, 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'meta_key' => '_ian_source', 'meta_value' => $source, 'posts_per_page' => 1, 'orderby' => 'ID', 'order' => 'ASC' ) ); return $items[0] ?? null; }
function ianproject_homepage_id() { return ian3_id( 'home' ) ?: absint( get_option( 'ian_homepage_id' ) ); }
function ian3_backup_post( $id ) {
    if ( metadata_exists( 'post', $id, '_ian_v3_backup' ) ) { return; }
    $post = get_post( $id ); if ( ! $post ) { return; }
    $fields = array_intersect_key( get_object_vars( $post ), array_flip( array( 'ID', 'post_type', 'post_status', 'post_title', 'post_content', 'post_excerpt', 'post_name', 'post_parent', 'menu_order', 'post_date', 'post_date_gmt' ) ) );
    $fields['_source'] = get_post_meta( $id, '_ian_source', true ); $fields['_categories'] = wp_get_post_categories( $id );
    add_post_meta( $id, '_ian_v3_backup', wp_slash( $fields ), true ); wp_save_post_revision( $id );
}
function ian3_content_assets( $content ) {
    $errors = array(); $created = 0; $content = ianproject_tokens( $content );
    $content = ianproject_media_rewrite( $content, $created, $errors );
    if ( $errors ) { return new WP_Error( 'ian_assets', implode( '；', array_unique( $errors ) ) ); }
    return $content;
}
function ian3_featured_image( $id, $source ) {
    if ( ! $source || has_post_thumbnail( $id ) ) { return; }
    $errors = array(); $created = 0; $url = ianproject_media_rewrite( ianproject_tokens( $source ), $created, $errors );
    if ( $errors ) { return; }
    $attachment = attachment_url_to_postid( $url ); if ( $attachment ) { set_post_thumbnail( $id, $attachment ); }
}
function ian3_categories() {
    $ids = array(); foreach ( array( 'insights' => 'Insights', 'project' => 'Project' ) as $slug => $name ) {
        $term = get_term_by( 'slug', $slug, 'category' );
        if ( $term ) { $ids[ $slug ] = (int) $term->term_id; }
        else { $term = wp_insert_term( $name, 'category', array( 'slug' => $slug ) ); if ( ! is_wp_error( $term ) ) { $ids[ $slug ] = (int) $term['term_id']; } }
    }
    if ( isset( $ids['insights'] ) ) { update_option( 'default_category', $ids['insights'] ); }
    return $ids;
}
function ian3_migrate_insight( $id ) {
    $p = get_post( $id ); if ( ! $p || 'ian_insight' !== $p->post_type ) { return true; }
    ian3_backup_post( $id ); $terms = ian3_categories();
    $content = ian3_content_assets( $p->post_content ); if ( is_wp_error( $content ) ) { return $content; }
    $result = wp_update_post( wp_slash( array( 'ID' => $id, 'post_type' => 'post', 'post_content' => $content ) ), true ); if ( is_wp_error( $result ) ) { return $result; }
    wp_set_post_categories( $id, array( $terms['insights'] ) ); update_post_meta( $id, '_ian_v3_legacy_insight', 1 ); update_post_meta( $id, '_ian3_applied_release', '3.0.0' );
    return true;
}
function ian3_apply_record( $record, $kind ) {
    $page = 'pages' === $kind; $type = $page ? 'page' : 'post'; $source = $record['source'];
    $existing = ianproject_imported_post( $source, $type );
    if ( ! $existing && ! $page ) { $legacy = ianproject_imported_post( $source, 'ian_insight' ); if ( $legacy ) { $r = ian3_migrate_insight( $legacy->ID ); if ( is_wp_error( $r ) ) { return $r; } $existing = get_post( $legacy->ID ); } }
    if ( $existing && get_post_meta( $existing->ID, '_ian3_applied_release', true ) ) {
        if ( $page ) { $map = (array) get_option( 'ian3_pages', array() ); $map[ $record['role'] ] = $existing->ID; update_option( 'ian3_pages', $map, false ); }
        else { foreach ( $record['meta'] ?? array() as $key => $value ) { if ( ! metadata_exists( 'post', $existing->ID, $key ) ) { update_post_meta( $existing->ID, $key, sanitize_text_field( $value ) ); } } }
        return $existing->ID;
    }
    $data = array( 'post_type' => $type, 'post_title' => $record['title'], 'post_name' => $record['slug'], 'post_status' => $record['status'] ?? 'publish', 'post_excerpt' => $record['summary'] ?? $record['description'] ?? '', 'comment_status' => 'closed', 'ping_status' => 'closed', 'menu_order' => (int) ( $record['menu_order'] ?? 0 ) );
    // An existing Contact page is left byte-for-byte intact; its shared form shortcode supplies the new fields.
    if ( $existing && $page && 'contact' === $record['role'] ) { $data = array( 'ID' => $existing->ID ); }
    else {
        $content = ian3_content_assets( $record['content'] ); if ( is_wp_error( $content ) ) { return $content; } $data['post_content'] = $content;
        if ( $existing ) { ian3_backup_post( $existing->ID ); $data['ID'] = $existing->ID; $data['post_name'] = $existing->post_name; $data['post_status'] = $existing->post_status; }
        elseif ( get_page_by_path( $record['slug'], OBJECT, $type ) ) { $data['post_name'] = 'ianproject-' . $record['slug']; }
    }
    $id = isset( $data['ID'] ) ? wp_update_post( wp_slash( $data ), true ) : wp_insert_post( wp_slash( $data ), true ); if ( is_wp_error( $id ) ) { return $id; }
    if ( ! $existing ) { update_post_meta( $id, '_ian3_created', 1 ); }
    update_post_meta( $id, '_ian_source', $source ); update_post_meta( $id, '_ian3_applied_release', '3.0.0' );
    if ( ! empty( $record['description'] ) ) { update_post_meta( $id, '_ian_description', sanitize_text_field( $record['description'] ) ); }
    if ( $page ) {
        $map = (array) get_option( 'ian3_pages', array() ); $map[ $record['role'] ] = $id; update_option( 'ian3_pages', $map, false );
        if ( 'contact' !== $record['role'] || ! $existing ) { delete_post_meta( $id, '_elementor_edit_mode' ); update_post_meta( $id, '_wp_page_template', 'default' ); }
    } else {
        $cats = ian3_categories(); wp_set_post_categories( $id, array( $cats[ $record['category'] ] ) );
        foreach ( $record['meta'] ?? array() as $key => $value ) { update_post_meta( $id, $key, sanitize_text_field( $value ) ); }
        ian3_featured_image( $id, $record['featuredImage'] ?? '' );
    }
    return $id;
}
function ian3_create_profile( $kind, $seed = false ) {
    $kind = 'showroom' === $kind ? 'showroom' : 'factory'; $parent = ian3_id( $kind ); if ( ! $parent ) { return new WP_Error( 'ian_parent', '请先安装网站页面。' ); }
    if ( $seed ) { $found = get_posts( array( 'post_type' => 'page', 'post_parent' => $parent, 'post_status' => array( 'draft', 'publish', 'private', 'pending' ), 'posts_per_page' => 1 ) ); if ( $found ) { return $found[0]->ID; } }
    $pattern = null; foreach ( ian3_manifest()['patterns'] ?? array() as $p ) { if ( $p['slug'] === $kind . '-profile' ) { $pattern = $p; break; } }
    if ( ! $pattern ) { return new WP_Error( 'ian_pattern', '找不到资料页模板。' ); }
    $content = ian3_content_assets( $pattern['content'] ); if ( is_wp_error( $content ) ) { return $content; }
    return wp_insert_post( wp_slash( array( 'post_type' => 'page', 'post_status' => 'draft', 'post_parent' => $parent, 'post_title' => 'factory' === $kind ? '工厂资料 — 待填写' : '展厅资料 — 待填写', 'post_content' => $content, 'comment_status' => 'closed' ) ), true );
}
function ian3_begin_install() {
    if ( ! get_option( 'ian3_previous_front' ) ) { add_option( 'ian3_previous_front', array( 'page_on_front' => get_option( 'page_on_front' ), 'show_on_front' => get_option( 'show_on_front' ), 'permalink_structure' => get_option( 'permalink_structure' ) ), '', false ); }
    $tasks = array();
    foreach ( get_posts( array( 'post_type' => 'ian_insight', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'posts_per_page' => -1, 'fields' => 'ids' ) ) as $id ) { $tasks[] = array( 'legacy_insight', $id ); }
    foreach ( array( 'pages', 'posts' ) as $group ) { foreach ( ian3_manifest()[ $group ] ?? array() as $index => $record ) { $tasks[] = array( $group, $index ); } }
    if ( function_exists( 'ianc_migrate_product' ) && class_exists( 'WooCommerce' ) ) { foreach ( get_posts( array( 'post_type' => 'ian_product', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ), 'posts_per_page' => -1, 'fields' => 'ids' ) ) as $id ) { $tasks[] = array( 'legacy_product', $id ); } }
    $tasks[] = array( 'profile', 'factory' ); $tasks[] = array( 'profile', 'showroom' ); $tasks[] = array( 'finish', 0 );
    update_option( 'ian3_install_tasks', $tasks, false ); update_option( 'ian3_install_offset', 0, false );
    return count( $tasks );
}
function ian3_finish_install() {
    $home = ian3_id( 'home' ); if ( $home && 'publish' === get_post_status( $home ) ) { update_option( 'page_on_front', $home ); update_option( 'show_on_front', 'page' ); update_option( 'ian_homepage_id', $home ); }
    if ( ! get_option( 'permalink_structure' ) ) { update_option( 'permalink_structure', '/%category%/%postname%/' ); }
    // Saved old body templates must not override the newly approved pages. Keep them as backed-up drafts.
    $templates = get_posts( array( 'post_type' => array( 'wp_template', 'wp_template_part' ), 'post_status' => 'publish', 'posts_per_page' => -1, 'tax_query' => array( array( 'taxonomy' => 'wp_theme', 'field' => 'slug', 'terms' => get_stylesheet() ) ) ) );
    foreach ( $templates as $post ) { ian3_backup_post( $post->ID ); wp_update_post( array( 'ID' => $post->ID, 'post_status' => 'draft' ) ); }
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    foreach ( (array) get_option( 'active_plugins', array() ) as $file ) { if ( in_array( basename( $file ), array( 'ianproject-site-fixes.php', 'ianproject-site.php' ), true ) && str_starts_with( get_plugin_data( WP_PLUGIN_DIR . '/' . $file, false, false )['Name'] ?? '', 'IanProject' ) ) { deactivate_plugins( $file, true ); } }
    update_option( 'ian3_install_complete', '3.0.0', false ); flush_rewrite_rules( false ); do_action( 'litespeed_purge_all' );
    return true;
}
function ian3_install_step() {
    $tasks = get_option( 'ian3_install_tasks' ); if ( ! is_array( $tasks ) || ! $tasks ) { ian3_begin_install(); $tasks = get_option( 'ian3_install_tasks' ); }
    $offset = absint( get_option( 'ian3_install_offset' ) );
    if ( $offset >= count( $tasks ) ) { return array( 'done' => true, 'offset' => $offset, 'total' => count( $tasks ) ); }
    list( $kind, $value ) = $tasks[ $offset ];
    if ( 'legacy_insight' === $kind ) { $result = ian3_migrate_insight( $value ); }
    elseif ( 'legacy_product' === $kind ) { $result = ianc_migrate_product( $value ); }
    elseif ( 'profile' === $kind ) { $result = ian3_create_profile( $value, true ); }
    elseif ( 'finish' === $kind ) { $result = ian3_finish_install(); }
    else { $result = ian3_apply_record( ian3_manifest()[ $kind ][ $value ], $kind ); }
    if ( is_wp_error( $result ) ) { return $result; }
    update_option( 'ian3_install_offset', ++$offset, false );
    return array( 'done' => $offset >= count( $tasks ), 'offset' => $offset, 'total' => count( $tasks ), 'step' => $kind );
}
add_action( 'wp_ajax_ian3_install', function () {
    if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => '没有安装权限。' ), 403 ); }
    check_ajax_referer( 'ian3_install', 'nonce' );
    $result = ian3_install_step(); if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 ); } wp_send_json_success( $result );
} );
add_action( 'admin_post_ian3_add_profile', function () {
    if ( ! current_user_can( 'edit_pages' ) ) { wp_die( '没有编辑权限。', 403 ); } check_admin_referer( 'ian3_profile' );
    $result = ian3_create_profile( sanitize_key( $_GET['kind'] ?? '' ) ); if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ) ); } wp_safe_redirect( get_edit_post_link( $result, 'raw' ) ); exit;
} );

add_action( 'template_redirect', function () {
    if ( is_admin() || is_preview() || is_feed() ) { return; }
    $path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' ); $base = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' ); if ( $base && str_starts_with( $path, $base . '/' ) ) { $path = substr( $path, strlen( $base ) + 1 ); }
    $targets = array( 'custom-solutions' => '#custom-solutions', 'quality-process' => '#working-together', 'catalogues' => '#catalogue-download' );
    $clean = preg_replace( '/\.html$/', '', $path ); if ( isset( $targets[ $clean ] ) && ian3_id( 'home' ) ) { wp_safe_redirect( ian3_url( 'home' ) . $targets[ $clean ], 301 ); exit; }
    // Old article/product addresses keep a permanent redirect when native permalinks differ.
    if ( preg_match( '~^(insights|products)/([^/]+?)(?:\.html)?/?$~', $path, $m ) ) {
        $type = 'insights' === $m[1] ? 'post' : 'product'; $item = get_page_by_path( sanitize_title( $m[2] ), OBJECT, $type );
        if ( $item && 'publish' === $item->post_status ) { $target = get_permalink( $item ); $current = home_url( '/' . $path . '/' ); if ( untrailingslashit( $target ) !== untrailingslashit( $current ) ) { wp_safe_redirect( $target, 301 ); exit; } }
    }
}, 2 );
