(()=>{
 const form=document.getElementById('quote-builder-form'),status=document.getElementById('quote-builder-status');if(!form)return;
 const config=window.IAN_CONTACT||{},website=form.elements.website;
 website.addEventListener('input',()=>website.setCustomValidity(''));
 const query=new URLSearchParams(location.search),service=query.get('service'),allowed=['Design','Quality Inspection','Shipping','Installation Support','After-Sales Support','Factory visit','Showroom visit'];
 if(!form.elements.requirements.value){if(config.productName)form.elements.requirements.value='Product name: '+config.productName+'\nModel: '+(config.productModel||'')+'\nQuantity:\nRequirements:';else if(allowed.includes(service))form.elements.requirements.value='Requested service: '+service+'\n\nProduct name:\nModel:\nQuantity:\nRequirements:';}
 const send=channel=>{
  for(const name of ['name','country','requirements']){const field=form.elements[name];field.value=field.value.trim();field.setCustomValidity(field.value?'':'Please fill in this field.');field.addEventListener('input',()=>field.setCustomValidity(''),{once:true});}
  let url='',raw=website.value.trim();website.setCustomValidity('');if(raw){try{const u=new URL(/^https?:\/\//i.test(raw)?raw:'https://'+raw);if(!['https:','http:'].includes(u.protocol)||!u.hostname.includes('.')||/\s/.test(raw))throw Error();url=u.href;}catch{website.setCustomValidity('Please enter a company website, or leave this field blank.');}}
  if(!form.reportValidity())return;
  const body=['Hello IanProject team,','','Name: '+form.elements.name.value,'Company website: '+(url||'Not provided'),'Country: '+form.elements.country.value,'Trade terms: '+form.elements.terms.value,'','Requirements:',form.elements.requirements.value].join('\n');
  let target;if(channel==='whatsapp'){try{const u=new URL(config.whatsappUrl);u.searchParams.set('text',body);target=u.href;}catch{status.textContent='Please contact us by email.';return;}}else{target='mailto:'+config.email+'?subject='+encodeURIComponent('Project Request — '+form.elements.name.value)+'&body='+encodeURIComponent(body);}
  status.textContent=channel==='whatsapp'?'Opening WhatsApp…':'Opening your email app. Attach drawings and a bill of materials for custom products, then send the message.';location.href=target;
 };
 form.addEventListener('submit',e=>{e.preventDefault();send('email');});form.querySelector('[data-quote-channel="whatsapp"]')?.addEventListener('click',()=>send('whatsapp'));
})();
