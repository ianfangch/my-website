(()=>{
 const toggle=document.querySelector('.preview-menu-toggle'),nav=document.querySelector('#preview-menu');
 const closeDropdowns=except=>document.querySelectorAll('.ian-dropdown-toggle').forEach(b=>{if(b!==except){b.setAttribute('aria-expanded','false');document.getElementById(b.getAttribute('aria-controls')).hidden=true;}});
 const closeMenu=()=>{nav?.classList.remove('is-open');toggle?.setAttribute('aria-expanded','false');if(toggle)toggle.textContent='☰';closeDropdowns();};
 toggle?.addEventListener('click',()=>{const open=nav.classList.toggle('is-open');toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'×':'☰';if(!open)closeDropdowns();});
 document.querySelectorAll('.ian-dropdown-toggle').forEach(b=>b.addEventListener('click',()=>{const menu=document.getElementById(b.getAttribute('aria-controls')),open=menu.hidden;closeDropdowns(b);menu.hidden=!open;b.setAttribute('aria-expanded',String(open));}));
 document.addEventListener('click',e=>{if(!e.target.closest('.ian-dropdown'))closeDropdowns();});
 document.addEventListener('keydown',e=>{if(e.key!=='Escape')return;const open=[...document.querySelectorAll('.ian-dropdown-toggle')].find(b=>b.getAttribute('aria-expanded')==='true');if(open){closeDropdowns();open.focus();}else{closeMenu();if(matchMedia('(max-width:767px)').matches)toggle?.focus();}});
 document.querySelectorAll('.ip-toc').forEach(t=>{if(matchMedia('(max-width:900px)').matches)t.open=false;});
 // Covers load near the viewport; the original factory photo remains a clean fallback.
 const load=img=>{if(img.dataset.loaded)return;img.dataset.loaded='1';let retry=false;const end=ok=>{img.hidden=!ok;img.closest('.ih-film')?.classList.toggle('has-thumb',ok);};img.onload=()=>{if(img.naturalWidth<200&&!retry){retry=true;img.src='https://i.ytimg.com/vi/'+img.dataset.video+'/hqdefault.jpg';return;}end(img.naturalWidth>=200);};img.onerror=()=>{if(!retry){retry=true;img.src='https://i.ytimg.com/vi/'+img.dataset.video+'/hqdefault.jpg';}else end(false);};img.referrerPolicy='no-referrer';img.src='https://i.ytimg.com/vi/'+img.dataset.video+'/maxresdefault.jpg';};
 if('IntersectionObserver'in window){const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){const img=e.target.querySelector('.ih-yt-cover');if(img)load(img);observer.unobserve(e.target);}}),{rootMargin:'180px'});document.querySelectorAll('.ih-film').forEach(card=>observer.observe(card));}
 // Old native product thumbnail controls remain functional after migration.
 document.querySelectorAll('[data-product-image],.product-thumbnail').forEach(el=>el.addEventListener('click',()=>{const image=el.dataset.productImage||el.getAttribute('src'),main=document.getElementById('product-main-image');if(main&&image)main.src=image;}));
})();
