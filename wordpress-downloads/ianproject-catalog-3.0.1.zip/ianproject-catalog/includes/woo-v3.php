<?php
defined( 'ABSPATH' ) || exit;

function ianc_hidden_categories() {
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'meta_query' => array( array( 'key' => '_ian_hide_catalog', 'value' => '1' ) ), 'fields' => 'ids' ) );
    if ( is_wp_error( $terms ) ) { return array(); }
    foreach ( $terms as $id ) { $children = get_term_children( $id, 'product_cat' ); if ( ! is_wp_error( $children ) ) { $terms = array_merge( $terms, $children ); } }
    return array_unique( array_map( 'absint', $terms ) );
}
function ianc_catalog_args( $args = array() ) {
    $tax = array( 'relation' => 'AND' ); $hidden = ianc_hidden_categories();
    if ( $hidden ) { $tax[] = array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $hidden, 'operator' => 'NOT IN', 'include_children' => true ); }
    $visibility = wc_get_product_visibility_term_ids(); $visibility_key = ! empty( $args['s'] ) ? 'exclude-from-search' : 'exclude-from-catalog'; $exclude = array_filter( array( $visibility[ $visibility_key ] ?? 0 ) );
    if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) { $exclude[] = $visibility['outofstock'] ?? 0; }
    if ( $exclude ) { $tax[] = array( 'taxonomy' => 'product_visibility', 'field' => 'term_taxonomy_id', 'terms' => $exclude, 'operator' => 'NOT IN' ); }
    return array_merge( array( 'post_type' => 'product', 'post_status' => 'publish', 'has_password' => false, 'posts_per_page' => 12, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ), 'tax_query' => $tax ), $args );
}
function ianc_visible_terms() {
    if ( ! taxonomy_exists( 'product_cat' ) ) { return array(); }
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) ); if ( is_wp_error( $terms ) ) { return array(); }
    $hidden = ianc_hidden_categories(); $visible = array();
    foreach ( $terms as $term ) {
        if ( in_array( $term->term_id, $hidden, true ) ) { continue; }
        $args = ianc_catalog_args( array( 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) ); $args['tax_query'][] = array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $term->term_id );
        if ( get_posts( $args ) ) { $visible[] = $term; }
    }
    return $visible;
}
function ianc_products_url() { if ( function_exists( 'ian3_url' ) ) { return ian3_url( 'products' ); } if ( is_page() && has_shortcode( get_post_field( 'post_content', get_queried_object_id() ), 'ian_catalog' ) ) { return get_permalink(); } return wc_get_page_permalink( 'shop' ); }
function ianc_contact_url( $id = 0 ) { $url = function_exists( 'ian3_url' ) ? ian3_url( 'contact' ) : home_url( '/contact/' ); return $id ? add_query_arg( 'product', $id, $url ) : $url; }
function ianc_price_html( $id ) {
    $p = wc_get_product( $id );
    $legacy = get_post_meta( $id, '_ian_product_data', true );
    if ( ! get_option( 'ian_catalog_show_prices', false ) || ! empty( $legacy['quoteOnly'] ) || ! $p || '' === $p->get_price() ) { return '<div class="catalog-price catalog-price-pending"><strong>Request a Quote</strong></div>'; }
    $html = wc_price( $p->get_price() ); $unit = get_post_meta( $id, '_ian_price_unit', true );
    return '<div class="catalog-price"><strong>' . $html . '</strong>' . ( $unit ? '<small>' . esc_html( $unit ) . '</small>' : '' ) . '</div>';
}
add_shortcode( 'ian_product_price', function () { return ianc_price_html( get_the_ID() ); } );
add_shortcode( 'ian_product_meta', function () {
    $id = get_the_ID(); $p = wc_get_product( $id ); $terms = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'names' ) );
    return '<p class="text-uppercase text-primary mb-2">' . esc_html( ( is_wp_error( $terms ) ? '' : implode( ', ', $terms ) ) . ( $p && $p->get_sku() ? ' / ' . $p->get_sku() : '' ) ) . '</p>';
} );
function ianc_product_card( $id ) {
    $p = wc_get_product( $id ); if ( ! $p ) { return ''; }
    $terms = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'names' ) );
    return '<article class="catalog-card"><a class="catalog-card-image" href="' . esc_url( get_permalink( $id ) ) . '">' . $p->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy', 'decoding' => 'async' ) ) . '</a><div class="catalog-card-body"><p class="catalog-card-meta">' . esc_html( ( is_wp_error( $terms ) ? '' : implode( ', ', $terms ) ) . ( $p->get_sku() ? ' / ' . $p->get_sku() : '' ) ) . '</p><h3><a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( $p->get_name() ) . '</a></h3><p>' . esc_html( wp_trim_words( wp_strip_all_tags( $p->get_short_description() ), 25 ) ) . '</p>' . ianc_price_html( $id ) . '<a class="catalog-details" href="' . esc_url( get_permalink( $id ) ) . '">View Details ↗</a></div></article>';
}
add_filter( 'posts_search', function ( $search, $query ) {
    if ( ! $query->get( 'ianc_search' ) || ! $query->get( 's' ) ) { return $search; }
    global $wpdb; $like = '%' . $wpdb->esc_like( $query->get( 's' ) ) . '%';
    return $wpdb->prepare( " AND ({$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_excerpt LIKE %s OR {$wpdb->posts}.post_content LIKE %s OR EXISTS (SELECT 1 FROM {$wpdb->postmeta} ianc_sku WHERE ianc_sku.post_id={$wpdb->posts}.ID AND ianc_sku.meta_key IN ('_sku','_ian_sku') AND ianc_sku.meta_value LIKE %s)) AND {$wpdb->posts}.post_password='' ", $like, $like, $like, $like );
}, 10, 2 );
function ianc_query_text( $key ) { return isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) : ''; }
add_shortcode( 'ian_catalog', function ( $attrs ) {
    $attrs = shortcode_atts( array( 'category' => '' ), $attrs, 'ian_catalog' ); $fixed = sanitize_title( $attrs['category'] );
    $category = $fixed ?: sanitize_title( ianc_query_text( 'category' ) ); if ( ! $category && is_tax( 'product_cat' ) ) { $category = get_queried_object()->slug; }
    $search = ianc_query_text( 'catalog_search' ); $sort = sanitize_key( ianc_query_text( 'catalog_sort' ) ); $page = max( 1, absint( $_GET['catalog_page'] ?? 1 ) );
    $args = ianc_catalog_args( array( 'paged' => $page, 's' => $search, 'ianc_search' => true ) );
    if ( $category ) { $args['tax_query'][] = array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => $category ); }
    if ( 'name' === $sort ) { $args['orderby'] = 'title'; $args['order'] = 'ASC'; }
    if ( in_array( $sort, array( 'price-asc', 'price-desc' ), true ) && get_option( 'ian_catalog_show_prices' ) ) { $args['meta_key'] = '_price'; $args['orderby'] = 'meta_value_num'; $args['order'] = 'price-asc' === $sort ? 'ASC' : 'DESC'; }
    $query = new WP_Query( $args ); $terms = ianc_visible_terms(); $url = ianc_products_url();
    ob_start(); ?>
    <section class="ian-catalog" id="catalog" aria-label="Product catalogue">
    <?php if ( ! $fixed ) : ?><nav class="catalog-filters" aria-label="Product categories"><a href="<?php echo esc_url( $url . '#catalog' ); ?>" class="catalog-filter <?php echo ! $category ? 'active' : ''; ?>">All Products</a><?php foreach ( $terms as $term ) : ?><a class="catalog-filter <?php echo $category === $term->slug ? 'active' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'category' => $term->slug, 'catalog_search' => $search ), $url ) . '#catalog' ); ?>"><?php echo esc_html( $term->name ); ?></a><?php endforeach; ?></nav><?php endif; ?>
    <form class="catalog-controls" method="get" action="<?php echo esc_url( $url ); ?>#catalog"><?php if ( $category ) : ?><input type="hidden" name="category" value="<?php echo esc_attr( $category ); ?>"><?php endif; ?><div><label for="catalog-search">Search products or model code</label><input type="search" id="catalog-search" name="catalog_search" value="<?php echo esc_attr( $search ); ?>"></div><div><label for="catalog-sort">Sort by</label><select id="catalog-sort" name="catalog_sort"><option value="">Recommended</option><option value="name" <?php selected( $sort, 'name' ); ?>>Name</option><?php if ( get_option( 'ian_catalog_show_prices' ) ) : ?><option value="price-asc" <?php selected( $sort, 'price-asc' ); ?>>Price: low to high</option><option value="price-desc" <?php selected( $sort, 'price-desc' ); ?>>Price: high to low</option><?php endif; ?></select></div><button type="submit">Search</button></form>
    <p class="catalog-count" role="status"><?php echo esc_html( $query->found_posts . ' products' ); ?><?php if ( $search || $category ) : ?> · <a href="<?php echo esc_url( $url . '#catalog' ); ?>">Clear filters</a><?php endif; ?></p><div class="catalog-grid"><?php foreach ( $query->posts as $p ) { echo ianc_product_card( $p->ID ); } ?></div>
    <?php if ( ! $query->found_posts ) : ?><div class="catalog-empty"><h3><?php echo $search || $category ? 'No matching products.' : 'Let’s find the products for your project.'; ?></h3><p>Share your product list or requirements with IanProject.</p><a href="<?php echo esc_url( ianc_contact_url() ); ?>">Discuss Your Requirements ↗</a></div><?php endif; ?>
    <?php if ( $query->max_num_pages > 1 ) : ?><nav class="ian-pagination" aria-label="Product pages"><?php echo wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'catalog_page', '%#%', $url ), 'current' => $page, 'total' => $query->max_num_pages, 'add_args' => array( 'category' => $category, 'catalog_search' => $search, 'catalog_sort' => $sort ), 'add_fragment' => '#catalog' ) ) ); ?></nav><?php endif; ?></section>
    <?php return ob_get_clean();
} );
/** Category copy comes from WooCommerce; a short neutral fallback keeps new cards complete. */
function ianc_category_summary( $term ) {
    $description = trim( wp_strip_all_tags( preg_replace( '~</p>\s*<p[^>]*>~i', ' ', $term->description ) ) );
    if ( $description ) { return wp_trim_words( $description, 28 ); }
    $defaults = array(
        'accessories' => 'Storage organisers, cabinet fittings and hardware to complete your furniture and interior products.',
        'cabinetry' => 'Kitchen cabinets, wardrobes and fitted joinery, with materials and configurations reviewed for your project.',
        'cabinetry-joinery' => 'Kitchen cabinets, wardrobes and fitted joinery, with materials and configurations reviewed for your project.',
        'carpet' => 'Carpet tiles and soft flooring options for homes, offices, hospitality and commercial interiors.',
        'carpets' => 'Carpet tiles and soft flooring options for homes, offices, hospitality and commercial interiors.',
        'countertops' => 'Worktops and surface materials for kitchens, bathrooms and interior spaces. Discuss colours, dimensions and finishes.',
        'flooring' => 'Flooring options for residential and commercial spaces. Compare materials, finishes and project requirements.',
        'furniture' => 'Furniture for living, dining, bedrooms and commercial spaces, coordinated around your project requirements.',
        'sinks' => 'Kitchen sinks in a range of sizes and configurations. Confirm installation type and dimensions before quotation.',
    );
    return $defaults[ $term->slug ] ?? sprintf( 'Explore %s options. Share the models, quantities and specifications you need for your project quotation.', $term->name );
}
add_shortcode( 'ian_home_product_categories', function () {
    if ( function_exists( 'ian3_visible' ) && ! ian3_visible( 'products' ) ) { return ''; }
    $terms = ianc_visible_terms(); if ( ! $terms ) { return '<p class="ih-section-intro">Share your product requirements to explore suitable options. <a href="' . esc_url( ianc_contact_url() ) . '">Contact IanProject ↗</a></p>'; }
    $html = '<div class="ih-product-grid">';
    foreach ( $terms as $term ) {
        $image = wp_get_attachment_image( absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ), 'large', false, array( 'loading' => 'lazy' ) );
        $html .= '<a class="ih-product-card" href="' . esc_url( add_query_arg( 'category', $term->slug, ianc_products_url() ) . '#catalog' ) . '">' . ( $image ?: '<span class="ian-category-placeholder">Explore category</span>' ) . '<div><h3>' . esc_html( $term->name ) . '</h3><p>' . esc_html( ianc_category_summary( $term ) ) . '</p><span class="ih-category-link">Explore products <span aria-hidden="true">↗</span></span></div></a>';
    }
    $html .= '<a class="ih-product-card ih-category-more" href="' . esc_url( ianc_contact_url() ) . '"><p class="ih-more-kicker">MORE PRODUCTS</p><h3>Continuously<br>updated.</h3><p>Looking for something else? Share the product or specification you need.</p><span class="ih-category-link">Tell us what you need <span aria-hidden="true">↗</span></span></a>';
    return $html . '</div>';
} );
add_shortcode( 'ian_wc_product', function () {
    if ( function_exists( 'ian3_product_detail' ) ) { return ian3_product_detail(); }
    $id = get_queried_object_id(); $p = wc_get_product( $id ); if ( ! $p ) { return ''; }
    if ( get_post_meta( $id, '_ian_catalog_migrated', true ) && has_block( 'core/post-title', get_post_field( 'post_content', $id ) ) ) {
        return '<main class="ian-legacy-product">' . apply_filters( 'the_content', get_post_field( 'post_content', $id ) ) . '<div class="container py-4"><a class="btn btn-primary" href="' . esc_url( ianc_contact_url( $id ) ) . '">Request a Quote</a></div></main>';
    }
    $ids = array_values( array_filter( array_merge( array( $p->get_image_id() ), $p->get_gallery_image_ids() ) ) ); $images = '';
    foreach ( $ids as $index => $image ) { $images .= wp_get_attachment_image( $image, 'large', false, array( 'loading' => $index ? 'lazy' : 'eager' ) ); }
    $content = apply_filters( 'the_content', $p->get_description() );
    if ( $p->has_attributes() || $p->has_weight() || $p->has_dimensions() ) { ob_start(); wc_display_product_attributes( $p ); $attributes = ob_get_clean(); if ( $attributes ) { $content .= '<h2>Specifications</h2>' . $attributes; } }
    return '<main class="ip-page ian-product-page"><section class="ip-detail-head"><div class="ip-shell"><nav class="ip-breadcrumb" aria-label="Breadcrumb"><a href="' . esc_url( ianc_products_url() ) . '">Products</a><span>/</span><span>' . esc_html( $p->get_name() ) . '</span></nav><div class="ip-detail-title"><span class="ip-kicker">' . esc_html( $p->get_sku() ) . '</span><h1>' . esc_html( $p->get_name() ) . '</h1><p>' . esc_html( wp_strip_all_tags( $p->get_short_description() ) ) . '</p></div></div></section><div class="ip-shell ian-product-layout"><div class="ian-product-gallery">' . ( $images ?: $p->get_image() ) . '</div><aside class="ian-product-summary">' . ianc_price_html( $id ) . '<p>Confirm specifications, quantities and delivery terms with IanProject.</p><a class="ip-button" href="' . esc_url( ianc_contact_url( $id ) ) . '">Request a Quote ↗</a></aside></div><section class="ip-shell ip-article ian-product-description">' . $content . '</section></main>';
} );
// This module is a quotation catalogue, independent of the selected theme.
add_filter( 'woocommerce_is_purchasable', '__return_false', 99 );
add_filter( 'woocommerce_variation_is_purchasable', '__return_false', 99 );
add_action( 'wp', function () {
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 ); remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
} );
add_filter( 'woocommerce_get_price_html', function ( $html, $product ) { $legacy = get_post_meta( $product->get_id(), '_ian_product_data', true ); return ! is_admin() && ( ! get_option( 'ian_catalog_show_prices' ) || ! empty( $legacy['quoteOnly'] ) ) ? '<span class="ian-quote-price">Request a Quote</span>' : $html; }, 99, 2 );
add_action( 'template_redirect', function () {
    if ( is_admin() || is_preview() ) { return; }
    $path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' ); $base = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' ); if ( $base && str_starts_with( $path, $base . '/' ) ) { $path = substr( $path, strlen( $base ) + 1 ); }
    $slug = '';
    if ( preg_match( '~^products/([^/]+?)(?:\.html)?/?$~', $path, $match ) ) { $slug = $match[1]; }
    if ( in_array( $path, array( 'product', 'product.html' ), true ) && isset( $_GET['id'] ) && is_scalar( $_GET['id'] ) ) { $slug = wp_unslash( $_GET['id'] ); }
    if ( $slug ) { $post = get_page_by_path( sanitize_title( $slug ), OBJECT, 'product' ); if ( $post && 'publish' === $post->post_status && untrailingslashit( get_permalink( $post ) ) !== untrailingslashit( home_url( '/' . $path . '/' ) ) ) { wp_safe_redirect( get_permalink( $post ), 301 ); exit; } }
}, 1 );
