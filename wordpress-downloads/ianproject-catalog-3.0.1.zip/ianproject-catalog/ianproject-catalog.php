<?php
/**
 * Plugin Name: IanProject 产品目录
 * Description: WooCommerce 原生产品的报价目录、分类显示控制与旧 IanProject 产品迁移；不包含样例产品。
 * Version: 3.0.1
 * Requires at least: 6.7
 * Requires PHP: 8.0
 * Requires Plugins: woocommerce
 * License: GPL-2.0-or-later
 */
defined( 'ABSPATH' ) || exit;
function ianc_boot() {
    static $loaded = false; if ( $loaded ) { return; }
    if ( ! class_exists( 'WooCommerce' ) ) { add_action( 'admin_notices', function () { if ( current_user_can( 'activate_plugins' ) ) { echo '<div class="notice notice-error"><p>IanProject 产品目录 3.0 需要先启用兼容版本的 WooCommerce。数据不会删除。</p></div>'; } } ); return; }
    $loaded = true;
    require_once __DIR__ . '/includes/woo-v3.php';
    require_once __DIR__ . '/includes/migrate-v3.php';
    require_once __DIR__ . '/includes/admin-v3.php';
}
add_action( 'plugins_loaded', 'ianc_boot', 30 );
if ( did_action( 'plugins_loaded' ) ) { ianc_boot(); }
add_action( 'wp_enqueue_scripts', function () { wp_enqueue_style( 'ian-catalog-module', plugins_url( 'assets/catalog.css', __FILE__ ), array(), '3.0.1' ); }, 40 );
register_activation_hook( __FILE__, function () { if ( false === get_option( 'ian_catalog_show_prices', false ) ) { add_option( 'ian_catalog_show_prices', false ); } flush_rewrite_rules( false ); } );
register_deactivation_hook( __FILE__, function () { flush_rewrite_rules( false ); } );
