<?php
defined( 'ABSPATH' ) || exit;

/** One-time owner-approved native attribute update. No frontend category overrides. */
function ianlm_unit_rules() {
    return array( 'cabinetry' => 'metre', 'countertops' => 'metre', 'carpet' => 'metre', 'flooring' => 'metre', 'accessories' => 'set', 'furniture' => 'set', 'sinks' => 'set' );
}
function ianlm_unit_attributes( $product ) {
    $data = array();
    foreach ( $product->get_attributes() as $key => $attribute ) { $data[$key] = $attribute->get_data(); }
    return $data;
}
function ianlm_unit_attribute_objects( $data ) {
    $out = array();
    foreach ( $data as $key => $value ) {
        $attribute = new WC_Product_Attribute();
        foreach ( array( 'id', 'name', 'options', 'position', 'visible', 'variation' ) as $property ) { $attribute->{'set_' . $property}( $value[$property] ); }
        if ( method_exists( $attribute, 'set_extra_data' ) ) {
            foreach ( array_diff_key( $value, array_flip( array( 'id', 'name', 'options', 'position', 'visible', 'variation', 'is_visible', 'is_variation', 'is_taxonomy', 'value' ) ) ) as $property => $extra ) { $attribute->set_extra_data( $property, $extra ); }
        }
        $out[$key] = $attribute;
    }
    return $out;
}
function ianlm_unit_hash( $id ) {
    $product = wc_get_product( $id );
    return $product ? hash( 'sha256', wp_json_encode( array( ianlm_unit_attributes( $product ), $product->get_category_ids(), $product->get_type(), get_post_modified_time( 'U', true, $id ), $product->get_price( 'edit' ) ) ) ) : '';
}
function ianlm_unit_target( $product ) {
    $slugs = array();
    foreach ( $product->get_category_ids() as $id ) {
        foreach ( array_merge( array( $id ), get_ancestors( $id, 'product_cat', 'taxonomy' ) ) as $term_id ) { $term = get_term( $term_id, 'product_cat' ); if ( $term && ! is_wp_error( $term ) ) { $slugs[] = $term->slug; } }
    }
    $units = array_unique( array_values( array_intersect_key( ianlm_unit_rules(), array_flip( $slugs ) ) ) );
    return count( $units ) === 1 ? reset( $units ) : '';
}
function ianlm_unit_after( $product, $unit ) {
    $data = ianlm_unit_attributes( $product );
    foreach ( array( 'Pricing unit' => $unit, 'Minimum order' => '1 ' . $unit ) as $name => $value ) {
        $key = sanitize_title( $name );
        foreach ( $data as $old ) {
            if ( in_array( sanitize_title( $old['name'] ), array( $key, 'pa_' . $key ), true ) && ( $old['id'] || $old['variation'] ) ) { return new WP_Error( 'ianlm_unit_attribute', '单位或 MOQ 被用作全局／变体属性，请在原生商品编辑页核对，不自动覆盖。' ); }
        }
        $attribute = new WC_Product_Attribute(); $attribute->set_name( $name ); $attribute->set_options( array( $value ) ); $attribute->set_position( $data[$key]['position'] ?? count( $data ) ); $attribute->set_visible( true ); $attribute->set_variation( false );
        $data[$key] = array_replace( $data[$key] ?? array(), $attribute->get_data() );
    }
    return $data;
}
function ianlm_unit_scan() {
    if ( ! current_user_can( 'manage_woocommerce' ) || ! function_exists( 'wc_get_product' ) ) { return new WP_Error( 'ianlm_unit_permission', '请启用 WooCommerce，并使用有商品管理权限的账号。' ); }
    $last = get_option( 'ianlm_unit_job_' . get_current_user_id() );
    if ( is_array( $last ) && array_filter( $last['items'], static fn( $item ) => 'updated' === $item['status'] ) ) { update_option( 'ianlm_unit_previous_' . get_current_user_id(), $last, false ); }
    $job = array( 'owner' => get_current_user_id(), 'token' => wp_generate_uuid4(), 'offset' => 0, 'phase' => 'review', 'items' => array() );
    $ids = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'numberposts' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC' ) );
    foreach ( $ids as $id ) {
        $product = wc_get_product( $id ); $unit = $product ? ianlm_unit_target( $product ) : '';
        $item = array( 'id' => $id, 'title' => get_the_title( $id ), 'unit' => $unit, 'before_unit' => $product ? $product->get_attribute( 'Pricing unit' ) : '', 'before_moq' => $product ? $product->get_attribute( 'Minimum order' ) : '', 'status' => 'pending', 'message' => '', 'hash' => ianlm_unit_hash( $id ) );
        if ( ! $product || ! $product->is_type( array( 'simple', 'variable' ) ) || ! current_user_can( 'edit_post', $id ) || ! $unit ) { $item['status'] = 'skipped'; $item['message'] = '分类不明确、跨单位分类或商品类型／权限需人工核对。'; }
        else {
            $after = ianlm_unit_after( $product, $unit );
            if ( is_wp_error( $after ) ) { $item['status'] = 'skipped'; $item['message'] = $after->get_error_message(); }
            elseif ( $after === ianlm_unit_attributes( $product ) ) { $item['status'] = 'unchanged'; $item['message'] = '已符合规则。'; }
        }
        $job['items'][] = $item;
    }
    update_option( 'ianlm_unit_job_' . get_current_user_id(), $job, false );
    return $job;
}
function ianlm_unit_step( $token ) {
    $option = 'ianlm_unit_job_' . get_current_user_id(); $job = get_option( $option );
    if ( ! current_user_can( 'manage_woocommerce' ) || ! is_array( $job ) || $job['owner'] !== get_current_user_id() || ! hash_equals( $job['token'], $token ) ) { return new WP_Error( 'ianlm_unit_plan', '请先扫描单位更新清单。' ); }
    $lock = array( 'token' => wp_generate_uuid4(), 'time' => time() ); $old = get_option( 'ianlm_unit_lock' );
    if ( is_array( $old ) && $old['time'] < time() - 180 ) { delete_option( 'ianlm_unit_lock' ); }
    if ( ! add_option( 'ianlm_unit_lock', $lock, '', false ) ) { return new WP_Error( 'ianlm_unit_busy', '另一批单位更新正在运行，请稍后继续。' ); }
    try {
        if ( ! isset( $job['items'][$job['offset']] ) ) { $job['phase'] = 'complete'; return $job; }
        $item =& $job['items'][$job['offset']];
        if ( 'pending' === $item['status'] ) {
            $product = wc_get_product( $item['id'] );
            if ( ! $product || ! current_user_can( 'edit_post', $item['id'] ) || ! hash_equals( $item['hash'], ianlm_unit_hash( $item['id'] ) ) || ianlm_unit_target( $product ) !== $item['unit'] ) { $item['status'] = 'error'; $item['message'] = '扫描后商品已改变或无编辑权限，请重新扫描。'; }
            else {
                $after = ianlm_unit_after( $product, $item['unit'] );
                if ( is_wp_error( $after ) ) { $item['status'] = 'error'; $item['message'] = $after->get_error_message(); }
                else {
                    $key = 'ianlm_unit_backup_' . $item['id'] . '_' . $job['token'];
                    $backup = array( 'id' => $item['id'], 'owner' => get_current_user_id(), 'before' => ianlm_unit_attributes( $product ), 'restored' => false, 'created' => current_time( 'mysql', true ) );
                    if ( ! add_option( $key, $backup, '', false ) ) { $item['status'] = 'error'; $item['message'] = '备份未建立，已停止此项。'; }
                    else {
                        $product->set_attributes( ianlm_unit_attribute_objects( $after ) ); $product->save();
                        $backup['after_hash'] = ianlm_unit_hash( $item['id'] ); update_option( $key, $backup, false );
                        $item['backup'] = $key; $item['status'] = 'updated'; $item['message'] = '计价单位及 MOQ 已更新；价格与其他资料保留。';
                        wc_delete_product_transients( $item['id'] ); do_action( 'litespeed_purge_post', $item['id'] );
                    }
                }
            }
        }
        ++$job['offset']; $job['phase'] = $job['offset'] >= count( $job['items'] ) ? 'complete' : 'running'; update_option( $option, $job, false );
        return $job;
    } finally { if ( ( get_option( 'ianlm_unit_lock' )['token'] ?? '' ) === $lock['token'] ) { delete_option( 'ianlm_unit_lock' ); } }
}
function ianlm_unit_restore( $key ) {
    if ( ! str_starts_with( $key, 'ianlm_unit_backup_' ) || ! current_user_can( 'manage_woocommerce' ) ) { return new WP_Error( 'ianlm_unit_backup', '没有可恢复的备份或权限。' ); }
    $backup = get_option( $key );
    if ( ! is_array( $backup ) || $backup['owner'] !== get_current_user_id() || ! current_user_can( 'edit_post', $backup['id'] ) || ! empty( $backup['restored'] ) || empty( $backup['after_hash'] ) || ! hash_equals( $backup['after_hash'], ianlm_unit_hash( $backup['id'] ) ) ) { return new WP_Error( 'ianlm_unit_edited', '商品已有后续编辑、备份已恢复或无编辑权限，已停止自动恢复。' ); }
    $product = wc_get_product( $backup['id'] ); $product->set_attributes( ianlm_unit_attribute_objects( $backup['before'] ) ); $product->save();
    $backup['restored'] = true; update_option( $key, $backup, false );
    foreach ( array( 'ianlm_unit_job_', 'ianlm_unit_previous_' ) as $prefix ) { $option = $prefix . get_current_user_id(); $job = get_option( $option ); if ( is_array( $job ) ) { foreach ( $job['items'] as &$item ) { if ( ( $item['backup'] ?? '' ) === $key ) { $item['status'] = 'restored'; $item['message'] = '已恢复原单位及 MOQ。'; } } unset( $item ); update_option( $option, $job, false ); } }
    wc_delete_product_transients( $backup['id'] ); do_action( 'litespeed_purge_post', $backup['id'] ); return true;
}
foreach ( array( 'scan', 'step', 'restore' ) as $operation ) {
    add_action( 'wp_ajax_ianlm_unit_' . $operation, static function () use ( $operation ) {
        if ( ! current_user_can( 'manage_woocommerce' ) || ! function_exists( 'wc_get_product' ) ) { wp_send_json_error( array( 'message' => '请启用 WooCommerce，并确认商品管理权限。' ), 403 ); }
        check_ajax_referer( 'ianlm_unit', 'nonce' );
        $input = 'restore' === $operation ? 'backup' : 'token'; $value = isset( $_POST[$input] ) && is_scalar( $_POST[$input] ) ? sanitize_text_field( wp_unslash( $_POST[$input] ) ) : '';
        $r = 'scan' === $operation ? ianlm_unit_scan() : ( 'step' === $operation ? ianlm_unit_step( $value ) : ianlm_unit_restore( $value ) );
        if ( is_wp_error( $r ) ) { wp_send_json_error( array( 'message' => $r->get_error_message() ), 400 ); } wp_send_json_success( $r );
    } );
}
add_action( 'admin_menu', function () { add_management_page( 'IanProject 商品单位更新', 'IanProject 商品单位更新', 'manage_woocommerce', 'ianproject-unit-update', 'ianlm_unit_admin' ); } );
function ianlm_unit_admin() {
    if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
    $job = get_option( 'ianlm_unit_job_' . get_current_user_id() );
    $previous = get_option( 'ianlm_unit_previous_' . get_current_user_id() );
    ?>
    <div class="wrap"><h1>IanProject 商品单位更新</h1>
    <p>已确认：柜子、台面、地毯、地板按延米 metre，MOQ 为 1 metre；配件、家具、水槽按套 set，MOQ 为 1 set。按现有分类识别，包含子分类；跨单位分类或未知分类保留并报告。</p>
    <p>只写入 WooCommerce 原生 Pricing unit 和 Minimum order 非变体属性。现有价格金额、变体、图片、正文及其他属性保留；请核对原价格是否确实对应新的单位。每项先备份。完成后可停用本工具，前台不会按分类强制覆盖未来编辑。</p>
    <p><button class="button" id="ian-unit-scan">1. 扫描并预览</button> <button class="button button-primary" id="ian-unit-start" disabled>2. 备份并应用／继续</button> <button class="button" id="ian-unit-report">下载报告</button> <button class="button" id="ian-unit-previous" <?php disabled( ! is_array( $previous ) ); ?>>查看上一次更新备份</button></p><p role="status" id="ian-unit-status"></p><div id="ian-unit-results"></div></div>
    <script>(()=>{'use strict';let job=<?php echo wp_json_encode( $job ?: null, JSON_HEX_TAG | JSON_HEX_AMP ); ?>;const nonce=<?php echo wp_json_encode( wp_create_nonce( 'ianlm_unit' ) ); ?>,scan=document.getElementById('ian-unit-scan'),start=document.getElementById('ian-unit-start'),status=document.getElementById('ian-unit-status'),results=document.getElementById('ian-unit-results');let previous=<?php echo wp_json_encode( $previous ?: null, JSON_HEX_TAG | JSON_HEX_AMP ); ?>,busy=false;document.getElementById('ian-unit-previous').onclick=()=>{if(!busy&&previous){job=previous;render();}};const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));async function api(op,args={}){const r=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:new URLSearchParams({action:'ianlm_unit_'+op,nonce,...args})}),j=await r.json();if(!j.success)throw Error(j.data?.message||'更新失败');return j.data;}function render(){if(!job)return;start.disabled=busy||job.offset>=job.items.length;status.textContent='已处理 '+job.offset+' / '+job.items.length+'；已更新 '+job.items.filter(i=>i.status==='updated').length+'；需核对 '+job.items.filter(i=>['error','skipped'].includes(i.status)).length+'。';results.innerHTML='<table class="widefat striped"><thead><tr><th>商品</th><th>原单位／MOQ</th><th>新单位／MOQ</th><th>状态</th><th>备份</th></tr></thead><tbody>'+job.items.map(i=>'<tr><td>'+esc(i.title)+' (#'+i.id+')</td><td>'+esc(i.before_unit)+' / '+esc(i.before_moq)+'</td><td>'+esc(i.unit)+' / '+(i.unit?'1 '+esc(i.unit):'保留')+'</td><td>'+esc(i.message||i.status)+'</td><td>'+(i.status==='updated'&&i.backup?'<button class="button" data-unit-restore="'+esc(i.backup)+'">恢复此项</button>':'')+'</td></tr>').join('')+'</tbody></table>';results.querySelectorAll('[data-unit-restore]').forEach(b=>{b.disabled=busy;b.onclick=async()=>{if(busy)return;busy=true;scan.disabled=start.disabled=true;b.disabled=true;try{await api('restore',{backup:b.dataset.unitRestore});const i=job.items.find(i=>i.backup===b.dataset.unitRestore);if(i){i.status='restored';i.message='已恢复单位及 MOQ。';}render();}catch(e){status.textContent=e.message;}finally{busy=false;scan.disabled=false;start.disabled=job.offset>=job.items.length;b.disabled=false;}};});}scan.onclick=async()=>{busy=true;scan.disabled=start.disabled=true;try{if(job?.items.some(i=>i.status==='updated')){previous=job;document.getElementById('ian-unit-previous').disabled=false;}job=await api('scan');render();}catch(e){status.textContent=e.message;}finally{busy=false;scan.disabled=false;start.disabled=!job||job.offset>=job.items.length;}};start.onclick=async()=>{busy=true;scan.disabled=start.disabled=true;try{while(job.offset<job.items.length){job=await api('step',{token:job.token});render();}}catch(e){status.textContent='已暂停：'+e.message;}finally{busy=false;scan.disabled=false;start.disabled=!job||job.offset>=job.items.length;}};document.getElementById('ian-unit-report').onclick=()=>{if(!job)return;const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(job,null,2)],{type:'application/json'}));a.download='ianproject-unit-update-report.json';a.click();URL.revokeObjectURL(a.href);};render();})();</script>
    <?php
}
