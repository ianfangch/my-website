<?php
defined( 'ABSPATH' ) || exit;

/** One-time native content update; never rewrites rendered frontend HTML. */
function ianlm_contact_page_id() {
    $map = (array) get_option('ian3_pages', array());
    return absint(get_option('ianq_contact_page', 0)) ?: absint($map['contact'] ?? 0);
}
function ianlm_contact_fingerprint($post) {
    return hash('sha256', wp_json_encode(array($post->ID, $post->post_title, $post->post_content, $post->post_status)));
}
function ianlm_location_snapshot() {
    $values = (array) get_option('iansf_contacts', array());
    $out = array();
    foreach (array('address', 'map_url') as $key) {
        $out[$key] = array('exists' => array_key_exists($key, $values), 'value' => $values[$key] ?? null);
    }
    return $out;
}
function ianlm_location_hash($snapshot = null) {
    return hash('sha256', wp_json_encode($snapshot ?? ianlm_location_snapshot()));
}
function ianlm_location_merge($snapshot) {
    $values = (array) get_option('iansf_contacts', array());
    foreach (array('address', 'map_url') as $key) {
        if ($snapshot[$key]['exists']) { $values[$key] = $snapshot[$key]['value']; }
        else { unset($values[$key]); }
    }
    // Inputs come from the bundled location file or our own backup. Preserve every
    // unrelated raw value, including omitted keys when restoring an older option.
    $priority = has_filter('sanitize_option_iansf_contacts', 'iansf_sanitize_contacts');
    if (false !== $priority) { remove_filter('sanitize_option_iansf_contacts', 'iansf_sanitize_contacts', $priority); }
    try { update_option('iansf_contacts', $values, false); }
    finally { if (false !== $priority) { add_filter('sanitize_option_iansf_contacts', 'iansf_sanitize_contacts', $priority); } }
}
function ianlm_contact_asset_hash() {
    $root = dirname(__DIR__) . '/data/';
    return hash('sha256', file_get_contents($root.'contact-page.html') . file_get_contents($root.'contact-location.html') . file_get_contents($root.'contact-settings.json'));
}
function ianlm_contact_block_has_class($block, $class) {
    return in_array($class, preg_split('/\s+/', $block['attrs']['className'] ?? ''), true);
}
/** Add the location block to the existing sidebar, preserving owner edits. */
function ianlm_contact_add_location(&$blocks, $location) {
    foreach ($blocks as &$block) {
        if (ianlm_contact_block_has_class($block, 'ian-contact-sidebar')) {
            foreach ($block['innerBlocks'] as $child) {
                if (ianlm_contact_block_has_class($child, 'ian-contact-location')) { return 'current'; }
            }
            $at = count($block['innerBlocks']);
            foreach ($block['innerBlocks'] as $i => $child) {
                if ('core/heading' === $child['blockName'] && 'What to include' === trim(wp_strip_all_tags($child['innerHTML']))) { $at = $i; break; }
            }
            $nulls = 0; $slot = max(0, count($block['innerContent']) - 1);
            foreach ($block['innerContent'] as $i => $part) {
                if (null === $part) { if ($nulls === $at) { $slot = $i; break; } ++$nulls; }
            }
            array_splice($block['innerBlocks'], $at, 0, array($location));
            array_splice($block['innerContent'], $slot, 0, array(null, "\n"));
            return 'added';
        }
        $found = ianlm_contact_add_location($block['innerBlocks'], $location);
        if ($found) { return $found; }
    }
    return false;
}
function ianlm_contact_preview() {
    $id = ianlm_contact_page_id(); $post = get_post($id);
    if (!current_user_can('manage_options') || !$post || 'page' !== $post->post_type || !current_user_can('edit_post', $id)) { return new WP_Error('ianlm_contact_page', '请先指定联系页面，并确认有管理设置及编辑页面的权限。'); }
    $root = dirname(__DIR__) . '/data/';
    $blocks = parse_blocks($post->post_content);
    $location = parse_blocks(file_get_contents($root.'contact-location.html'))[0];
    $found = ianlm_contact_add_location($blocks, $location);
    $content = 'current' === $found ? $post->post_content : ($found ? serialize_blocks($blocks) : file_get_contents($root.'contact-page.html'));
    // Only the legacy-layout fallback replaces a page. Keep the enquiry shortcode attributes.
    if (!$found && preg_match('/\[ian_quote_form(?:\s[^\]]*)?\]/', $post->post_content, $m)) { $content = str_replace('[ian_quote_form]', $m[0], $content); }
    $values = json_decode(file_get_contents($root.'contact-settings.json'), true);
    $desired = array();
    foreach (array('address', 'map_url') as $key) { $desired[$key] = array('exists' => true, 'value' => $values[$key]); }
    $before_location = ianlm_location_snapshot();
    $plan = array('id' => $id, 'owner' => get_current_user_id(), 'title' => $post->post_title, 'before_hash' => ianlm_contact_fingerprint($post), 'before_location_hash' => ianlm_location_hash($before_location), 'template_hash' => ianlm_contact_asset_hash(), 'content' => $content, 'location' => $desired, 'mode' => $found ?: 'replace_legacy', 'already_current' => $content === $post->post_content && $desired === $before_location);
    update_option('ianlm_contact_plan_'.get_current_user_id(), $plan, false);
    return $plan;
}
function ianlm_contact_apply($plan) {
    if (!is_array($plan) || !isset($plan['location'], $plan['before_location_hash']) || (int) $plan['owner'] !== get_current_user_id() || !current_user_can('manage_options') || !current_user_can('edit_post', $plan['id'])) { return new WP_Error('ianlm_contact_permission', '请重新预览联系页更新。'); }
    $post = get_post($plan['id']);
    if (!$post || !hash_equals($plan['before_hash'], ianlm_contact_fingerprint($post)) || !hash_equals($plan['before_location_hash'], ianlm_location_hash()) || !hash_equals($plan['template_hash'], ianlm_contact_asset_hash())) { return new WP_Error('ianlm_contact_changed', '联系页、公司地址或模板在预览后发生变化，请重新预览。'); }
    if ($plan['content'] === $post->post_content && $plan['location'] === ianlm_location_snapshot()) { delete_option('ianlm_contact_plan_'.get_current_user_id()); return array('id' => $post->ID, 'message' => '联系页与统一公司地址已是新版，无需重复更新。'); }
    $key = 'ianlm_contact_backup_'.$post->ID.'_'.wp_generate_uuid4();
    $saved = add_option($key, array('id' => $post->ID, 'content' => $post->post_content, 'location' => ianlm_location_snapshot(), 'owner' => get_current_user_id(), 'created_at' => current_time('mysql', true), 'applied_hash' => hash('sha256', $plan['content']), 'applied_location_hash' => ianlm_location_hash($plan['location'])), '', false);
    if (!$saved) { return new WP_Error('ianlm_contact_backup_failed', '无法保存备份，更新已停止。'); }
    wp_save_post_revision($post->ID);
    $result = wp_update_post(wp_slash(array('ID' => $post->ID, 'post_content' => $plan['content'])), true);
    if (is_wp_error($result)) { return $result; }
    ianlm_location_merge($plan['location']);
    update_option('ianlm_contact_last_'.get_current_user_id(), array('id' => $post->ID, 'backup' => $key), false);
    delete_option('ianlm_contact_plan_'.get_current_user_id());
    do_action('litespeed_purge_post', $post->ID);
    return array('id' => $post->ID, 'backup' => $key, 'message' => '联系页源内容及全站公司地址／地图已更新。邮箱、电话、WhatsApp、商品和 WooCommerce 商店／税务地址均保留。');
}
function ianlm_contact_restore($key) {
    $backup = get_option($key); $post = is_array($backup) ? get_post($backup['id']) : null;
    if (!$post || !current_user_can('manage_options') || !current_user_can('edit_post', $post->ID) || (int) $backup['owner'] !== get_current_user_id()) { return new WP_Error('ianlm_contact_backup', '没有可恢复的联系页备份或权限。'); }
    if (!hash_equals($backup['applied_hash'], hash('sha256', $post->post_content)) || (isset($backup['applied_location_hash']) && !hash_equals($backup['applied_location_hash'], ianlm_location_hash()))) { return new WP_Error('ianlm_contact_edited', '更新后联系页或公司地址已有编辑，已停止自动恢复。'); }
    $r = wp_update_post(wp_slash(array('ID' => $post->ID, 'post_content' => $backup['content'])), true);
    if (!is_wp_error($r)) {
        if (isset($backup['location'])) { ianlm_location_merge($backup['location']); }
        do_action('litespeed_purge_post', $post->ID); delete_option('ianlm_contact_last_'.get_current_user_id());
    }
    return $r;
}
add_action('admin_menu', function () { add_management_page('IanProject 联系页更新', 'IanProject 联系页更新', 'manage_options', 'ianproject-contact-update', 'ianlm_contact_admin'); });
function ianlm_contact_admin() {
    if (!current_user_can('manage_options')) { return; }
    $message = ''; $error = false;
    if (isset($_POST['ianlm_contact_preview'])) { check_admin_referer('ianlm_contact_update'); $r = ianlm_contact_preview(); if (is_wp_error($r)) { $message = $r->get_error_message(); $error = true; } }
    if (isset($_POST['ianlm_contact_apply'])) { check_admin_referer('ianlm_contact_update'); $r = ianlm_contact_apply(get_option('ianlm_contact_plan_'.get_current_user_id())); $error = is_wp_error($r); $message = $error ? $r->get_error_message() : $r['message']; }
    if (isset($_POST['ianlm_contact_restore'])) { check_admin_referer('ianlm_contact_update'); $last = get_option('ianlm_contact_last_'.get_current_user_id(), array()); $r = ianlm_contact_restore($last['backup'] ?? ''); $error = is_wp_error($r); $message = $error ? $r->get_error_message() : '已恢复更新前的联系页及公司地址／地图。'; }
    echo '<div class="wrap" style="max-width:980px"><h1>IanProject 联系页更新</h1><p>在现有联系页侧栏加入地址区块，保留已编辑的正文；老版页面将改为新版布局。仅更新全站公司地址和地图链接，邮箱、电话及 WhatsApp 继续使用现有统一设置。无需重新迁移商品。</p>';
    if ($message) { echo '<div class="notice '.($error ? 'notice-error' : 'notice-success').'"><p>'.esc_html($message).'</p></div>'; }
    echo '<form method="post">'; wp_nonce_field('ianlm_contact_update'); echo '<button class="button" name="ianlm_contact_preview">1. 预览联系页更新</button></form>';
    $plan = get_option('ianlm_contact_plan_'.get_current_user_id());
    if (is_array($plan) && isset($plan['location'])) {
        echo '<h2>待更新：'.esc_html($plan['title']).' (#'.absint($plan['id']).')</h2><p>公司地址：'.esc_html($plan['location']['address']['value']).'<br>地图：'.esc_html($plan['location']['map_url']['value']).'</p><p>地址及联系方式以后在「设置 → IanProject 联系方式」维护，联系页和页脚共用。WooCommerce 商店／税务地址不变。</p><p><a href="'.esc_url(get_permalink($plan['id'])).'" target="_blank" rel="noopener">查看当前联系页</a> · <a href="'.esc_url(get_edit_post_link($plan['id'], 'raw')).'">编辑源内容</a></p><details><summary>查看将保存的原生区块内容</summary><textarea class="large-text code" rows="14" readonly>'.esc_textarea($plan['content']).'</textarea></details><form method="post" style="margin-top:20px">'; wp_nonce_field('ianlm_contact_update'); echo '<button class="button button-primary" name="ianlm_contact_apply">2. 备份并应用联系页及地址更新</button></form>';
    }
    if (get_option('ianlm_contact_last_'.get_current_user_id())) { echo '<h2>恢复</h2><p>如果更新后尚未另行编辑页面或地址，可恢复本次更新前的内容和地址；其他联系方式保留。</p><form method="post">'; wp_nonce_field('ianlm_contact_update'); echo '<button class="button" name="ianlm_contact_restore">恢复更新前的联系页及地址</button></form>'; }
    echo '<p>完成后可停用此迁移工具，联系页不依赖本工具运行。</p></div>';
}
