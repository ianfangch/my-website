<?php
/** Basic metadata for native content. Established SEO plugins remain authoritative. */
defined( 'ABSPATH' ) || exit;
function ianseo_external_provider() {
    return (bool) apply_filters( 'ianproject_external_seo', defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' ) || function_exists( 'the_seo_framework' ) );
}
function ianseo_first_paragraph( $content ) {
    foreach ( parse_blocks( $content ) as $block ) {
        $class = $block['attrs']['className'] ?? '';
        if ( preg_match( '/kicker|eyebrow/', $class ) ) { continue; }
        if ( $block['innerBlocks'] ) { $text = ianseo_first_paragraph( serialize_blocks( $block['innerBlocks'] ) ); if ( $text ) { return $text; } }
        if ( in_array( $block['blockName'], array( 'core/paragraph', null, 'core/freeform', 'core/html' ), true ) ) {
            $paragraphs = array();
            if ( 'core/paragraph' === $block['blockName'] ) { $paragraphs[] = $block['innerHTML']; }
            elseif ( preg_match_all( '~<p\b[^>]*>(.*?)</p>~is', $block['innerHTML'], $matches ) ) { $paragraphs = $matches[1]; }
            foreach ( $paragraphs as $html ) {
                $text = trim( wp_strip_all_tags( strip_shortcodes( $html ) ) );
                if ( strlen( $text ) >= 60 ) { return $text; }
            }
        }
    }
    return '';
}
function ianseo_description( $id ) {
    // Never read legacy _ian_description: it may contain obsolete price ranges.
    $text = get_post_field( 'post_excerpt', $id );
    if ( ! trim( $text ) ) { $text = ianseo_first_paragraph( get_post_field( 'post_content', $id ) ); }
    if ( ! trim( $text ) ) { $text = get_the_title( $id ); }
    $text = preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( strip_shortcodes( $text ) ), ENT_QUOTES, 'UTF-8' ) );
    return wp_html_excerpt( trim( $text ), 160, '…' );
}
function ianseo_utility_ids() {
    $ids = array();
    foreach ( array( 'cart', 'checkout', 'myaccount' ) as $name ) { $ids[] = absint( get_option( 'woocommerce_' . $name . '_page_id' ) ); }
    return array_filter( $ids );
}
function ianseo_redirect_page_ids() {
    $ids = array(); $shop = absint( get_option( 'woocommerce_shop_page_id' ) ); $blog = absint( get_option( 'page_for_posts' ) );
    if ( $shop && $shop !== ian3_id( 'products' ) && ian3_id( 'products' ) && ian3_visible( 'products' ) ) { $ids[] = $shop; }
    if ( $blog && $blog !== ian3_id( 'insights' ) && ian3_id( 'insights' ) && ian3_visible( 'insights' ) ) { $ids[] = $blog; }
    return $ids;
}
add_filter( 'wp_robots', function ( $robots ) {
    $ids = ianseo_utility_ids();
    if ( $ids && is_page( $ids ) ) { unset( $robots['index'] ); $robots['noindex'] = true; }
    return $robots;
} );
add_filter( 'wp_sitemaps_posts_query_args', function ( $args, $type ) {
    if ( 'page' === $type ) { $args['post__not_in'] = array_unique( array_merge( (array) ( $args['post__not_in'] ?? array() ), ianseo_utility_ids(), ianseo_redirect_page_ids() ) ); }
    return $args;
}, 10, 2 );
add_action( 'template_redirect', function () {
    if ( is_admin() || wp_doing_ajax() || is_preview() || ! in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', array( 'GET', 'HEAD' ), true ) || isset( $_GET['add-to-cart'] ) ) { return; }
    $target = '';
    if ( function_exists( 'is_shop' ) && is_shop() && in_array( absint( get_option( 'woocommerce_shop_page_id' ) ), ianseo_redirect_page_ids(), true ) ) {
        $target = ian3_url( 'products' ); $query = array();
        if ( isset( $_GET['s'] ) && is_scalar( $_GET['s'] ) ) { $query['catalog_search'] = sanitize_text_field( wp_unslash( $_GET['s'] ) ); }
        if ( isset( $_GET['product_cat'] ) && is_scalar( $_GET['product_cat'] ) ) { $query['category'] = sanitize_title( wp_unslash( $_GET['product_cat'] ) ); }
        if ( get_query_var( 'paged' ) > 1 ) { $query['catalog_page'] = absint( get_query_var( 'paged' ) ); }
        $target = add_query_arg( ianproject_query_values( $query ), $target );
    } elseif ( is_home() && ! is_front_page() && in_array( absint( get_option( 'page_for_posts' ) ), ianseo_redirect_page_ids(), true ) ) { $target = ian3_url( 'insights' ); }
    elseif ( is_404() ) {
        $path = trim( rawurldecode( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ), '/' );
        $base = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
        if ( $base && str_starts_with( $path, $base . '/' ) ) { $path = substr( $path, strlen( $base ) + 1 ); }
        $aliases = array( 'about' => 'about', 'contact' => 'contact', 'privacy-policy' => 'privacy', 'terms-of-use' => 'terms' );
        if ( isset( $aliases[$path] ) && ian3_visible( $aliases[$path] ) ) { $target = ian3_url( $aliases[$path] ); }
    }
    if ( $target ) { wp_safe_redirect( $target, 301 ); exit; }
}, 5 );
add_action( 'wp_head', function () {
    if ( ianseo_external_provider() || is_404() || is_search() || is_feed() ) { return; }
    if ( is_singular() ) {
        $id = get_queried_object_id();
        if ( post_password_required( $id ) || in_array( $id, ianseo_utility_ids(), true ) ) { return; }
        $description = ianseo_description( $id );
        echo '<meta name="description" content="' . esc_attr( $description ) . '"><meta property="og:title" content="' . esc_attr( get_the_title( $id ) ) . '"><meta property="og:description" content="' . esc_attr( $description ) . '"><meta property="og:url" content="' . esc_url( get_permalink( $id ) ) . '"><meta property="og:type" content="' . ( 'post' === get_post_type( $id ) ? 'article' : 'website' ) . '">';
        $image = get_the_post_thumbnail_url( $id, 'large' ); if ( $image ) { echo '<meta property="og:image" content="' . esc_url( $image ) . '">'; }
    } elseif ( is_tax() || is_category() || is_tag() || is_post_type_archive() || is_home() ) {
        echo '<link rel="canonical" href="' . esc_url( get_pagenum_link( max( 1, absint( get_query_var( 'paged' ) ) ) ) ) . '">';
    }
}, 3 );
function ianseo_organization() {
    $values = iansf_contacts();
    $organization = array( '@type' => 'Organization', '@id' => home_url( '/#organization' ), 'name' => get_bloginfo( 'name' ), 'url' => home_url( '/' ) );
    foreach ( array( 'email' => 'email', 'phone' => 'telephone', 'address' => 'address' ) as $field => $property ) { if ( ! empty( $values[$field] ) ) { $organization[$property] = $values[$field]; } }
    $organization['sameAs'] = array_values( array_filter( array_intersect_key( $values, array_flip( array( 'linkedin', 'instagram', 'facebook', 'youtube', 'pinterest', 'tiktok', 'x' ) ) ) ) );
    $logo = wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' ); if ( $logo ) { $organization['logo'] = $logo; }
    return $organization;
}
add_action( 'wp_footer', function () {
    if ( ianseo_external_provider() || ! is_singular( 'product' ) || ! function_exists( 'WC' ) || ! WC()->structured_data ) { return; }
    $product = wc_get_product( get_queried_object_id() ); if ( ! $product ) { return; }
    foreach ( WC()->structured_data->get_data() as $node ) { if ( in_array( 'Product', (array) $node['@type'], true ) ) { return; } }
    // Core WooCommerce owns offers, currency, taxes and real reviews. Unknown/zero prices stay absent.
    if ( $product->is_type( 'variable' ) ) { if ( (float) $product->get_variation_price( 'min', true ) <= 0 ) { return; } }
    elseif ( ! ian4_has_native_price( $product ) ) { return; }
    WC()->structured_data->generate_product_data( $product );
}, 9 );
add_action( 'wp_footer', function () {
    if ( ianseo_external_provider() || is_404() || is_search() || is_feed() || ! ( is_singular() || is_front_page() ) || in_array( get_queried_object_id(), ianseo_utility_ids(), true ) || post_password_required() ) { return; }
    $id = get_queried_object_id(); $url = is_singular() ? get_permalink( $id ) : home_url( '/' );
    $graph = array( ianseo_organization() );
    if ( is_front_page() ) { $graph[] = array( '@type' => 'WebSite', '@id' => home_url( '/#website' ), 'url' => home_url( '/' ), 'name' => get_bloginfo( 'name' ), 'publisher' => array( '@id' => home_url( '/#organization' ) ) ); }
    else {
        $items = array( array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => home_url( '/' ) ) );
        $role = is_singular( 'product' ) ? 'products' : ( is_singular( 'post' ) ? ian3_article_kind( $id ) : '' );
        if ( $role && ian3_visible( $role ) ) { $items[] = array( '@type' => 'ListItem', 'position' => 2, 'name' => ian3_roles()[$role], 'item' => ian3_url( $role ) ); }
        $items[] = array( '@type' => 'ListItem', 'position' => count( $items ) + 1, 'name' => get_the_title( $id ), 'item' => $url );
        $native_breadcrumb = false;
        if ( function_exists( 'WC' ) && WC()->structured_data ) { foreach ( WC()->structured_data->get_data() as $node ) { if ( in_array( 'BreadcrumbList', (array) $node['@type'], true ) ) { $native_breadcrumb = true; break; } } }
        if ( ! $native_breadcrumb ) { $graph[] = array( '@type' => 'BreadcrumbList', '@id' => $url . '#breadcrumb', 'itemListElement' => $items ); }
    }
    if ( is_singular( 'post' ) && 'insights' === ian3_article_kind( $id ) ) {
        $article = array( '@type' => 'Article', '@id' => $url . '#article', 'headline' => get_the_title( $id ), 'description' => ianseo_description( $id ), 'mainEntityOfPage' => $url, 'datePublished' => get_post_time( 'c', true, $id ), 'dateModified' => get_post_modified_time( 'c', true, $id ), 'author' => array( '@id' => home_url( '/#organization' ) ), 'publisher' => array( '@id' => home_url( '/#organization' ) ) );
        $image = get_the_post_thumbnail_url( $id, 'full' ); if ( $image ) { $article['image'] = $image; }
        $graph[] = $article;
    }
    echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_SLASHES ) . '</script>';
}, 11 );
// Refresh obsolete cached HTML once after a theme update, without changing any source content.
add_action( 'admin_init', function () {
    if ( current_user_can( 'manage_options' ) && get_option( 'ianseo_theme_version' ) !== IANPROJECT_VERSION ) {
        do_action( 'litespeed_purge_all' );
        update_option( 'ianseo_theme_version', IANPROJECT_VERSION, false );
    }
} );
