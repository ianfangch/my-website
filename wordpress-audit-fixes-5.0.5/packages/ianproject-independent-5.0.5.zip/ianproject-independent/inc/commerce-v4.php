<?php
defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/catalog-v4.php';
function ian4_product_view() {
    if ( ! function_exists( 'wc_get_product' ) || ! ( $p = wc_get_product( get_queried_object_id() ) ) ) { return ''; }
    if ( ! function_exists( 'ianq_cart_state' ) ) { ob_start(); wc_get_template( 'content-single-product.php' ); return ob_get_clean(); }
    $state = ianq_cart_state(); $product = ian4_product_payload( $p, $state['assets'] ); $state['products'][ $product['key'] ] = $product;
    $html = file_get_contents( get_theme_file_path( 'parts/product-v4.html' ) );
    $html = str_replace( array( '%%TITLE%%', '%%SUMMARY%%', '%%CATEGORY%%', '%%DESCRIPTION%%', '%%PRODUCTS_URL%%' ), array( esc_html( $product['name'] ), esc_html( $product['summary'] ), esc_html( $product['category'] ), apply_filters( 'the_content', ian5_sections( $p->get_description() )['details'] ?? '' ), esc_url(ian3_url('products')) ), $html );
    $sections = ian5_sections( $p->get_description() );
    $html = str_replace( array( '%%PACKING%%', '%%CUSTOMISATION%%' ), array( apply_filters( 'the_content', $sections['packing'] ?? '' ), apply_filters( 'the_content', $sections['customisation'] ?? '' ) ), $html );
    $data = array( 'data' => array( 'products' => $state['products'], 'assets' => $state['assets'] ), 'key' => $product['key'], 'state' => $state, 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'ian4_cart' ), 'nonceEndpoint' => function_exists( 'ianq_ajax_enquiry' ) ? WC_AJAX::get_endpoint( 'ianq_enquiry' ) : '', 'contact' => wc_get_checkout_url(), 'directContact' => ian4_contact_url( $p->get_id() ) );
    wp_enqueue_script( 'ian-commerce', get_theme_file_uri( 'assets/js/commerce-v4.js' ), array(), IANPROJECT_VERSION, true );
    return '<div class="ian-commerce">' . $html . '<p class="shell" id="commerce-status" role="alert"></p><script type="application/json" id="ian4-product-data">' . wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script><noscript><p class="shell">' . ian3_link( 'contact', 'Contact us about this product', 'button' ) . '</p></noscript></div>';
}
function ian4_cart_view() {
    $state = ianq_cart_state(); $html = '<div class="ian-commerce"><main class="shell section"><h1>Your project cart</h1><p>Review the selected configurations, then continue to Contact to confirm specifications, final pricing and delivery.</p>' . ( function_exists( 'wc_print_notices' ) ? wc_print_notices( true ) : '' );
    if ( ! $state['items'] ) { return $html . '<p class="cart-empty">Your cart is empty.</p>' . ian3_link( 'products', 'Explore products', 'button' ) . '</main></div>'; }
    $html .= '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="ian4_cart_update">'.wp_nonce_field('ian4_cart_update','ian4_cart_nonce',true,false).'<div class="native-cart-scroll"><table class="native-cart-table"><thead><tr><th>Product</th><th>Configuration</th><th>Quantity</th><th>Reference amount</th><th></th></tr></thead><tbody>';
    foreach ( $state['items'] as $i ) { $p = $state['products'][ $i['key'] ]; $m = null !== $i['model'] ? $p['models'][ $i['model'] ] : null; $html .= '<tr><td><a href="' . esc_url( get_permalink( $p['id'] ) ) . '">' . esc_html( $p['name'] ) . '</a></td><td>' . esc_html( $m['label'] ?? $p['code'] ) . '</td><td><input class="cart-quantity" type="number" name="cart_qty['.esc_attr($i['cartKey']).']" min="'.esc_attr($p['pricing']['minimumQuantity'] ?? $p['pricing']['step']).'" step="'.esc_attr($p['pricing']['step']).'" value="'.esc_attr($i['qty']).'"> ' . esc_html($p['pricing']['quantityUnit']) . '</td><td>' . esc_html( ian4_price_text( $m['pricing'] ?? $p['pricing'], $i['qty'] ) ) . '</td><td><button class="view-cart-link" name="remove" value="'.esc_attr($i['cartKey']).'">Remove</button></td></tr>'; }
    return $html . '</tbody></table></div><button class="button button-outline" name="update" style="margin-top:20px">Update quantities</button></form><div class="native-cart-actions"><a class="button" href="' . esc_url( wc_get_checkout_url() ) . '">Continue to Contact</a>' . ian3_link( 'products', 'Continue browsing', 'text-link' ) . '</div><p>No online payment is collected.</p></main></div>';
}

add_filter( 'ianq_product_presentation', function ( $fallback, $product, $assets ) { $data = ian4_product_payload( $product, $assets ); $data['_assets'] = $assets; return $data; }, 10, 3 );
add_filter( 'the_content', function ( $content ) {
    return function_exists( 'ianq_cart_state' ) && function_exists( 'is_cart' ) && is_cart() && get_the_ID() === (int) get_option( 'woocommerce_cart_page_id' ) ? ian4_cart_view() : $content;
}, 100 );
add_action( 'init', function () { add_shortcode( 'ian_wc_product', 'ian4_product_view' ); }, 1000 );
add_filter( 'pre_do_shortcode_tag', function( $value, $tag ) { return 'ian_page_heading' === $tag && function_exists( 'is_cart' ) && is_cart() ? '' : $value; }, 10, 2 );
// A usable Contact page remains available without the enquiry extension.
add_action( 'init', function () {
    if ( ! shortcode_exists( 'ian_quote_form' ) ) { add_shortcode( 'ian_quote_form', function () { $v = iansf_contacts(); return '<p><a href="' . esc_url( 'mailto:' . $v['email'] ) . '">Email us</a> · <a href="' . esc_url( iansf_whatsapp_url( $v ) ) . '">WhatsApp</a></p>'; } ); }
}, 30 );
