<?php
defined( 'ABSPATH' ) || exit;
function ianq_contact_url( $id = 0 ) {
    $map = (array) get_option( 'ian3_pages', array() );
    $page = absint( get_option( 'ianq_contact_page', $map['contact'] ?? 0 ) );
    $url = $page && 'publish' === get_post_status( $page ) ? get_permalink( $page ) : home_url( '/contact/' );
    return $id ? add_query_arg( 'ian_product', absint( $id ), $url ) : $url;
}
function ianq_contacts() {
    $values = (array) get_option( 'iansf_contacts', array() );
    return array_merge( array( 'email'=>'info@ianproject.com', 'whatsapp'=>'8619956229033', 'whatsapp_url'=>'' ), $values );
}
function ianq_whatsapp_url( $values = null ) {
    $values = $values ?? ianq_contacts();
    return $values['whatsapp_url'] ?: 'https://wa.me/' . preg_replace( '/\D/', '', $values['whatsapp'] );
}
function ianq_unit( $product ) {
    $value = $product->get_attribute( 'Pricing unit' );
    if ( ! $value && $product->is_type( 'variation' ) ) { $parent = wc_get_product( $product->get_parent_id() ); $value = $parent ? $parent->get_attribute( 'Pricing unit' ) : ''; }
    $value = strtolower( trim( $value ) );
    return in_array( $value, array( 'unit', 'set', 'metre', 'square metre' ), true ) ? $value : 'unit';
}
function ianq_minimum_quantity( $product ) {
    $step = in_array( ianq_unit( $product ), array( 'metre', 'square metre' ), true ) ? 0.1 : 1;
    $value = $product->get_attribute( 'Minimum order' );
    if ( ! $value && $product->is_type( 'variation' ) ) { $parent = wc_get_product( $product->get_parent_id() ); $value = $parent ? $parent->get_attribute( 'Minimum order' ) : ''; }
    // Only a plain native numeric MOQ in the same unit is an enforceable quantity.
    if ( preg_match( '/^\s*([0-9]+(?:\.[0-9]+)?)\s+(square metres?|metres?|sets?|units?)\s*$/i', $value, $match ) && rtrim( strtolower( $match[2] ), 's' ) === ianq_unit( $product ) ) {
        return max( $step, ceil( round( (float) $match[1] / $step, 6 ) ) * $step );
    }
    return $step;
}
function ianq_quantity( $product, $value ) {
    $step = in_array( ianq_unit( $product ), array( 'metre', 'square metre' ), true ) ? 0.1 : 1;
    $value = is_scalar( $value ) ? (float) $value : 1;
    $minimum = ianq_minimum_quantity( $product );
    return is_finite( $value ) ? max( $minimum, round( $value / $step ) * $step ) : $minimum;
}
add_filter( 'woocommerce_quantity_input_args', function ( $args, $product ) {
    if ( $product ) { $args['min_value'] = max( (float) $args['min_value'], ianq_minimum_quantity( $product ) ); $args['step'] = in_array( ianq_unit( $product ), array( 'metre', 'square metre' ), true ) ? 0.1 : 1; }
    return $args;
}, 20, 2 );
function ianq_validate_minimum_quantity( $passed, $product_id, $quantity, $variation_id = 0 ) {
    $product = wc_get_product( $variation_id ?: $product_id );
    if ( $product && (float) $quantity < ianq_minimum_quantity( $product ) ) { wc_add_notice( 'Please meet the product minimum order quantity.', 'error' ); return false; }
    return $passed;
}
add_filter( 'woocommerce_add_to_cart_validation', 'ianq_validate_minimum_quantity', 20, 4 );
add_filter( 'woocommerce_update_cart_validation', function ( $passed, $key, $item, $quantity ) {
    return (float) $quantity <= 0 ? $passed : ianq_validate_minimum_quantity( $passed, $item['product_id'], $quantity, $item['variation_id'] ?? 0 );
}, 20, 4 );
function ianq_can_purchase( $product ) {
    return '' !== $product->get_price( 'edit' ) && (float) $product->get_price( 'edit' ) > 0 && $product->is_purchasable() && $product->is_in_stock();
}
foreach ( array( 'woocommerce_is_purchasable', 'woocommerce_variation_is_purchasable' ) as $hook ) {
    add_filter( $hook, function ( $purchasable, $product ) {
        return $purchasable && '' !== $product->get_price( 'edit' ) && (float) $product->get_price( 'edit' ) > 0;
    }, 20, 2 );
}
function ianq_amount( $product, $quantity = 1 ) {
    if ( $product->is_type( 'variable' ) || '' === $product->get_price( 'edit' ) || (float) $product->get_price( 'edit' ) <= 0 ) { return 'Price to be confirmed'; }
    $amount = wc_get_price_to_display( $product, array( 'qty'=>$quantity, 'display_context'=>'cart' ) );
    return trim( html_entity_decode( wp_strip_all_tags( wc_price( $amount ) . $product->get_price_suffix( '', $quantity ) ), ENT_QUOTES, 'UTF-8' ) );
}
function ianq_product_summary( $product, $quantity = 1 ) {
    $parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
    $label = $product->is_type( 'variation' ) ? wc_get_formatted_variation( $product, true, false, false ) : ( $product->is_type( 'variable' ) ? 'To be confirmed' : $product->get_sku() );
    return 'Product: ' . $parent->get_name() . "\nConfiguration: " . html_entity_decode( wp_strip_all_tags( $label ), ENT_QUOTES, 'UTF-8' ) . "\nQuantity: " . $quantity . ' ' . ianq_unit( $product ) . ( 1.0 === (float) $quantity ? '' : 's' ) . "\nReference amount: " . ianq_amount( $product, $quantity );
}
add_action( 'admin_menu', function () { add_options_page( 'IanProject 询价', 'IanProject 询价', 'manage_options', 'ianproject-enquiry', 'ianq_settings' ); } );
function ianq_settings() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    if ( isset( $_POST['ianq_save'] ) ) {
        check_admin_referer( 'ianq_settings' );
        $id = absint( $_POST['contact_page'] ?? 0 );
        if ( $id && ( 'page' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) ) { echo '<div class="notice notice-error"><p>请选择已发布的联系页面。</p></div>'; }
        else {
            update_option( 'ianq_contact_page', $id, false );
            $contacts = ianq_contacts();
            if ( is_email( wp_unslash( $_POST['email'] ?? '' ) ) ) { $contacts['email'] = sanitize_email( wp_unslash( $_POST['email'] ) ); }
            $number = preg_replace( '/\D/', '', (string) wp_unslash( $_POST['whatsapp'] ?? '' ) );
            if ( preg_match( '/^[1-9][0-9]{6,14}$/', $number ) ) { $contacts['whatsapp'] = $number; }
            update_option( 'iansf_contacts', $contacts, false );
            echo '<div class="notice notice-success"><p>已保存。联系方式使用全站同一份数据。</p></div>';
        }
    }
    $contacts = ianq_contacts();
    echo '<div class="wrap"><h1>IanProject 询价</h1><p>只管理询价规则和草稿发送，不改变价格、税费、商品或主题设置。联系页放置 [ian_quote_form] 短代码。</p><form method="post">';
    wp_nonce_field( 'ianq_settings' );
    echo '<p>联系页面 '; wp_dropdown_pages( array( 'name'=>'contact_page', 'selected'=>absint( get_option( 'ianq_contact_page', 0 ) ), 'show_option_none'=>'使用网站 Contact 页面', 'option_none_value'=>0 ) );
    echo '</p><p><label>接收邮箱 <input type="email" name="email" required value="' . esc_attr( $contacts['email'] ) . '"></label></p><p><label>WhatsApp 号码 <input name="whatsapp" required value="' . esc_attr( $contacts['whatsapp'] ) . '"></label></p><p>EXW 标注直接使用 WooCommerce 的价格显示后缀。本插件没有独立价格标注或费用排除说明。</p><button class="button button-primary" name="ianq_save">保存</button></form></div>';
}

// Works with ordinary WooCommerce themes as well as IanProject's custom layout.
add_action( 'woocommerce_single_product_summary', function () {
    global $product;
    if ( ! $product || 'publish' !== $product->get_status() ) { return; }
    echo '<p class="ianq-native-contact"><a class="button" data-ianq-contact href="' . esc_url( ianq_contact_url( $product->get_id() ) ) . '">Contact about this product</a></p>';
    wp_enqueue_script( 'ianq-native-contact', plugins_url( '../assets/native-contact.js', __FILE__ ), array(), IANQ_VERSION, true );
}, 35 );
add_action( 'init', function () {
    if ( shortcode_exists( 'ian_contact' ) ) { return; }
    add_shortcode( 'ian_contact', function ( $atts ) {
        $atts=shortcode_atts(array('field'=>'email','label'=>'','link'=>'yes'),$atts);
        $values=ianq_contacts();$field=$atts['field'];$value=$values[$field]??'';
        if(!is_scalar($value)||!$value){return '';}
        $href='email'===$field?'mailto:'.$value:('whatsapp'===$field?ianq_whatsapp_url($values):('phone'===$field?'tel:+'.preg_replace('/\D/','',$value):''));
        $label=esc_html($atts['label']?:$value);
        return $href&&'no'!==$atts['link']?'<a href="'.esc_url($href).'">'.$label.'</a>':$label;
    });
}, 40 );
