<?php
defined( 'ABSPATH' ) || exit;

function ianq_private_response() {
    if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
    nocache_headers();
    if ( ! headers_sent() ) { header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' ); }
    do_action( 'litespeed_control_set_nocache', 'IanProject visitor enquiry' );
}
function ianq_is_enquiry_request() {
    $map = (array) get_option( 'ian3_pages', array() );
    $id = absint( get_option( 'ianq_contact_page', 0 ) ) ?: absint( $map['contact'] ?? 0 );
    if ( $id && is_page( $id ) ) { return true; }
    $post = is_singular() ? get_post( get_queried_object_id() ) : null;
    return $post && has_shortcode( $post->post_content, 'ian_quote_form' );
}
add_action( 'wp', function () {
    if ( ! is_admin() && ( ianq_is_enquiry_request() || ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) ) ) { ianq_private_response(); }
}, 0 );
add_filter( 'wp_robots', function ( $robots ) {
    if ( ianq_is_enquiry_request() && ( isset( $_GET['cart'] ) || isset( $_GET['ian_product'] ) ) ) { unset( $robots['index'] ); $robots['noindex'] = true; }
    return $robots;
} );
/** Read-only session endpoint, like WooCommerce's native cart fragments endpoint. */
function ianq_ajax_enquiry() {
    ianq_private_response();
    if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) { wp_send_json_error( array( 'message' => 'Use POST.' ), 405 ); }
    $mode = isset( $_POST['context'] ) && is_scalar( $_POST['context'] ) ? sanitize_key( wp_unslash( $_POST['context'] ) ) : '';
    if ( ! in_array( $mode, array( 'cart', 'product', 'nonce' ), true ) ) { wp_send_json_error( array( 'message' => 'Invalid enquiry context.' ), 400 ); }
    if ( 'nonce' === $mode ) { wp_send_json_success( array( 'nonce' => wp_create_nonce( 'ian4_cart' ) ) ); }
    if ( 'cart' === $mode ) {
        $text = ianq_cart_summary_text();
        if ( $text ) { $text .= "\n\nRequirements:"; }
    } else {
        $values = array();
        foreach ( array( 'product', 'variation', 'quantity' ) as $key ) {
            if ( isset( $_POST[$key] ) && ! is_scalar( $_POST[$key] ) ) { wp_send_json_error( array( 'message' => 'Invalid product request.' ), 400 ); }
            $values[$key] = isset( $_POST[$key] ) ? wp_unslash( $_POST[$key] ) : 0;
        }
        $text = ianq_direct_enquiry( absint( $values['product'] ), absint( $values['variation'] ), $values['quantity'] ?: 1 );
        if ( ! $text ) { wp_send_json_error( array( 'message' => 'This product is unavailable. Enter your requirements below.' ), 404 ); }
    }
    wp_send_json_success( array( 'requirements' => $text ) );
}
add_action( 'wc_ajax_ianq_enquiry', 'ianq_ajax_enquiry' );
// Run once after installing/updating the extension; no content or cache settings are rewritten.
add_action( 'init', function () {
    if ( get_option( 'ianq_runtime_version' ) !== IANQ_VERSION ) {
        do_action( 'litespeed_purge_all' );
        update_option( 'ianq_runtime_version', IANQ_VERSION, false );
    }
}, 2000 );
