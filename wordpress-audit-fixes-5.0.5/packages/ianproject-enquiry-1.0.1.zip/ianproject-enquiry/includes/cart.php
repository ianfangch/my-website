<?php
defined( 'ABSPATH' ) || exit;
function ianq_load_cart() {
    if ( ! function_exists( 'WC' ) ) { return false; }
    if ( null === WC()->cart && did_action( 'woocommerce_init' ) ) { wc_load_cart(); }
    if ( WC()->cart ) { WC()->cart->get_cart(); }
    return (bool) WC()->cart;
}
function ianq_cart_state() {
    $state = array( 'items' => array(), 'products' => array(), 'assets' => array() );
    if ( ! ianq_load_cart() ) { return $state; }
    foreach ( WC()->cart->get_cart() as $key => $item ) {
        $p = wc_get_product( $item['product_id'] ); if ( ! $p ) { continue; }
        $pk = 'p' . $p->get_id();
        if ( ! isset( $state['products'][ $pk ] ) ) { $state['products'][ $pk ] = apply_filters( 'ianq_product_presentation', array( 'id'=>$p->get_id(), 'name'=>$p->get_name(), 'models'=>array() ), $p, $state['assets'] ); }
        if ( ! empty( $state['products'][ $pk ]['_assets'] ) ) { $state['assets'] = array_merge( $state['assets'], $state['products'][ $pk ]['_assets'] ); unset( $state['products'][ $pk ]['_assets'] ); }
        $model = null;
        foreach ( $state['products'][ $pk ]['models'] as $index => $variation ) { if ( $variation['id'] === (int) ( $item['variation_id'] ?? 0 ) ) { $model = $index; break; } }
        $state['items'][] = array( 'key' => $pk, 'model' => $model, 'qty' => (float) $item['quantity'], 'cartKey' => $key );
    }
    return $state;
}
add_filter( 'woocommerce_get_checkout_url', function ( $url ) { return add_query_arg( 'cart', '1', ianq_contact_url() ); } );
add_action( 'template_redirect', function () { if ( function_exists( 'is_checkout' ) && is_checkout() && ! is_wc_endpoint_url() ) { wp_safe_redirect( add_query_arg( 'cart', '1', ianq_contact_url() ), 302 ); exit; } }, 4 );
// This site's cart gathers quotations; website checkout must not create orders.
add_action( 'woocommerce_checkout_process', function () { wc_add_notice( 'Please continue to Contact to confirm your quotation. Online checkout is not available.', 'error' ); } );
add_filter( 'rest_pre_dispatch', function ( $result, $server, $request ) {
    if ( 'OPTIONS' !== $request->get_method() && preg_match( '~^/wc/store/v[0-9]+/checkout(?:/|$)~', $request->get_route() ) ) {
        return new WP_Error( 'ian_contact_checkout', 'Please continue to Contact to confirm your quotation.', array( 'status' => 409, 'contact' => add_query_arg( 'cart', '1', ianq_contact_url() ) ) );
    }
    return $result;
}, 10, 3 );

function ianq_cart_request( $data ) {
    if ( ! ianq_load_cart() ) { return new WP_Error( 'ian_cart', 'The cart is unavailable. Please contact us.' ); }
    $op = sanitize_key( $data['op'] ?? 'get' );
    if ( in_array( $op, array( 'update', 'remove' ), true ) ) {
        $key = sanitize_text_field( $data['key'] ?? '' ); $item = WC()->cart->get_cart_item( $key );
        if ( ! $item ) { return new WP_Error( 'ian_cart_item', 'This item is no longer in your cart. Refresh and try again.' ); }
        if ( 'remove' === $op ) { WC()->cart->remove_cart_item( $key ); }
        else {
            $p = $item['data']; $qty = ianq_quantity( $p, $data['qty'] ?? 1 );
            if ( ! $item['data']->has_enough_stock( $qty ) ) { return new WP_Error( 'ian_stock', 'Please contact us to confirm this quantity.' ); }
            WC()->cart->set_quantity( $key, $qty );
        }
    } elseif ( in_array( $op, array( 'add', 'contact' ), true ) ) {
        $id = absint( $data['product'] ?? 0 ); $variation = absint( $data['variation'] ?? 0 ); $p = wc_get_product( $id );
        if ( ! $p || 'publish' !== $p->get_status() || $p->is_type( 'variation' ) || post_password_required( $id ) ) { return new WP_Error( 'ian_product', 'This product is unavailable.' ); }
        $attrs = array();
        if ( $p->is_type( 'variable' ) ) {
            $v = wc_get_product( $variation );
            if ( ! $v || ! $v->is_type( 'variation' ) || $v->get_parent_id() !== $id || 'publish' !== $v->get_status() || ! $v->variation_is_active() ) { return new WP_Error( 'ian_variation', 'Please select an available configuration.' ); }
            $attrs = $v->get_variation_attributes();
        } elseif ( ! $p->is_type( 'simple' ) ) { return new WP_Error( 'ian_type', 'Please contact us about this product.' ); }
        if ( ! ianq_can_purchase( $variation ? $v : $p ) ) { return new WP_Error( 'ian_exw_price', 'This configuration has no confirmed price. Please use Contact to request a quotation.' ); }
        $qty = ianq_quantity( $variation ? $v : $p, $data['qty'] ?? 1 );
        $existing = '';
        if ( 'contact' === $op ) { foreach ( WC()->cart->get_cart() as $key => $item ) { if ( (int) $item['product_id'] === $id && (int) ( $item['variation_id'] ?? 0 ) === $variation ) { $existing = $key; break; } } }
        if ( $existing ) {
            $item = WC()->cart->get_cart_item( $existing );
            if ( ! $item['data']->has_enough_stock( $qty ) ) { return new WP_Error( 'ian_stock', 'Please contact us to confirm this quantity.' ); }
            WC()->cart->set_quantity( $existing, $qty );
        } elseif ( ! WC()->cart->add_to_cart( $id, $qty, $variation, $attrs ) ) {
            $notices = wc_get_notices( 'error' ); wc_clear_notices();
            return new WP_Error( 'ian_add_cart', $notices ? wp_strip_all_tags( $notices[0]['notice'] ) : 'Unable to add this configuration. Please contact us.' );
        }
    } elseif ( 'get' !== $op ) { return new WP_Error( 'ian_cart_action', 'Unsupported cart action.' ); }
    WC()->cart->calculate_totals(); WC()->cart->set_session();
    return ianq_cart_state();
}
foreach ( array( 'wp_ajax_ian4_cart', 'wp_ajax_nopriv_ian4_cart' ) as $hook ) {
    add_action( $hook, function () {
        check_ajax_referer( 'ian4_cart', 'nonce' ); $input = array();
        foreach ( array( 'op', 'key', 'qty', 'product', 'variation' ) as $name ) { if ( isset( $_POST[ $name ] ) && is_scalar( $_POST[ $name ] ) ) { $input[ $name ] = wp_unslash( $_POST[ $name ] ); } }
        $r = ianq_cart_request( $input ); if ( is_wp_error( $r ) ) { wp_send_json_error( array( 'message' => $r->get_error_message() ), 400 ); } wp_send_json_success( $r );
    } );
}

function ianq_cart_summary_text() {
    if ( ! ianq_load_cart() ) { return ''; }
    $rows = array();
    foreach ( WC()->cart->get_cart() as $item ) { $rows[] = ianq_product_summary( $item['data'], $item['quantity'] ); }
    return implode( "\n\n", $rows );
}
add_filter( 'woocommerce_stock_amount', 'floatval', 30 );
foreach(array('admin_post_ian4_cart_update','admin_post_nopriv_ian4_cart_update') as $hook){add_action($hook,function(){check_admin_referer('ian4_cart_update','ian4_cart_nonce');if(isset($_POST['remove'])&&is_scalar($_POST['remove'])){$r=ianq_cart_request(array('op'=>'remove','key'=>sanitize_text_field(wp_unslash($_POST['remove']))));}else{foreach((array)($_POST['cart_qty']??array()) as $key=>$qty){if(!is_scalar($qty))continue;$r=ianq_cart_request(array('op'=>'update','key'=>sanitize_text_field($key),'qty'=>wp_unslash($qty)));if(is_wp_error($r))break;}}if(isset($r)&&is_wp_error($r))wc_add_notice($r->get_error_message(),'error');wp_safe_redirect(wc_get_cart_url());exit;});}

