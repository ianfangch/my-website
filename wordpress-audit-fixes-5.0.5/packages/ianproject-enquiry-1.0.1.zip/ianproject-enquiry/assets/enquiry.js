/* The visitor reviews and sends the message in their own email / WhatsApp. */
(() => {
 'use strict';
 const form=document.getElementById('quote-builder-form'),config=window.IAN_ENQUIRY;
 if(!form||!config)return;
 const $=id=>document.getElementById('request-'+id),feedback=$('feedback'),preview=$('preview'),wrap=$('preview-wrap'),manual=$('manual');
 const subject='IanProject project request';
 function prepare(){
  if(loading||!form.reportValidity())return null;
  const website=$('website').value.trim();
  if(website){try{const u=new URL(/^https?:\/\//i.test(website)?website:'https://'+website);if(!['http:','https:'].includes(u.protocol)||!u.hostname.includes('.'))throw Error();$('website').setCustomValidity('');}catch(e){$('website').setCustomValidity('Enter a valid company website or leave it blank.');$('website').reportValidity();return null;}}
  const body='IanProject project request\n\nName: '+$('name').value.trim()+'\nCompany website: '+(website||'Not provided')+'\nCountry: '+$('country').value.trim()+'\nTrade terms: '+$('terms').value+'\n\nRequirements:\n'+$('requirements').value.trim()+'\n\nPlease confirm the specifications, final price, packing and delivery.';
  preview.value=body;wrap.hidden=false;manual.hidden=true;manual.replaceChildren();return body;
 }
 $('website').addEventListener('input',()=>$('website').setCustomValidity(''));
 function launch(url,newTab){const a=document.createElement('a');a.href=url;if(newTab){a.target='_blank';a.rel='noopener noreferrer';}document.body.append(a);a.click();a.remove();}
 function longMessage(url,label){wrap.open=true;manual.hidden=false;const p=document.createElement('p');p.className='small';p.textContent='This request is long. Copy it below, open '+label+', then paste it into your message.';const a=document.createElement('a');a.href=url;a.textContent='Open '+label+' and paste your request';a.target='_blank';a.rel='noopener noreferrer';manual.append(p,a);feedback.textContent='Your complete request is ready to copy. No message has been sent.';preview.focus();preview.select();}
 function email(){const body=prepare();if(!body)return;const short='mailto:'+config.email+'?subject='+encodeURIComponent(subject),url=short+'&body='+encodeURIComponent(body);if(url.length>1900){longMessage(short,'your email app');return;}launch(url,false);feedback.textContent='Review your draft in your email app and press Send there. If no email app opens, copy the request and email it to '+config.email+'.';}
 function whatsapp(){const body=prepare();if(!body)return;let url;try{url=new URL(config.whatsapp);if(url.protocol!=='https:')throw Error();}catch(e){feedback.textContent='WhatsApp is unavailable. Please use email or copy your request.';return;}const base=url.href;url.searchParams.set('text',body);if(url.href.length>7000){longMessage(base,'WhatsApp');return;}launch(url.href,true);feedback.textContent='Review your message in WhatsApp and press Send there. No message is sent automatically.';}
 async function copy(){const body=prepare();if(!body)return;try{await navigator.clipboard.writeText(body);feedback.textContent='Request copied. Paste it into your email or WhatsApp and send it there.';}catch(e){wrap.open=true;preview.focus();preview.select();feedback.textContent='Select and copy the prepared request, then paste it into your email or WhatsApp.';}}
 const buttons=[$('email'),$('whatsapp'),$('copy')],params=new URLSearchParams(location.search);
 const context=params.get('cart')==='1'?'cart':(/^\d+$/.test(params.get('ian_product')||'')?'product':'');
 let autoText='',loading=false;
 const retry=document.createElement('button');retry.type='button';retry.className='btn btn-outline-primary mt-2';retry.textContent='Reload selected products';retry.hidden=true;feedback.after(retry);
 function setLoading(value){loading=value;buttons.forEach(button=>button.disabled=value);}
 async function loadSelection(){
  if(!context||!config.endpoint){setLoading(false);return;}
  setLoading(true);retry.hidden=true;feedback.textContent='Loading your selected products…';
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000),data=new URLSearchParams({context});
  if(context==='product'){data.set('product',params.get('ian_product'));data.set('variation',params.get('ian_variation')||'0');data.set('quantity',params.get('ian_quantity')||'1');}
  try{
   const response=await fetch(config.endpoint,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:data,signal:controller.signal}),result=await response.json();
   if(!response.ok||!result.success||typeof result.data?.requirements!=='string')throw Error('unavailable');
   const field=$('requirements'),text=result.data.requirements;
   let notes=field.value;if(autoText&&notes.startsWith(autoText))notes=notes.slice(autoText.length).trimStart();
   field.value=text+(notes?(text?'\n\n':'')+notes:'');autoText=text;
   feedback.textContent=text?'Your selected products are ready. Add any requirements below.':(context==='cart'?'Your cart is empty. Browse products or enter your requirements below.':'Enter your requirements below.');
  }catch(error){feedback.textContent='Your selected products could not be loaded. Reload them, or enter your requirements manually.';retry.hidden=false;}
  finally{clearTimeout(timer);setLoading(false);}
 }
 retry.addEventListener('click',loadSelection);
 window.addEventListener('pageshow',event=>{if(event.persisted&&context&&!loading)loadSelection();});
 if(context){$('requirements').value='';loadSelection();}else setLoading(false);
 $('email').addEventListener('click',email);$('whatsapp').addEventListener('click',whatsapp);$('copy').addEventListener('click',copy);
 form.addEventListener('submit',event=>{event.preventDefault();email();});
})();
