/* Native links remain usable if JavaScript or YouTube is unavailable. */
(()=>{
 const coverFallback=image=>{
  if(!image.matches?.('.ian-video-cover'))return;
  const fallback=image.dataset.ianFallback;delete image.dataset.ianFallback;
  if(fallback)image.src=fallback;else image.hidden=true;
 };
 document.addEventListener('error',event=>coverFallback(event.target),true);
 document.querySelectorAll('.ian-video-cover').forEach(image=>{if(image.complete&&!image.naturalWidth)coverFallback(image);});
 document.addEventListener('click',event=>{
  if(event.defaultPrevented||event.button>0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
  const trigger=event.target.closest?.('a.ian-video-trigger');
  if(!trigger)return;
  const video=trigger.closest('.ian-video'),id=video?.dataset.ianYoutube;
  if(!id||!/^[A-Za-z0-9_-]{11}$/.test(id)||video.querySelector('iframe'))return;
  event.preventDefault();
  const player=document.createElement('iframe'),url=new URL('https://www.youtube-nocookie.com/embed/'+id);
  url.searchParams.set('autoplay','1');url.searchParams.set('playsinline','1');url.searchParams.set('rel','0');
  const start=Number(video.dataset.ianStart);if(Number.isSafeInteger(start)&&start>0)url.searchParams.set('start',String(Math.min(start,604800)));
  player.title=video.dataset.ianTitle||'YouTube video';player.allow='autoplay; encrypted-media; picture-in-picture; fullscreen';
  player.allowFullscreen=true;player.referrerPolicy='strict-origin-when-cross-origin';
  player.src=url.href;video.replaceChildren(player);video.classList.add('is-playing');
  player.focus();
 });
})();
