<?php
defined('ABSPATH')||exit;
function ian3_product_detail(){return function_exists('ian4_product_view')?ian4_product_view():'';}
function ian3_basic_catalogue(){return '<p>'.ian3_link('contact','Contact').'</p>';}
