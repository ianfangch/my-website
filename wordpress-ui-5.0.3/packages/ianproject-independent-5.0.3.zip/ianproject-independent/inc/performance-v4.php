<?php
defined( 'ABSPATH' ) || exit;

/** Presentation only: use WordPress media sizes, never generate a private image cache. */
function ianperf_native_image( $html, $eager = false ) {
    return preg_replace_callback( '~<img\b[^>]*>~i', function ( $match ) use ( $eager ) {
        $tag = new WP_HTML_Tag_Processor( $match[0] ); $tag->next_tag( 'IMG' );
        $class = (string) $tag->get_attribute( 'class' );
        $id = preg_match( '/wp-image-([0-9]+)/', $class, $m ) ? absint( $m[1] ) : attachment_url_to_postid( (string) $tag->get_attribute( 'src' ) );
        $attrs = array( 'alt'=>(string) $tag->get_attribute('alt'), 'class'=>$class, 'loading'=>$eager?'eager':'lazy', 'decoding'=>'async', 'fetchpriority'=>$eager?'high':'low', 'sizes'=>'(max-width: 767px) calc(100vw - 48px), 60vw' );
        if ( $id ) { $image = wp_get_attachment_image( $id, '1536x1536', false, $attrs ); if ( $image ) { return $image; } }
        foreach ( $attrs as $name=>$value ) { $tag->set_attribute( $name, $value ); }
        return $tag->get_updated_html();
    }, $html, 1 );
}
add_filter( 'render_block_core/group', function ( $html, $block ) {
    if ( is_admin() || ! is_front_page() || ! in_array( 'ih-hero-photo', explode( ' ', $block['attrs']['className'] ?? '' ), true ) ) { return $html; }
    return ianperf_native_image( $html, true );
}, 20, 2 );
add_filter( 'render_block_core/html', function ( $html ) {
    return !is_admin() && is_front_page() && str_contains($html,'ih-original-cover') ? ianperf_native_image($html) : $html;
}, 20 );
add_action( 'wp_head', function () {
    foreach ( array( 0, 4 ) as $font ) { echo '<link rel="preload" href="' . esc_url( get_theme_file_uri( 'assets/vendor/fonts/ian-font-' . $font . '.woff2?v=4.0.2' ) ) . '" as="font" type="font/woff2" crossorigin>' . "\n"; }
}, 1 );
