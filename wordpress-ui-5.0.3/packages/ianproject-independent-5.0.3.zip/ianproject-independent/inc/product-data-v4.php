<?php
defined( 'ABSPATH' ) || exit;

/** Persistent data uses WooCommerce products/variations and ordinary post meta. */
function ian4_has_native_price( $product ) {
    $raw = $product->get_price( 'edit' );
    return '' !== $raw && is_numeric( $raw ) && (float) $raw > 0;
}
/** Reuse WooCommerce's suffix setting and native tax-status/filter rules. */
function ian4_price_suffix( $product ) {
    return trim( html_entity_decode( wp_strip_all_tags( $product->get_price_suffix() ), ENT_QUOTES, 'UTF-8' ) );
}
function ian4_can_purchase( $product ) { return ian4_has_native_price( $product ) && $product->is_purchasable() && $product->is_in_stock(); }
function ian4_pricing( $product, $parent = null ) {
    $unit = ian5_product_unit( $product, $parent );
    $base = array( 'currency' => get_woocommerce_currency(), 'min' => null, 'max' => null, 'prefix' => '', 'unit' => 'per ' . $unit, 'quantityUnit' => $unit . 's', 'step' => in_array( $unit, array( 'metre', 'square metre' ), true ) ? 0.1 : 1, 'source' => 'unpriced', 'suffix' => ian4_price_suffix( $product ) );
    if ( $product->is_type( 'variable' ) ) {
        $prices = array(); $missing = 0;
        foreach ( $product->get_children() as $id ) {
            $v = wc_get_product( $id );
            if ( ! $v || 'publish' !== $v->get_status() || ! $v->variation_is_active() || ! $v->is_in_stock() ) { continue; }
            if ( ian4_has_native_price( $v ) ) { $prices[] = (float) wc_get_price_to_display( $v ); } else { ++$missing; }
        }
        if ( $prices ) { $base['min'] = min( $prices ); $base['max'] = max( $prices ); $base['prefix'] = $missing ? 'From' : ''; $base['source'] = 'native'; return $base; }
    } elseif ( ian4_has_native_price( $product ) ) {
        $base['min'] = (float) wc_get_price_to_display( $product );
        $base['source'] = 'native';
        return $base;
    }
    return $base;
}
function ian4_price_text( $pricing, $qty = 1 ) {
    if ( null === $pricing['min'] ) { return 'Price to be confirmed'; }
    $prefix = 'USD' === $pricing['currency'] ? 'US$' : $pricing['currency'] . ' ';
    $lo = $pricing['min'] * $qty; $hi = ( $pricing['max'] ?? $pricing['min'] ) * $qty;
    return ( 'from' === strtolower( $pricing['prefix'] ) ? 'From ' : '' ) . $prefix . number_format( $lo, 2, '.', ',' ) . ( $hi > $lo && 'from' !== strtolower( $pricing['prefix'] ) ? '–' . number_format( $hi, 2, '.', ',' ) : '' ) . ( '' !== ( $pricing['suffix'] ?? '' ) ? ' ' . $pricing['suffix'] : '' );
}
function ian4_attributes( $product ) {
    $out = array();
    foreach ( $product->get_attributes() as $name => $attr ) {
        if ( is_object( $attr ) ) {
            if ( ! $attr->get_visible() || $attr->get_variation() ) { continue; }
            $out[ wc_attribute_label( $name ) ] = $product->get_attribute( $name );
        } elseif ( is_scalar( $attr ) && '' !== (string) $attr ) { $out[ wc_attribute_label( $name ) ] = $product->get_attribute( $name ) ?: (string) $attr; }
    }
    if ( $product->is_type( 'variation' ) ) { $sections = ian5_sections( $product->get_description() ); $out = array_merge( $out, ian5_table_pairs( $sections['attributes'] ?? '' ) ); }
    return $out;
}
function ian4_asset( $id, &$assets ) {
    $id = absint( $id ); $image = wp_get_attachment_image_src( $id, 'full' );
    if ( ! $image ) { return ''; }
    $key = 'attachment-' . $id;
    $assets[ $key ] = array( 'src' => $image[0], 'width' => $image[1], 'height' => $image[2], 'bounds' => null );
    return $key;
}
function ian4_product_payload( $product, &$assets ) {
    $id = $product->get_id(); $pricing = ian4_pricing( $product );
    $assets['placeholder']=array('src'=>wc_placeholder_img_src('full'),'width'=>800,'height'=>600,'bounds'=>null);
    $images = array_values( array_filter( array_map( function($i) use (&$assets){return ian4_asset($i,$assets);}, array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) ) ) );
    if ( ! $images ) { $key = 'placeholder'; $assets[ $key ] = array( 'src' => wc_placeholder_img_src( 'full' ), 'width' => 800, 'height' => 600, 'bounds' => null ); $images[] = $key; }
    $models = array();
    if ( $product->is_type( 'variable' ) ) {
        foreach ( $product->get_children() as $vid ) {
            $v = wc_get_product( $vid ); if ( ! $v || 'publish' !== $v->get_status() || ! $v->variation_is_active() || ! $v->is_in_stock() ) { continue; }
            $attrs = array_merge( ian4_attributes( $product ), ian4_attributes( $v ) );
            $label = implode( ' · ', array_values( array_filter( array_map( fn( $name ) => $v->get_attribute( $name ), array_keys( $v->get_attributes() ) ) ) ) );
            if ( ! $label ) { $label = $v->get_sku() ?: 'Configuration ' . $vid; }
            $sections = ian5_sections( $v->get_description() ); $model_ids = array( $v->get_image_id() ); if ( preg_match_all( '/wp-image-([0-9]+)/', $sections['model-gallery'] ?? '', $matches ) ) { $model_ids = array_merge( $model_ids, array_map( 'absint', $matches[1] ) ); } $model_images = array_values( array_filter( array_map( function($i) use (&$assets){return ian4_asset($i,$assets);}, array_unique( array_filter( $model_ids ) ) ) ) );
            $own_price = ian4_has_native_price( $v ) ? ian4_pricing( $v, $product ) : null;
            $code = ( $attrs['Model'] ?? $v->get_sku() ) ?: $label;
            $size = $attrs['Overall dimensions'] ?? $attrs['Product dimensions'] ?? $attrs['Dimensions'] ?? $v->get_dimensions( false );
            if ( is_array( $size ) ) { $size = implode( ' × ', array_filter( $size ) ); }
            $models[] = array( 'id' => $vid, 'code' => $code, 'size' => $size, 'cutout' => $attrs['Cutout'] ?? '', 'note' => $attrs['Features'] ?? '', 'label' => $label, 'attrs' => $attrs, 'images' => $model_images ?: $images, 'pricing' => $own_price, 'purchasable' => ian4_can_purchase( $v ), 'packingHtml' => wp_kses_post( do_blocks( $sections['packing'] ?? '' ) ), 'packaging' => ian5_table_pairs( $sections['packing'] ?? '' ), 'packagingMedia' => ian4_packing_media( $v, $assets ), 'cells' => array( $code, $label, $size ?: '—', $attrs['Features'] ?? $attrs['Bin configuration'] ?? '—' ) );
        }
    }
    $sections = ian5_sections( $product->get_description() );
    $terms = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'names' ) );
    $related = array();
    foreach ( wc_get_related_products( $id, 3 ) as $rid ) { $rp = wc_get_product( $rid ); if ( $rp && $rp->is_visible() ) { $related[] = array( 'name' => $rp->get_name(), 'code' => $rp->get_sku(), 'image' => ian4_asset( $rp->get_image_id(), $assets ) ?: 'placeholder', 'url' => get_permalink( $rid ) ); } }
    return array( 'key' => 'p' . $id, 'id' => $id, 'name' => $product->get_name(), 'category' => is_wp_error( $terms ) ? '' : implode( ', ', $terms ), 'code' => $product->get_sku(), 'summary' => wp_strip_all_tags( $product->get_short_description() ), 'images' => $images, 'imageFocus' => array(), 'imageFit'=>'contain', 'galleryScope' => $models ? 'model' : 'product', 'models' => $models, 'specs' => ian4_attributes( $product ), 'packingHtml' => wp_kses_post( do_blocks( $sections['packing'] ?? '' ) ), 'packaging' => ian5_table_pairs( $sections['packing'] ?? '' ), 'packagingMedia' => ian4_packing_media( $product, $assets ), 'moq' => $product->get_attribute( 'Minimum order' ), 'leadTime' => $product->get_attribute( 'Production lead time' ), 'pricing' => $pricing, 'purchasable' => ian4_can_purchase( $product ), 'highlights' => array(), 'customisation' => array(), 'related' => $related, 'columns' => array( 'Model', 'Configuration', 'Dimensions', 'Features' ), 'overview' => '', 'detailGallery' => array() );
}
function ian4_packing_media( $product, &$assets ) {
    $sections = ian5_sections( $product->get_description() );
    if ( preg_match( '/wp-image-([0-9]+)/', $sections['packing'] ?? '', $match ) ) {
        $key = ian4_asset( absint( $match[1] ), $assets );
        return $key ? array( 'image' => $key, 'caption' => 'Packaging' ) : null;
    }
    return null;
}
