<?php
defined( 'ABSPATH' ) || exit;

/** Only meaningful quote text enables a reserved review card on the front end. */
function ianproject_home_quote_text( $block ) {
    $text = '';
    foreach ( $block['innerBlocks'] ?? array() as $child ) {
        if ( 'core/paragraph' === ( $child['blockName'] ?? '' ) ) { $text .= wp_strip_all_tags( $child['innerHTML'] ?? '' ); }
        $text .= ianproject_home_quote_text( $child );
    }
    return trim( preg_replace( '/[\s\x{00A0}\x{200B}]+/u', ' ', $text ) );
}
function ianproject_home_has_review( $block ) {
    if ( 'core/quote' === ( $block['blockName'] ?? '' ) && ianproject_home_quote_text( $block ) ) { return true; }
    foreach ( $block['innerBlocks'] ?? array() as $child ) { if ( ianproject_home_has_review( $child ) ) { return true; } }
    return false;
}
add_filter( 'render_block', function ( $html, $block ) {
    if ( is_admin() ) { return $html; }
    $classes = preg_split( '/\s+/', $block['attrs']['className'] ?? '' );
    if ( in_array( 'ih-review-card', $classes, true ) && ! ianproject_home_quote_text( $block ) ) { return ''; }
    if ( in_array( 'ih-reviews', $classes, true ) ) {
        if ( ! ianproject_home_has_review( $block ) ) { return ''; }
        $p = new WP_HTML_Tag_Processor( $html );
        if ( $p->next_tag() ) { $p->remove_class( 'ih-review-pending' ); }
        return $p->get_updated_html();
    }
    return $html;
}, 35, 2 );

