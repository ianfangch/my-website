<?php
defined( 'ABSPATH' ) || exit;

/** Read ordinary, editable core-block sections; no legacy product metadata. */
function ian5_sections( $content ) {
    $sections = array( 'details' => '' ); $current = 'details';
    $heading_key = static function( $heading ) {
        $label = strtolower( trim( html_entity_decode( wp_strip_all_tags( $heading ), ENT_QUOTES, 'UTF-8' ) ) );
        return array( 'product details'=>'details', 'packing & delivery'=>'packing', 'packaging & delivery'=>'packing', 'packing and delivery'=>'packing', 'customisation'=>'customisation', 'customisation options'=>'customisation', 'customization'=>'customisation', 'customization options'=>'customisation', 'product attributes'=>'attributes', 'additional images'=>'model-gallery' )[ $label ] ?? '';
    };
    foreach ( parse_blocks( $content ) as $block ) {
        $classes = preg_split( '/\s+/', $block['attrs']['className'] ?? '' );
        $key = '';
        foreach ( array( 'packing', 'customisation', 'attributes', 'model-gallery', 'project-information' ) as $name ) {
            if ( in_array( 'ian-' . $name, $classes, true ) ) { $key = $name; break; }
        }
        if ( $key ) { $sections[ $key ] = ( $sections[ $key ] ?? '' ) . serialize_block( $block ); continue; }
        if ( 'core/heading' === $block['blockName'] ) {
            $next = $heading_key( $block['innerHTML'] );
            if ( $next ) { $current = $next; continue; }
        }
        // Ordinary WooCommerce classic descriptions can use standard headings too.
        if ( in_array( $block['blockName'], array( null, 'core/freeform', 'core/html' ), true ) && ! preg_match( '~<(?:div|section)\b~i', $block['innerHTML'] ) ) {
            $parts=preg_split('~(<h[23]\b[^>]*>.*?</h[23]>)~is',$block['innerHTML'],-1,PREG_SPLIT_DELIM_CAPTURE);
            foreach($parts as $piece){$next=preg_match('~^<h[23]\b~i',$piece)?$heading_key($piece):'';if($next){$current=$next;}else{$sections[$current]=($sections[$current]??'').$piece;}}
            continue;
        }
        $sections[ $current ] = ( $sections[ $current ] ?? '' ) . serialize_block( $block );
    }
    return $sections;
}
function ian5_table_pairs( $content ) {
    $pairs = array();
    if ( preg_match_all( '~<tr\b[^>]*>\s*<(?:th|td)\b[^>]*>(.*?)</(?:th|td)>\s*<td\b[^>]*>(.*?)</td>\s*</tr>~is', $content, $rows, PREG_SET_ORDER ) ) {
        foreach ( $rows as $row ) {
            $name = trim( html_entity_decode( wp_strip_all_tags( $row[1] ), ENT_QUOTES, 'UTF-8' ) );
            $value = trim( html_entity_decode( wp_strip_all_tags( $row[2] ), ENT_QUOTES, 'UTF-8' ) );
            if ( '' !== $name && '' !== $value ) { $pairs[ $name ] = $value; }
        }
    }
    return $pairs;
}
function ian5_product_attribute( $product, $name, $parent = null ) {
    $value = $product->get_attribute( $name );
    return '' !== $value ? $value : ( $parent ? $parent->get_attribute( $name ) : '' );
}
function ian5_product_unit( $product, $parent = null ) {
    $unit = strtolower( trim( ian5_product_attribute( $product, 'Pricing unit', $parent ) ) );
    $units = array( 'unit'=>'unit', 'units'=>'unit', 'piece'=>'unit', 'pieces'=>'unit', 'set'=>'set', 'sets'=>'set', 'metre'=>'metre', 'meter'=>'metre', 'm'=>'metre', 'square metre'=>'square metre', 'm²'=>'square metre' );
    return $units[ $unit ] ?? 'unit';
}
function ian5_post_info( $id, $key ) {
    $sections = ian5_sections( get_post_field( 'post_content', $id ) );
    $pairs = ian5_table_pairs( $sections['project-information'] ?? '' );
    $labels = array( 'region'=>'Region', 'location'=>'Location', 'project_type'=>'Project type', 'scope'=>'Products', 'materials'=>'Materials', 'insight_topic'=>'Topic' );
    return $pairs[ $labels[ $key ] ?? $key ] ?? '';
}
