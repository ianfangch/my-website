<?php
defined( 'ABSPATH' ) || exit;

function ian_ui_icon( $name ) {
    $paths = array(
        'bag'=>'<path d="M5 8h14l1 13H4L5 8Z"/><path d="M8 9V6a4 4 0 0 1 8 0v3"/>',
        'email'=>'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
        'whatsapp'=>'<path d="M20.5 11.5a8.5 8.5 0 0 1-12.2 7.6L3 21l1.8-5.3a8.5 8.5 0 1 1 15.7-4.2Z"/><path d="M8 7.5c0 4.5 4 8.5 8.5 8.5l1-2.5-3-1-1 1c-1.5-.7-2.8-2-3.5-3.5l1-1-1-3-2 .5Z"/>',
        'location'=>'<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2.5"/>',
        'linkedin'=>'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 10v7m0-10v.1M11 17v-7m0 3a3 3 0 0 1 6 0v4"/>',
        'instagram'=>'<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><path d="M17.5 6.5h.01"/>',
        'facebook'=>'<path d="M14 21V12h3l.5-4H14V6c0-1 .5-2 2-2h2V1h-3c-4 0-5 2.5-5 5v2H7v4h3v9"/>',
        'youtube'=>'<rect x="2" y="5" width="20" height="14" rx="4"/><path d="m10 9 5 3-5 3V9Z"/>',
        'pinterest'=>'<circle cx="12" cy="12" r="9"/><path d="m9 21 3-13m-1 7c5 4 8-7 2-8-4-1-6 5-3 7"/>',
        'tiktok'=>'<path d="M14 3v12a4 4 0 1 1-4-4m4-8c1 4 3 5 6 5"/>',
        'x'=>'<path d="m4 3 16 18h-5L3 3h5l13 18M20 3 4 21"/>',
    );
    return isset( $paths[$name] ) ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'.$paths[$name].'</svg>' : '';
}
function ian_whatsapp_label( $contact ) {
    $digits=preg_replace('/\D/','',(string)$contact['whatsapp']);
    return $digits===preg_replace('/\D/','',(string)($contact['phone']??''))?$contact['phone']:'+'.$digits;
}
function ian_header_cart() {
    if(!function_exists('wc_get_cart_url')){return '';}
    $count=function_exists('WC')&&WC()->cart?(float)WC()->cart->get_cart_contents_count():0;
    $display=$count>99?'99+':(string)$count;
    return '<a class="header-cart" data-open-cart href="'.esc_url(wc_get_cart_url()).'" aria-label="'.esc_attr($count?'Shopping cart, '.$count.' items':'Shopping cart, empty').'">'.ian_ui_icon('bag').'<span class="screen-reader-text">Cart</span><b id="cart-count"'.($count>0?'':' hidden').'>'.esc_html($display).'</b></a>';
}
add_filter('woocommerce_add_to_cart_fragments',function($fragments){$fragments['a.header-cart']=ian_header_cart();return $fragments;});
add_action('wp_enqueue_scripts',function(){if(function_exists('WC')){wp_enqueue_script('wc-cart-fragments');}},30);
