<?php
/** Optional YouTube presentation for native product descriptions and post bodies. */
defined( 'ABSPATH' ) || exit;

function ian_video_source( $url ) {
    $parts = wp_parse_url( html_entity_decode( trim( $url ), ENT_QUOTES, 'UTF-8' ) );
    if ( ! is_array( $parts ) || ! in_array( strtolower( $parts['scheme'] ?? '' ), array( 'https', 'http' ), true ) || isset( $parts['user'] ) || isset( $parts['pass'] ) || isset( $parts['port'] ) ) { return false; }
    $host = strtolower( $parts['host'] ?? '' );
    if ( ! in_array( $host, array( 'youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtube-nocookie.com', 'www.youtube-nocookie.com', 'youtu.be', 'www.youtu.be' ), true ) ) { return false; }
    $path = trim( $parts['path'] ?? '', '/' ); $query = array();
    parse_str( $parts['query'] ?? '', $query );
    $id = ''; $portrait = false;
    if ( in_array( $host, array( 'youtu.be', 'www.youtu.be' ), true ) ) { $id = $path; }
    elseif ( 'watch' === $path ) { $id = $query['v'] ?? ''; }
    elseif ( preg_match( '~^(embed|shorts|live)/([A-Za-z0-9_-]{11})$~D', $path, $m ) ) { $id = $m[2]; $portrait = 'shorts' === $m[1]; }
    if ( ! is_string( $id ) || ! preg_match( '/^[A-Za-z0-9_-]{11}$/D', $id ) ) { return false; }
    $start = 0; $time = $query['start'] ?? $query['t'] ?? '';
    if ( is_scalar( $time ) && preg_match( '/^\d{1,8}$/D', (string) $time ) ) { $start = (int) $time; }
    elseif ( is_string( $time ) && preg_match( '/^(?:(\d{1,5})h)?(?:(\d{1,5})m)?(?:(\d{1,5})s)?$/D', $time, $m ) ) { $start = (int) ( $m[1] ?? 0 ) * 3600 + (int) ( $m[2] ?? 0 ) * 60 + (int) ( $m[3] ?? 0 ); }
    $start = min( 604800, max( 0, $start ) );
    return array( 'id' => $id, 'start' => $start, 'portrait' => $portrait, 'url' => 'https://www.youtube.com/watch?v=' . $id . ( $start ? '&t=' . $start . 's' : '' ) );
}
function ian_video_frontend() {
    return ! is_admin() && ! wp_doing_ajax() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) && is_singular( array( 'post', 'product' ) );
}
function ian_video_markup( $source ) {
    $title = sprintf( 'YouTube video: %s', wp_strip_all_tags( get_the_title( get_queried_object_id() ) ) );
    $play_label = sprintf( 'Play video: %s', wp_strip_all_tags( get_the_title( get_queried_object_id() ) ) );
    $poster = get_the_post_thumbnail_url( get_queried_object_id(), 'large' );
    return '<div class="ian-video' . ( $source['portrait'] ? ' is-portrait' : '' ) . '" data-ian-youtube="' . esc_attr( $source['id'] ) . '" data-ian-start="' . absint( $source['start'] ) . '" data-ian-title="' . esc_attr( $title ) . '"><a class="ian-video-trigger" href="' . esc_url( $source['url'] ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr( $play_label ) . '"><img class="ian-video-cover"' . ( $poster ? ' data-ian-fallback="' . esc_url( $poster ) . '"' : '' ) . ' src="https://i.ytimg.com/vi/' . esc_attr( $source['id'] ) . '/hqdefault.jpg" width="480" height="360" loading="lazy" decoding="async" referrerpolicy="no-referrer" alt=""><span class="ian-video-overlay" aria-hidden="true"><span class="ian-video-play"><svg viewBox="0 0 24 24" width="24" height="24" focusable="false" aria-hidden="true"><path fill="currentColor" d="m9 5 11 7-11 7Z"/></svg></span><span>Play video</span></span></a></div><p class="ian-video-external"><a href="' . esc_url( $source['url'] ) . '" target="_blank" rel="noopener noreferrer">Watch on YouTube ↗</a></p>';
}
/** Native embed handler runs before oEmbed fetching/caching; saved content stays portable. */
function ian_video_embed( $matches, $attr, $url, $rawattr ) {
    if ( ! ian_video_frontend() || ! ( $source = ian_video_source( $url ) ) ) { return false; }
    wp_enqueue_script( 'ian-video', get_theme_file_uri( 'assets/js/video.js' ), array(), IANPROJECT_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
    return ian_video_markup( $source );
}
add_action( 'init', function () {
    wp_embed_register_handler( 'ian-youtube', '~^https?://(?:www\.|m\.)?(?:youtube\.com|youtube-nocookie\.com|youtu\.be)/[^\s<>]+$~i', 'ian_video_embed', 0 );
} );
// Neutralise the native iframe spacer only for blocks using this presentation.
add_filter( 'render_block_core/embed', function ( $html ) {
    if ( ! ian_video_frontend() || false === strpos( $html, 'data-ian-youtube=' ) ) { return $html; }
    $tags = new WP_HTML_Tag_Processor( $html );
    if ( $tags->next_tag( 'figure' ) ) { $tags->add_class( 'ian-video-embed' ); }
    return $tags->get_updated_html();
} );
