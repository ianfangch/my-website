<?php
/**
 * Plugin Name: IanProject 旧资料迁移工具
 * Description: 一次性扫描、备份并转换旧页面、文章、商品、规格和图片；前台不依赖此插件。
 * Version: 2.0.2
 * Requires at least: 6.7
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 */
defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/includes/migration.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/contact-update.php';
add_action( 'init', function () {
    if ( ! post_type_exists( 'ian_product' ) ) { register_post_type( 'ian_product', array( 'public' => false, 'show_ui' => false, 'show_in_rest' => false, 'rewrite' => false ) ); }
    if ( ! post_type_exists( 'ian_insight' ) ) { register_post_type( 'ian_insight', array( 'public' => false, 'show_ui' => false, 'show_in_rest' => false, 'rewrite' => false ) ); }
    if ( ! taxonomy_exists( 'ian_product_category' ) ) { register_taxonomy( 'ian_product_category', 'ian_product', array( 'public' => false, 'show_ui' => false, 'hierarchical' => true, 'rewrite' => false ) ); }
} );
