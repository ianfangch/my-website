<?php
defined( 'ABSPATH' ) || exit;

/** Explicit, one-time page-content update. Never rewrites rendered frontend HTML. */
function ianlm_contact_page_id() {
    $map=(array)get_option('ian3_pages',array());
    return absint(get_option('ianq_contact_page',0))?:absint($map['contact']??0);
}
function ianlm_contact_fingerprint( $post ) {
    return hash('sha256',wp_json_encode(array($post->ID,$post->post_title,$post->post_content,$post->post_status)));
}
function ianlm_contact_preview() {
    $id=ianlm_contact_page_id();$post=get_post($id);
    if(!$post||'page'!==$post->post_type||!current_user_can('edit_post',$id)){return new WP_Error('ianlm_contact_page','请先指定联系页面，并确认有编辑权限。');}
    $file=dirname(__DIR__).'/data/contact-page.html';$content=file_get_contents($file);
    // Keep any existing shortcode attributes; the enquiry plugin still owns the form.
    if(preg_match('/\[ian_quote_form(?:\s[^\]]*)?\]/',$post->post_content,$m)){$content=str_replace('[ian_quote_form]',$m[0],$content);}
    $plan=array('id'=>$id,'owner'=>get_current_user_id(),'title'=>$post->post_title,'before_hash'=>ianlm_contact_fingerprint($post),'template_hash'=>hash_file('sha256',$file),'content'=>$content,'already_current'=>$content===$post->post_content);
    update_option('ianlm_contact_plan_'.get_current_user_id(),$plan,false);
    return $plan;
}
function ianlm_contact_apply( $plan ) {
    if(!is_array($plan)||(int)$plan['owner']!==get_current_user_id()||!current_user_can('edit_post',$plan['id'])){return new WP_Error('ianlm_contact_permission','请重新预览联系页更新。');}
    $post=get_post($plan['id']);$file=dirname(__DIR__).'/data/contact-page.html';
    if(!$post||!hash_equals($plan['before_hash'],ianlm_contact_fingerprint($post))||!hash_equals($plan['template_hash'],hash_file('sha256',$file))){return new WP_Error('ianlm_contact_changed','联系页或模板在预览后发生变化，请重新预览。');}
    if($plan['content']===$post->post_content){return array('id'=>$post->ID,'message'=>'联系页已是新版，无需重复更新。');}
    $key='ianlm_contact_backup_'.$post->ID.'_'.wp_generate_uuid4();
    add_option($key,array('id'=>$post->ID,'content'=>$post->post_content,'owner'=>get_current_user_id(),'created_at'=>current_time('mysql',true),'applied_hash'=>hash('sha256',$plan['content'])),'',false);
    wp_save_post_revision($post->ID);
    $result=wp_update_post(wp_slash(array('ID'=>$post->ID,'post_content'=>$plan['content'])),true);
    if(is_wp_error($result)){return $result;}
    update_option('ianlm_contact_last_'.get_current_user_id(),array('id'=>$post->ID,'backup'=>$key),false);
    delete_option('ianlm_contact_plan_'.get_current_user_id());
    do_action('litespeed_purge_post',$post->ID);
    return array('id'=>$post->ID,'backup'=>$key,'message'=>'联系页源内容已更新。商品、价格和询价插件设置未改动。');
}
function ianlm_contact_restore( $key ) {
    $backup=get_option($key);$post=is_array($backup)?get_post($backup['id']):null;
    if(!$post||!current_user_can('edit_post',$post->ID)||(int)$backup['owner']!==get_current_user_id()){return new WP_Error('ianlm_contact_backup','没有可恢复的联系页备份或权限。');}
    if(!hash_equals($backup['applied_hash'],hash('sha256',$post->post_content))){return new WP_Error('ianlm_contact_edited','更新后联系页已有编辑，已停止自动恢复。');}
    $r=wp_update_post(wp_slash(array('ID'=>$post->ID,'post_content'=>$backup['content'])),true);
    if(!is_wp_error($r)){do_action('litespeed_purge_post',$post->ID);delete_option('ianlm_contact_last_'.get_current_user_id());}
    return $r;
}
add_action('admin_menu',function(){add_management_page('IanProject 联系页更新','IanProject 联系页更新','manage_options','ianproject-contact-update','ianlm_contact_admin');});
function ianlm_contact_admin() {
    if(!current_user_can('manage_options')){return;}
    $message='';$error=false;
    if(isset($_POST['ianlm_contact_preview'])){check_admin_referer('ianlm_contact_update');$r=ianlm_contact_preview();if(is_wp_error($r)){$message=$r->get_error_message();$error=true;}}
    if(isset($_POST['ianlm_contact_apply'])){check_admin_referer('ianlm_contact_update');$r=ianlm_contact_apply(get_option('ianlm_contact_plan_'.get_current_user_id()));$error=is_wp_error($r);$message=$error?$r->get_error_message():$r['message'];}
    if(isset($_POST['ianlm_contact_restore'])){check_admin_referer('ianlm_contact_update');$last=get_option('ianlm_contact_last_'.get_current_user_id(),array());$r=ianlm_contact_restore($last['backup']??'');$error=is_wp_error($r);$message=$error?$r->get_error_message():'已恢复更新前的联系页。';}
    echo '<div class="wrap" style="max-width:980px"><h1>IanProject 联系页更新</h1><p>本次只更新联系页正文：移除重复邮箱和装饰图片区，保留需求表单，Email / WhatsApp 按钮直接打开对应渠道。不扫描或重做商品迁移。</p>';
    if($message){echo '<div class="notice '.($error?'notice-error':'notice-success').'"><p>'.esc_html($message).'</p></div>';}
    echo '<form method="post">';wp_nonce_field('ianlm_contact_update');echo '<button class="button" name="ianlm_contact_preview">1. 预览联系页更新</button></form>';
    $plan=get_option('ianlm_contact_plan_'.get_current_user_id());
    if(is_array($plan)){
        echo '<h2>待更新：'.esc_html($plan['title']).' (#'.absint($plan['id']).')</h2><p>新版：直接联系区域＋需求表单。公司邮箱、WhatsApp 和表单发送规则继续使用现有统一设置。</p><p><a href="'.esc_url(get_permalink($plan['id'])).'" target="_blank" rel="noopener">查看当前联系页</a> · <a href="'.esc_url(get_edit_post_link($plan['id'],'raw')).'">编辑源内容</a></p><details><summary>查看将保存的原生区块内容</summary><textarea class="large-text code" rows="14" readonly>'.esc_textarea($plan['content']).'</textarea></details><form method="post" style="margin-top:20px">';wp_nonce_field('ianlm_contact_update');echo '<button class="button button-primary" name="ianlm_contact_apply">2. 备份并应用联系页更新</button></form>';
    }
    if(get_option('ianlm_contact_last_'.get_current_user_id())){echo '<h2>恢复</h2><p>如果更新后尚未另行编辑，可以恢复本次更新前的联系页内容。</p><form method="post">';wp_nonce_field('ianlm_contact_update');echo '<button class="button" name="ianlm_contact_restore">恢复更新前的联系页</button></form>';}
    echo '<p>完成后可停用此迁移工具，联系页不依赖本工具运行。</p></div>';
}
