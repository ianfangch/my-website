<?php
defined( 'ABSPATH' ) || exit;
add_action( 'admin_menu', function () { add_management_page( 'IanProject 旧资料迁移', 'IanProject 旧资料迁移', 'manage_options', 'ianproject-legacy-importer', 'ianlm_admin' ); } );
function ianlm_allowed() { if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => '没有迁移权限。' ), 403 ); } check_ajax_referer( 'ianlm', 'nonce' ); }
add_action( 'wp_ajax_ianlm_scan', function () { ianlm_allowed(); $job = IanProject_Legacy_Migration::scan(); $job['phase'] = 'review'; $job['hash'] = hash( 'sha256', wp_json_encode( $job ) ); update_option( 'ianlm_job', $job, false ); wp_send_json_success( $job ); } );
function ianlm_step() {
    $job = get_option( 'ianlm_job' );
    if ( ! is_array( $job ) || (int) $job['owner'] !== get_current_user_id() ) { return new WP_Error( 'ianlm_scan', '请先扫描并检查转换清单。' ); }
    $lock = array( 'time' => time(), 'token' => wp_generate_uuid4() );
    $old = get_option( 'ianlm_lock' ); if ( is_array( $old ) && $old['time'] < time() - 180 ) { delete_option( 'ianlm_lock' ); }
    if ( ! add_option( 'ianlm_lock', $lock, '', false ) ) { return new WP_Error( 'ianlm_busy', '另一批迁移正在运行，请稍后重试。' ); }
    try {
        $index = (int) $job['offset'];
        if ( isset( $job['items'][ $index ] ) ) {
            $item =& $job['items'][ $index ];
            $r = !hash_equals($item['before_hash'],IanProject_Legacy_Migration::fingerprint($item['id'])) ? new WP_Error('ianlm_changed','资料在扫描后发生变化，请重新扫描。') : IanProject_Legacy_Migration::convert( $item['id'] );
            $item['status'] = is_wp_error( $r ) ? 'error' : 'converted'; $item['message'] = is_wp_error( $r ) ? $r->get_error_message() : '已转换为新版数据';
            $backup = get_option( 'ianlm5_backup_' . $item['id'] ); $item['has_backup'] = $backup && empty( $backup['restored'] );
            $job['offset'] = $index + 1;
        }
        $job['phase'] = $job['offset'] >= count( $job['items'] ) ? 'complete' : 'running';
        update_option( 'ianlm_job', $job, false );
        return $job;
    } finally { $current = get_option( 'ianlm_lock' ); if ( is_array( $current ) && $current['token'] === $lock['token'] ) { delete_option( 'ianlm_lock' ); } }
}
add_action( 'wp_ajax_ianlm_step', function () { ianlm_allowed(); $job = get_option( 'ianlm_job' ); if ( ! $job || ! hash_equals( $job['hash'], sanitize_text_field( wp_unslash( $_POST['plan'] ?? '' ) ) ) ) { wp_send_json_error( array( 'message' => '扫描清单已变化，请重新扫描。' ), 409 ); } $r = ianlm_step(); if ( is_wp_error( $r ) ) { wp_send_json_error( array( 'message' => $r->get_error_message() ), 400 ); } wp_send_json_success( $r ); } );
add_action( 'wp_ajax_ianlm_restore', function () { ianlm_allowed(); $id = absint( $_POST['id'] ?? 0 ); if ( ! current_user_can( 'edit_post', $id ) ) { wp_send_json_error( array( 'message' => '没有编辑权限。' ), 403 ); } $r = IanProject_Legacy_Migration::restore( $id ); if ( is_wp_error( $r ) ) { wp_send_json_error( array( 'message' => $r->get_error_message() ), 400 ); } wp_send_json_success( array( 'id' => $id, 'message' => '已恢复。新增的媒体附件保留，不删除其他数据。' ) ); } );
function ianlm_stage_json( $data ) {
    if ( ! is_array( $data ) || ! isset( $data['products'] ) && ! isset( $data['posts'] ) && ! isset( $data['pages'] ) ) { return new WP_Error( 'ianlm_json', '请选择含 products、posts 或 pages 的旧站 JSON。' ); }
    $created = 0; $skipped = 0;
    foreach ( array( 'products', 'posts', 'pages' ) as $group ) {
        foreach ( (array) ( $data[ $group ] ?? array() ) as $row ) {
            if ( ! is_array( $row ) ) { continue; } $source = sanitize_text_field( $row['source'] ?? $row['url'] ?? $row['id'] ?? '' );
            if ( ! $source || ! is_scalar( $row['title'] ?? $row['name'] ?? '' ) ) { ++$skipped; continue; }
            $found = get_posts( array( 'post_type' => array( 'product', 'ian_product', 'post', 'ian_insight', 'page' ), 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'meta_key' => '_ian_source', 'meta_value' => $source, 'numberposts' => 1 ) );
            if ( $found ) { ++$skipped; continue; }
            $type = 'products' === $group ? 'ian_product' : ( 'pages' === $group ? 'page' : 'ian_insight' );
            $id = wp_insert_post( wp_slash( array( 'post_type' => $type, 'post_status' => 'draft', 'post_title' => sanitize_text_field( $row['title'] ?? $row['name'] ), 'post_name' => sanitize_title( $row['slug'] ?? $row['id'] ?? basename( $source ) ), 'post_content' => wp_kses_post( is_string( $row['content'] ?? '' ) ? $row['content'] : '' ), 'post_excerpt' => sanitize_text_field( $row['summary'] ?? $row['description'] ?? '' ), 'menu_order' => (int) ( $row['menu_order'] ?? 0 ) ) ), true );
            if ( is_wp_error( $id ) ) { return $id; }
            update_post_meta( $id, '_ian_source', $source );
            if ( is_string( $row['featuredImage'] ?? null ) ) { update_post_meta( $id, '_ianlm_featured_source', $row['featuredImage'] ); }
            foreach ( (array) ( $row['meta'] ?? array() ) as $key => $value ) { if ( in_array( $key, array( '_ian_insight_topic', '_ian_region', '_ian_location', '_ian_project_type', '_ian_scope', '_ian_materials' ), true ) && is_scalar( $value ) ) { update_post_meta( $id, $key, sanitize_text_field( $value ) ); } }
            if ( 'products' === $group ) { update_post_meta( $id, '_ian_product_data', wp_slash( $row ) ); }
            if ( 'posts' === $group && 'project' === ( $row['category'] ?? '' ) ) { wp_update_post( array( 'ID' => $id, 'post_type' => 'post' ) ); $term = get_term_by( 'slug', 'project', 'category' ); if ( ! $term ) { $r = wp_insert_term( 'Project', 'category', array( 'slug' => 'project' ) ); $term = ! is_wp_error( $r ) ? get_term( $r['term_id'], 'category' ) : null; } if ( $term ) { wp_set_post_categories( $id, array( $term->term_id ) ); } }
            ++$created;
        }
    }
    return array( 'created' => $created, 'skipped' => $skipped );
}
function ianlm_admin() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    if ( isset( $_POST['ianlm_json'] ) ) {
        check_admin_referer( 'ianlm_json' ); $file = $_FILES['legacy_json'] ?? array();
        $r = ! empty( $file['tmp_name'] ) && is_uploaded_file( $file['tmp_name'] ) && (int) $file['size'] <= 8 * MB_IN_BYTES ? ianlm_stage_json( json_decode( file_get_contents( $file['tmp_name'] ), true ) ) : new WP_Error( 'ianlm_upload', '请选择 8 MB 以内的旧站 JSON。' );
        echo '<div class="notice ' . ( is_wp_error( $r ) ? 'notice-error' : 'notice-success' ) . '"><p>' . esc_html( is_wp_error( $r ) ? $r->get_error_message() : '已建立 ' . $r['created'] . ' 条待转换草稿，跳过 ' . $r['skipped'] . ' 条已有资料。请扫描后转换。' ) . '</p></div>';
    }
    $job = get_option( 'ianlm_job' );
    ?><div class="wrap" style="max-width:1100px"><h1>IanProject 旧资料迁移工具</h1>
    <p>扫描站内旧资料，备份后转换为原生文章、WooCommerce 商品与可变规格，图片转入媒体库。完成后可停用、删除本插件；已转换内容、附件和备份不会删除。启用插件不会自动改写资料。</p>
    <p>建议先在测试副本执行。已安装新主题后，旧目录和修复插件可在迁移验收时停用；WooCommerce 保持启用。不要同时编辑正在迁移的同一条资料。</p>
    <p><button id="ianlm-scan" class="button">1. 扫描旧资料</button> <button id="ianlm-start" class="button button-primary" disabled>2. 按下方清单转换 / 继续</button> <button id="ianlm-report" class="button">下载报告</button></p><p role="status" id="ianlm-status"></p><progress id="ianlm-progress" max="100" value="0" style="width:100%"></progress><div id="ianlm-results"></div>
    <details style="margin-top:25px"><summary>从旧站 JSON 建立待转换草稿（可选）</summary><p>已有站内旧资料无需重复上传。JSON 中的图片需要在媒体库或保留的旧主题文件夹内；不会自动下载任意外链图片。</p><form method="post" enctype="multipart/form-data"><?php wp_nonce_field( 'ianlm_json' ); ?><input type="file" accept=".json,application/json" name="legacy_json" required><button class="button" name="ianlm_json">导入为待转换草稿</button></form></details>
    <p>报告中出现缺图、无法读取原图、扫描后资料被修改等情况时，会保留资料供人工核对，不把失败项目当作转换成功。回滚会检查迁移后是否又被编辑；有人工修改时停止自动回滚。</p></div>
    <script>(()=>{let job=<?php echo wp_json_encode( is_array( $job ) && (int) $job['owner'] === get_current_user_id() ? $job : null, JSON_HEX_TAG | JSON_HEX_AMP ); ?>;const nonce=<?php echo wp_json_encode( wp_create_nonce( 'ianlm' ) ); ?>,scan=document.getElementById('ianlm-scan'),start=document.getElementById('ianlm-start'),status=document.getElementById('ianlm-status'),results=document.getElementById('ianlm-results'),progress=document.getElementById('ianlm-progress');const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));async function api(action,args={}){const r=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:new URLSearchParams({action,nonce,...args})}),j=await r.json();if(!j.success)throw Error(j.data?.message||'操作失败');return j.data;}function render(){if(!job)return;start.disabled=job.offset>=job.items.length;progress.value=100*job.offset/Math.max(1,job.items.length);const failed=job.items.filter(i=>i.status==='error').length;status.textContent='已处理 '+job.offset+' / '+job.items.length+'，待核对 '+failed+'，无需转换 '+job.already_native+'。';results.innerHTML='<table class="widefat striped"><thead><tr><th>资料</th><th>类型</th><th>状态 / 提示</th><th>备份</th></tr></thead><tbody>'+job.items.map(i=>'<tr><td>'+esc(i.title)+' (#'+i.id+')</td><td>'+esc(i.kind)+'</td><td>'+esc(i.message||i.warnings.join('；')||'待转换')+'</td><td>'+(i.has_backup||i.status==='converted'?'<button class="button" data-restore="'+i.id+'">恢复此项</button>':'')+'</td></tr>').join('')+'</tbody></table>';results.querySelectorAll('[data-restore]').forEach(b=>b.onclick=async()=>{if(!confirm('恢复这一项的迁移前备份？转换后的人工修改会阻止自动恢复。'))return;try{const r=await api('ianlm_restore',{id:b.dataset.restore});status.textContent=r.message;}catch(e){status.textContent=e.message;}});}scan.onclick=async()=>{scan.disabled=true;try{job=await api('ianlm_scan');render();}catch(e){status.textContent=e.message;}finally{scan.disabled=false;}};start.onclick=async()=>{start.disabled=true;scan.disabled=true;try{while(job.offset<job.items.length){job=await api('ianlm_step',{plan:job.hash});render();start.disabled=true;}}catch(e){status.textContent='已暂停：'+e.message+'。可继续已扫描任务。';}finally{scan.disabled=false;render();}};document.getElementById('ianlm-report').onclick=()=>{if(!job)return;const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(job,null,2)],{type:'application/json'}));a.download='ianproject-migration-report.json';a.click();URL.revokeObjectURL(a.href);};render();})();</script>
    <?php
}
