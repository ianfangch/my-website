<?php
defined( 'ABSPATH' ) || exit;

final class IanProject_Legacy_Source {
    const VERSION = '4.0.0';
    private static $media = array();
    public static function scan() {
        $ids = get_posts( array( 'post_type' => array( 'page', 'post', 'product', 'ian_product', 'ian_insight' ), 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'numberposts' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'meta_query' => array( 'relation' => 'OR', array( 'key' => '_ian_source', 'compare' => 'EXISTS' ), array( 'key' => '_ian_product_data', 'compare' => 'EXISTS' ) ) ) );
        $ids = array_merge( $ids, get_posts( array( 'post_type' => array( 'ian_product', 'ian_insight' ), 'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ), 'numberposts' => -1, 'fields' => 'ids' ) ), array_values( (array) get_option( 'ian3_pages', array() ) ) );
        // Only saved overrides owned by this theme are offered, and only for
        // templates shipped in the new theme. Other themes remain untouched.
        if ( str_starts_with( wp_get_theme()->get( 'Name' ), 'IanProject' ) ) {
            $templates = get_posts( array( 'post_type' => array( 'wp_template', 'wp_template_part' ), 'post_status' => 'publish', 'numberposts' => -1, 'tax_query' => array( array( 'taxonomy' => 'wp_theme', 'field' => 'slug', 'terms' => get_template() ) ) ) );
            foreach ( $templates as $template ) {
                $folder = 'wp_template' === $template->post_type ? 'templates' : 'parts';
                if ( is_file( get_template_directory() . '/' . $folder . '/' . sanitize_file_name( $template->post_name ) . '.html' ) ) { $ids[] = $template->ID; }
            }
        }
        $items = array(); $done = 0;
        foreach ( array_unique( array_map( 'absint', $ids ) ) as $id ) {
            $p = get_post( $id ); if ( ! $p ) { continue; }
            if ( get_post_meta( $id, '_ian4_native', true ) ) { ++$done; continue; }
            $kind = in_array( $p->post_type, array( 'wp_template', 'wp_template_part' ), true ) ? 'template' : ( in_array( $p->post_type, array( 'product', 'ian_product' ), true ) ? 'product' : ( 'page' === $p->post_type ? 'page' : 'article' ) );
            $warnings = array();
            if ( 'template' === $kind ) { $warnings[] = '备份并停用旧的已保存模板，让新版主题模板生效；不会删除模板。'; }
            if ( 'product' === $kind ) {
                $data = get_post_meta( $id, '_ian_product_data', true );
                if ( ! is_array( $data ) || ! $data ) { $warnings[] = '没有可识别的旧产品字段，需人工核对。'; }
                $count = count( self::models( is_array( $data ) ? $data : array() ) );
                if ( $count ) { $warnings[] = '将生成 ' . $count . ' 个原生规格；缺少型号单价时保留系列参考价。'; }
            }
            $items[] = array( 'id' => $id, 'title' => $p->post_title, 'kind' => $kind, 'status' => 'pending', 'before_hash'=>self::fingerprint($id), 'warnings' => $warnings );
        }
        return array( 'items' => $items, 'already_native' => $done, 'created_at' => current_time( 'mysql', true ), 'owner' => get_current_user_id(), 'offset' => 0 );
    }
    private static function fields( $p ) { return array_intersect_key( get_object_vars( $p ), array_flip( array( 'ID', 'post_type', 'post_status', 'post_title', 'post_content', 'post_excerpt', 'post_name', 'post_parent', 'menu_order', 'post_date', 'post_date_gmt', 'comment_status', 'ping_status' ) ) ); }
    private static function backup( $id ) {
        $key = 'ianlm_backup_' . $id;
        $previous = get_option( $key );
        if ( $previous && empty( $previous['restored'] ) ) { return; }
        if ( $previous ) { add_option( $key . '_history_' . wp_generate_uuid4(), $previous, '', false ); delete_option( $key ); }
        $terms = array(); foreach ( get_object_taxonomies( get_post_type( $id ) ) as $tax ) { $t = wp_get_object_terms( $id, $tax, array( 'fields' => 'ids' ) ); if ( ! is_wp_error( $t ) ) { $terms[ $tax ] = $t; } }
        add_option( $key, array( 'post' => self::fields( get_post( $id ) ), 'meta' => get_post_meta( $id ), 'terms' => $terms, 'generated_variations' => array() ), '', false );
        wp_save_post_revision( $id );
    }
    private static function image_path( $source ) {
        $source = html_entity_decode( (string) $source, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $relative = str_replace( '{{IAN_ASSET}}/', '', $source );
        if ( str_starts_with( $relative, 'img/' ) ) {
            $themes = array_unique( array_filter( array_merge( array( get_option( 'ian_legacy_stylesheet_v2' ), get_stylesheet() ), array_keys( wp_get_themes() ) ) ) );
            foreach ( $themes as $slug ) { $theme = wp_get_theme( $slug ); if ( ! str_starts_with( $theme->get( 'Name' ), 'IanProject' ) ) { continue; } $base = realpath( $theme->get_stylesheet_directory() . '/assets' ); $file = $base ? realpath( $base . '/' . $relative ) : false; if ( $file && str_starts_with( $file, $base . DIRECTORY_SEPARATOR ) && is_file( $file ) ) { return $file; } }
            return new WP_Error( 'ianlm_media', '缺少原图：' . $relative . '。请保留或恢复旧主题原图文件。' );
        }
        $parts = wp_parse_url( $source ); if ( ! is_array( $parts ) || empty( $parts['path'] ) ) { return new WP_Error( 'ianlm_media', '无效图片地址。' ); }
        $home = wp_parse_url( home_url() );
        if ( ! empty( $parts['host'] ) && strtolower( $parts['host'] ) !== strtolower( $home['host'] ?? '' ) ) { return new WP_Error( 'ianlm_external', '外链图片未自动下载：' . $source ); }
        $path = rawurldecode( $parts['path'] );
        if ( preg_match( '~(?:^|/)\.\.(?:/|$)|[\\\\\x00]~', $path ) ) { return new WP_Error( 'ianlm_path', '图片路径不安全。' ); }
        // Renamed or symlinked theme folders may still contain the same approved asset.
        if ( preg_match( '~(?:^|/)themes/[^/]+/assets/(img/.+)$~', $path, $match ) ) {
            return self::image_path( $match[1] );
        }
        $roots = array( array( get_theme_root_uri(), get_theme_root() ), array( content_url( 'plugins' ), WP_PLUGIN_DIR ), array( wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'] ) );
        foreach ( $roots as list( $url, $root ) ) { $prefix = trailingslashit( (string) wp_parse_url( $url, PHP_URL_PATH ) ); if ( str_starts_with( $path, $prefix ) ) { $base = realpath( $root ); $file = realpath( $root . '/' . substr( $path, strlen( $prefix ) ) ); if ( $base && $file && str_starts_with( $file, $base . DIRECTORY_SEPARATOR ) && is_file( $file ) ) { return $file; } return new WP_Error( 'ianlm_media', '本地图片文件不存在：' . $path ); } }
        return new WP_Error( 'ianlm_media', '图片不在本站媒体或主题目录内：' . $path );
    }
    public static function attachment( $source ) {
        if ( is_numeric( $source ) ) { $id = absint( $source ); if(wp_attachment_is_image($id)&&is_file(get_attached_file($id))){self::native_sizes($id);return $id;}return new WP_Error( 'ianlm_image', '图片附件不存在：' . $id ); }
        if ( ! is_scalar( $source ) || ! $source ) { return 0; }
        if ( isset( self::$media[ $source ] ) ) { return self::$media[ $source ]; }
        $existing = attachment_url_to_postid( $source );
        if ( $existing && is_file( get_attached_file( $existing ) ) ) { self::tag_attachment($existing);self::native_sizes($existing); return self::$media[ $source ] = $existing; }
        $file = self::image_path( $source ); if ( is_wp_error( $file ) ) { return $file; }
        if ( ! preg_match( '~\.(?:jpe?g|png|webp|gif|avif)$~i', $file ) || ! ( $size = wp_getimagesize( $file ) ) ) { return new WP_Error( 'ianlm_image', '不是可导入的图片：' . basename( $file ) ); }
        $hash = hash_file( 'sha256', $file );
        foreach ( array( '_ian_media_hash_v2', '_ian4_media_hash' ) as $key ) { $found = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => $key, 'meta_value' => $hash, 'numberposts' => 1, 'fields' => 'ids' ) ); if ( $found && is_file( get_attached_file( $found[0] ) ) ) { self::tag_attachment($found[0]);self::native_sizes($found[0]); return self::$media[ $source ] = (int) $found[0]; } }
        $upload = wp_upload_bits( 'ian-' . substr( $hash, 0, 12 ) . '-' . sanitize_file_name( basename( $file ) ), null, file_get_contents( $file ) );
        if ( $upload['error'] ) { return new WP_Error( 'ianlm_upload', $upload['error'] ); }
        $mime = wp_check_filetype( $upload['file'] );
        $id = wp_insert_attachment( array( 'post_title' => pathinfo( $file, PATHINFO_FILENAME ), 'post_mime_type' => $mime['type'], 'post_status' => 'inherit' ), $upload['file'], 0, true );
        if ( is_wp_error( $id ) ) { return $id; }
        wp_update_attachment_metadata( $id, array( 'width' => $size[0], 'height' => $size[1], 'file' => _wp_relative_upload_path( $upload['file'] ), 'sizes' => array(), 'filesize' => filesize( $upload['file'] ) ) );
        update_post_meta( $id, '_ian4_media_hash', $hash );
        self::native_sizes($id);
        $index = self::asset_index(); if ( isset( $index[ $hash ]['bounds'] ) && $index[ $hash ]['bounds'] ) { update_post_meta( $id, '_ian4_subject_box', $index[ $hash ]['bounds'] ); }
        return self::$media[ $source ] = (int) $id;
    }
    private static function native_sizes($id){
        $meta=wp_get_attachment_metadata($id);$file=get_attached_file($id);
        if(!$file||!is_file($file)||!empty($meta['sizes'])||max((int)($meta['width']??0),(int)($meta['height']??0))<=300){return;}
        require_once ABSPATH.'wp-admin/includes/image.php';
        $generated=wp_generate_attachment_metadata($id,$file);
        if(!empty($generated)){wp_update_attachment_metadata($id,$generated);}
    }
    private static function tag_attachment($id){$file=get_attached_file($id);if(!$file||!is_file($file)||get_post_meta($id,'_ian4_subject_box',true))return;$index=self::asset_index();$hash=hash_file('sha256',$file);if(!empty($index[$hash]['bounds']))update_post_meta($id,'_ian4_subject_box',$index[$hash]['bounds']);}
    private static function asset_index() { static $index; if ( null === $index ) { $file = dirname( __DIR__ ) . '/data/assets-index.json'; $index = is_file( $file ) ? json_decode( file_get_contents( $file ), true ) : array(); } return is_array( $index ) ? $index : array(); }
    private static function rewrite( $html ) {
        $html = str_replace( '{{IAN_HOME}}', untrailingslashit( home_url() ), $html ); $errors = array();
        $html = preg_replace_callback( '~(?:\{\{IAN_ASSET\}\}/[^\s"\'<>\\\\()]+|https?://[^\s"\'<>\\\\()]+|/[^\s"\'<>\\\\()]*wp-content/[^\s"\'<>\\\\()]+)~i', function ( $m ) use ( &$errors ) {
            if ( ! preg_match( '~\.(?:jpe?g|png|webp|gif|avif)(?:[?#].*)?$~i', $m[0] ) ) { return $m[0]; }
            $id = self::attachment( $m[0] );
            if ( is_wp_error( $id ) ) { if ( 'ianlm_external' !== $id->get_error_code() ) { $errors[] = $id->get_error_message(); } return $m[0]; }
            return $id ? wp_get_attachment_url( $id ) : $m[0];
        }, $html );
        return $errors ? new WP_Error( 'ianlm_content_media', implode( '；', array_unique( $errors ) ) ) : $html;
    }
    private static function clean_blocks( $blocks, $article = false ) {
        $out = array();
        foreach ( $blocks as $b ) {
            $name = $b['blockName'] ?? null; $class = $b['attrs']['className'] ?? '';
            if ( $article && ( in_array( $name, array( 'core/post-title', 'core/post-featured-image' ), true ) || str_contains( $class, 'article-hero' ) ) ) { continue; }
            if ( 'core/image' === $name ) { $tags = new WP_HTML_Tag_Processor( $b['innerHTML'] ); if ( $tags->next_tag( 'IMG' ) ) { $id = attachment_url_to_postid( $tags->get_attribute( 'src' ) ); if ( $id ) { $b['attrs']['id'] = $id; $tags->add_class( 'wp-image-' . $id ); $b['innerHTML'] = $tags->get_updated_html(); foreach ( $b['innerContent'] as &$piece ) { if ( is_string( $piece ) && str_contains( $piece, '<img' ) ) { $piece = $b['innerHTML']; } } unset( $piece ); } } }
            if ( $b['innerBlocks'] ) { $rebuilt = array(); $new_children = array(); $index = 0; foreach ( $b['innerContent'] as $piece ) { if ( null !== $piece ) { $rebuilt[] = $piece; continue; } $old = $b['innerBlocks'][ $index++ ]; $clean = self::clean_blocks( array( $old ), $article ); if ( $clean ) { $rebuilt[] = null; $new_children[] = $clean[0]; } } $b['innerBlocks'] = $new_children; $b['innerContent'] = $rebuilt; }
            $out[] = $b;
        }
        return $out;
    }
    public static function content( $html, $article = false ) { $rewritten = self::rewrite( $html ); return is_wp_error( $rewritten ) ? $rewritten : serialize_blocks( self::clean_blocks( parse_blocks( $rewritten ), $article ) ); }
    public static function models( $data ) {
        $out = array();
        foreach ( (array) ( $data['catalogueRows'] ?? array() ) as $row ) { foreach ( (array) ( $row['models'] ?? array() ) as $m ) { if ( ! is_array( $m ) ) { continue; } $attrs = array(); foreach ( array( 'code' => 'Model', 'size' => 'Overall dimensions', 'cutout' => 'Cutout', 'material' => 'Material', 'note' => 'Features' ) as $key => $label ) { if ( ! empty( $m[ $key ] ) && is_scalar( $m[ $key ] ) ) { $attrs[ $label ] = (string) $m[ $key ]; } } $m['label'] = implode( ' · ', array_filter( array( $m['code'] ?? '', $m['size'] ?? '' ) ) ); $m['attrs'] = $attrs; $m['image'] = $row['image'] ?? ''; $out[] = $m; } }
        foreach ( (array) ( $data['optionRows'] ?? array() ) as $m ) {
            if ( ! is_array( $m ) ) { continue; } $attrs = array();
            foreach ( array( 'sku' => 'Configuration reference', 'cabinet' => 'Cabinet width', 'bins' => 'Bin configuration', 'productSize' => 'Product dimensions', 'clearWidth' => 'Internal clear width', 'clearDepth' => 'Minimum clear depth', 'clearHeight' => 'Minimum clear height', 'frame' => 'Frame & slides', 'lid' => 'Lids & tray', 'capacity' => 'Capacity' ) as $key => $label ) { if ( ! empty( $m[ $key ] ) && is_scalar( $m[ $key ] ) && 'Confirm with enquiry' !== $m[ $key ] ) { $attrs[ $label ] = (string) $m[ $key ]; } }
            $out[] = array( 'code' => $m['sku'] ?? '', 'label' => implode( ' · ', array_filter( array( $m['sku'] ?? '', $m['cabinet'] ?? '', $m['bins'] ?? '' ) ) ), 'attrs' => $attrs, 'image' => '', 'source' => $m );
        }
        return $out;
    }
    private static function attr( $name, $values, $variation = false ) { $a = new WC_Product_Attribute(); $a->set_name( $name ); $a->set_options( array_values( array_unique( array_map( 'sanitize_text_field', $values ) ) ) ); $a->set_visible( true ); $a->set_variation( $variation ); return $a; }
    private static function image_block( $id, $alt = '' ) { return '<!-- wp:image ' . wp_json_encode( array( 'id' => $id, 'sizeSlug' => 'full', 'linkDestination' => 'none' ) ) . ' --><figure class="wp-block-image size-full"><img src="' . esc_url( wp_get_attachment_url( $id ) ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-' . absint( $id ) . '"/></figure><!-- /wp:image -->'; }
    private static function description( $data, $images ) {
        $html = '';
        foreach ( (array) ( $data['highlights'] ?? array() ) as $point ) { if ( is_scalar( $point ) && $point ) { $html .= '<!-- wp:paragraph --><p>' . esc_html( $point ) . '</p><!-- /wp:paragraph -->'; } }
        foreach ( $images as $id ) { $html .= self::image_block( $id, $data['imageAlt'] ?? $data['name'] ?? '' ); }
        return $html;
    }
    private static function category_term($term){
        $found=get_term_by('slug',$term->slug,'product_cat');if($found)return (int)$found->term_id;
        $parent=0;if($term->parent){$old=get_term($term->parent,'ian_product_category');if($old&&!is_wp_error($old)){$parent=self::category_term($old);if(is_wp_error($parent))return $parent;}}
        $r=wp_insert_term($term->name,'product_cat',array('slug'=>$term->slug,'description'=>$term->description,'parent'=>$parent));if(is_wp_error($r))return $r;
        foreach(array('_ian_hide_catalog','thumbnail_id') as $key){$v=get_term_meta($term->term_id,$key,true);if(''!==$v)update_term_meta($r['term_id'],$key,$v);}
        return (int)$r['term_id'];
    }
    private static function migrate_categories( $id, $data ) {
        $ids = array();
        $terms = wp_get_object_terms( $id, 'ian_product_category' );
        if ( ! is_wp_error( $terms ) ) { foreach ( $terms as $t ) { $new=self::category_term($t);if(is_wp_error($new))return $new;$ids[]=$new; } }
        if ( ! $ids ) { $ids = wp_get_object_terms( $id, 'product_cat', array( 'fields' => 'ids' ) ); if ( is_wp_error( $ids ) ) { $ids = array(); } }
        if ( ! $ids && ! empty( $data['category'] ) ) { $slug = sanitize_title( $data['category'] ); $t = get_term_by( 'slug', $slug, 'product_cat' ); if ( ! $t ) { $r = wp_insert_term( ucwords( str_replace( '-', ' ', $slug ) ), 'product_cat', array( 'slug' => $slug ) ); if ( is_wp_error( $r ) ) { return $r; } $ids[] = $r['term_id']; } else { $ids[] = $t->term_id; } }
        return array_map( 'absint', $ids );
    }
    private static function product( $id ) {
        if ( ! class_exists( 'WC_Product_Variable' ) ) { return new WP_Error( 'ianlm_woo', '商品转换需要启用 WooCommerce。' ); }
        $data = get_post_meta( $id, '_ian_product_data', true );
        if ( ! is_array( $data ) || ! $data ) { return new WP_Error( 'ianlm_fields', '没有旧产品字段。请人工核对，未覆盖现有商品。' ); }
        $existing = 'product' === get_post_type( $id ) ? wc_get_product( $id ) : null;
        if ( $existing && ! $existing->is_type( 'simple' ) ) { return new WP_Error( 'ianlm_existing_variants', '已有可变商品或其他商品类型，未自动覆盖，请人工核对。' ); }
        $models = self::models( $data ); $images = array();
        foreach ( array_merge( array( $data['image'] ?? '' ), (array) ( $data['images'] ?? array() ) ) as $image ) { if ( is_array( $image ) ) { $image = $image['src'] ?? $image['url'] ?? ''; } if ( ! $image ) { continue; } $aid = self::attachment( $image ); if ( is_wp_error( $aid ) ) { return $aid; } if ( $aid ) { $images[] = $aid; } }
        $images = array_values( array_unique( $images ) );
        foreach ( $models as &$m ) { $m['attachment'] = 0; if ( ! empty( $m['image'] ) ) { $aid = self::attachment( $m['image'] ); if ( is_wp_error( $aid ) ) { return $aid; } $m['attachment'] = $aid; } } unset( $m );
        $cats = self::migrate_categories( $id, $data ); if ( is_wp_error( $cats ) ) { return $cats; }
        $content = get_post_field( 'post_content', $id );
        $full_legacy = has_block( 'core/post-title', $content ) && ( str_contains( $content, '[ian_product_price]' ) || str_contains( $content, 'product-detail-actions' ) );
        $details = $full_legacy || ! trim( $content ) ? self::description( $data, array_values( array_unique( array_filter( array_merge( array_column( $models, 'attachment' ), array_slice( $images, 1 ) ) ) ) ) ) : self::content( $content );
        if ( is_wp_error( $details ) ) { return $details; }
        $details = preg_replace( '/\[(?:ian_product_price|ian_product_meta|ian_wc_product|ian_product_details)[^\]]*\]/i', '', $details );
        $currency = strtoupper( sanitize_text_field( $data['currency'] ?? 'USD' ) ); $min = $data['price'] ?? ''; $max = $data['priceMax'] ?? ''; $unit = str_contains( $data['priceUnit'] ?? '', 'metre' ) ? 'metre' : ( str_contains( $data['priceUnit'] ?? '', 'set' ) ? 'set' : 'unit' );
        $source_price = $data['specifications']['Source reference price'] ?? '';
        if ( '' === $min && is_string( $source_price ) && preg_match( '~([A-Z]{3})\s+([\d,.]+)(?:[–-]([\d,.]+))?\s+per\s+(set|unit|metre)~u', $source_price, $match ) ) { $currency = $match[1]; $min = str_replace( ',', '', $match[2] ); $max = str_replace( ',', '', $match[3] ?? '' ); $unit = $match[4]; }
        if ( $models && $existing && '' !== $existing->get_regular_price( 'edit' ) && is_numeric( $data['price'] ?? '' ) && abs( (float) $existing->get_regular_price( 'edit' ) - (float) $data['price'] ) > 0.00001 ) { return new WP_Error( 'ianlm_price_edit', '现有价格已与旧资料不同，未覆盖人工调整的价格，请先核对。' ); }
        self::backup( $id );
        $result = wp_update_post( wp_slash( array( 'ID' => $id, 'post_type' => 'product', 'post_content' => $details, 'post_excerpt' => $existing && $existing->get_short_description() ? $existing->get_short_description() : ( $data['summary'] ?? '' ) ) ), true ); if ( is_wp_error( $result ) ) { return $result; }
        clean_post_cache( $id ); wp_set_object_terms( $id, $models ? 'variable' : 'simple', 'product_type' );
        $p = $models ? new WC_Product_Variable( $id ) : new WC_Product_Simple( $id );
        $attributes = $existing ? $existing->get_attributes() : array();
        $packaging = array();
        foreach ( (array) ( $data['specifications'] ?? array() ) as $name => $value ) {
            if ( is_string( $name ) && is_scalar( $value ) && '' !== (string) $value ) {
                if ( preg_match( '~^(?:packaging|packing method|units per carton|carton dimensions|gross weight|net weight)$~i', $name ) ) { $packaging[ $name ] = (string) $value; continue; }
                if ( ! preg_match( '~source reference price|minimum order|production lead time~i', $name ) ) { $ak=sanitize_title($name);if(!isset($attributes[$ak]))$attributes[$ak] = self::attr( $name, array( (string) $value ) ); }
            }
        }
        $labels = array(); foreach ( $models as $n => &$m ) { $label = $m['label'] ?: 'Configuration ' . ( $n + 1 ); if ( in_array( $label, $labels, true ) ) { $label .= ' · ' . ( $n + 1 ); } $m['label'] = $label; $labels[] = $label; } unset( $m );
        if ( $models ) { $attributes[] = self::attr( 'Configuration', $labels, true ); }
        $p->set_attributes( $attributes ); $p->set_category_ids( $cats );
        if ( ( ! $p->get_image_id() || !is_file(get_attached_file($p->get_image_id())) ) && $images ) { $p->set_image_id( $images[0] ); }
        $p->set_gallery_image_ids( array_values( array_unique( array_diff( array_merge( $p->get_gallery_image_ids(), $images ), array( $p->get_image_id() ) ) ) ) );
        if ( ! $p->get_sku() && ! empty( $data['code'] ) ) { $sku = sanitize_text_field( $data['code'] ); if ( strlen( $sku ) > 100 ) { $sku = 'IAN-' . $id; } $collision = wc_get_product_id_by_sku( $sku ); $p->set_sku( $collision && $collision !== $id ? $sku . '-' . $id : $sku ); }
        $quote = $models || ! empty( $data['quoteOnly'] ) || ! is_numeric( $min ) || ( is_numeric( $max ) && (float) $max > (float) $min ) || $currency !== get_woocommerce_currency();
        if ( $quote ) { $p->set_price( '' ); $p->set_regular_price( '' ); $p->set_sale_price( '' ); }
        elseif ( '' === $p->get_regular_price( 'edit' ) ) { $p->set_regular_price( wc_format_decimal( $min ) ); }
        $p->update_meta_data( '_ian4_quote_only', $quote ? 1 : 0 );
        if ( $packaging ) { $p->update_meta_data( '_ian4_packaging', $packaging ); }
        foreach ( array( 'reference_currency' => $currency, 'reference_min' => is_numeric( $min ) ? wc_format_decimal( $min ) : '', 'reference_max' => is_numeric( $max ) ? wc_format_decimal( $max ) : '', 'price_prefix' => $data['pricePrefix'] ?? '', 'unit' => $unit, 'moq' => $data['moq'] ?? '', 'lead_time' => $data['leadTime'] ?? '', 'customisation' => implode( "\n", array_filter( (array) ( $data['customisationOptions'] ?? array() ), 'is_scalar' ) ), 'image_fit' => in_array($data['category']??'',array('cabinetry','cabinetry-joinery'),true)?'cover':'contain', 'image_scope' => ! empty( $data['optionRows'] ) ? 'series' : ( $models ? 'model' : 'product' ) ) as $key => $value ) { $p->update_meta_data( '_ian4_' . $key, $value ); }
        $p->save(); $generated = array();
        $backup = get_option( 'ianlm_backup_' . $id );
        foreach ( $models as $n => $m ) {
            $v = new WC_Product_Variation(); $v->set_parent_id( $id ); $v->set_status( 'publish' ); $v->set_attributes( array( 'configuration' => $m['label'] ) ); $v->set_sku( 'IAN-' . $id . '-V' . ( $n + 1 ) );
            if ( $m['attachment'] ) { $v->set_image_id( $m['attachment'] ); }
            $v->update_meta_data( '_ian4_model', sanitize_text_field( $m['code'] ?? '' ) ); $v->update_meta_data( '_ian4_attributes', $m['attrs'] ); $v->update_meta_data( '_ian4_quote_only', 1 ); $v->update_meta_data( '_ian4_generated', 1 );
            $vid = $v->save(); $generated[] = $vid; $backup['generated_variations'] = $generated; update_option( 'ianlm_backup_' . $id, $backup, false );
        }
        if ( $models ) { WC_Product_Variable::sync( $id ); }
        delete_post_meta( $id, '_ian_product_data' );
        foreach ( $cats as $cat ) { if ( ! get_term_meta( $cat, 'thumbnail_id', true ) && $p->get_image_id() ) { update_term_meta( $cat, 'thumbnail_id', $p->get_image_id() ); } }
        wc_delete_product_transients( $id );
        return true;
    }
    public static function convert( $id ) {
        $id = absint( $id ); $p = get_post( $id ); if ( ! $p ) { return new WP_Error( 'ianlm_post', '资料不存在。' ); }
        if ( get_post_meta( $id, '_ian4_native', true ) ) { return true; }
        $kind = in_array( $p->post_type, array( 'wp_template', 'wp_template_part' ), true ) ? 'template' : ( in_array( $p->post_type, array( 'ian_product', 'product' ), true ) ? 'product' : ( 'page' === $p->post_type ? 'page' : 'article' ) );
        $before_hash = self::fingerprint( $id );
        $old_path = wp_parse_url( get_permalink( $id ), PHP_URL_PATH );
        try {
            if ( 'template' === $kind ) {
                if ( ! has_term( get_template(), 'wp_theme', $id ) || ! str_starts_with( wp_get_theme()->get( 'Name' ), 'IanProject' ) ) { return new WP_Error( 'ianlm_template', '模板不属于当前 IanProject 主题，未修改。' ); }
                self::backup( $id ); $result = wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ), true );
            }
            elseif ( 'product' === $kind ) { $result = self::product( $id ); }
            else {
                $content = $p->post_content;
                if ( 'page' === $kind ) { $map = (array) get_option( 'ian3_pages', array() ); $role = array_search( $id, array_map( 'absint', $map ), true ); if ( $role ) { $records = json_decode( file_get_contents( dirname( __DIR__ ) . '/data/pages.json' ), true ); foreach ( $records['pages'] ?? array() as $record ) { if ( $record['role'] === $role ) { $content = $record['content']; break; } } } }
                $content = self::content( $content, 'article' === $kind );
                if ( is_wp_error( $content ) ) { return $content; }
                $featured = get_post_meta( $id, '_ianlm_featured_source', true ); $thumbnail = 0;
                if ( $featured ) { $thumbnail = self::attachment( $featured ); if ( is_wp_error( $thumbnail ) ) { return $thumbnail; } }
                elseif ( get_post_thumbnail_id( $id ) ) { $thumbnail = self::attachment( get_post_thumbnail_id( $id ) ); if ( is_wp_error( $thumbnail ) ) { return $thumbnail; } }
                self::backup( $id );
                $new_type = 'ian_insight' === $p->post_type ? 'post' : $p->post_type;
                $result = wp_update_post( wp_slash( array( 'ID' => $id, 'post_type' => $new_type, 'post_content' => $content ) ), true );
                if ( ! is_wp_error( $result ) && $thumbnail ) { set_post_thumbnail( $id, $thumbnail ); delete_post_meta( $id, '_ianlm_featured_source' ); }
                if ( ! is_wp_error( $result ) && 'ian_insight' === $p->post_type ) { $term = get_term_by( 'slug', 'insights', 'category' ); if ( ! $term ) { $r = wp_insert_term( 'Insights', 'category', array( 'slug' => 'insights' ) ); if ( ! is_wp_error( $r ) ) { $term = get_term( $r['term_id'], 'category' ); } } if ( $term ) { wp_set_post_categories( $id, array( $term->term_id ), true ); } }
                if ( ! is_wp_error( $result ) && 'page' === $kind ) { delete_post_meta( $id, '_elementor_edit_mode' ); update_post_meta( $id, '_wp_page_template', 'default' ); }
            }
        } catch ( Throwable $e ) { $result = new WP_Error( 'ianlm_exception', $e->getMessage() ); }
        if ( is_wp_error( $result ) ) {
            // A late WooCommerce exception must not leave a half-converted
            // product. Restore this item's backup in the same request.
            $backup = get_option( 'ianlm_backup_' . $id );
            if ( $backup && empty( $backup['restored'] ) && ! hash_equals( $before_hash, self::fingerprint( $id ) ) ) {
                $restore = self::restore( $id );
                if ( is_wp_error( $restore ) ) { return new WP_Error( 'ianlm_restore_required', $result->get_error_message() . '；自动恢复未完成：' . $restore->get_error_message() ); }
                return new WP_Error( 'ianlm_restored', $result->get_error_message() . '；本项已恢复到转换前。' );
            }
            return $result;
        }
        update_post_meta( $id, '_ian4_native', self::VERSION ); update_post_meta( $id, '_ian4_migration_hash', self::fingerprint( $id ) );
        if ( $old_path && '/' !== trim($old_path) && $old_path !== wp_parse_url( get_permalink( $id ), PHP_URL_PATH ) ) { $routes = (array) get_option( 'ian4_redirects', array() ); $routes[ '/' . trim( $old_path, '/' ) ] = $id; update_option( 'ian4_redirects', $routes, false ); }
        $source_path = trim((string)get_post_meta($id,'_ian_source',true),'/');
        if(preg_match('~^(?:products|insights|project-cases)/[a-zA-Z0-9_-]+(?:\.html)?$~',$source_path)){
            $routes=(array)get_option('ian4_redirects',array());$base=rtrim((string)wp_parse_url(home_url(),PHP_URL_PATH),'/');$clean=preg_replace('/\.html$/','',$source_path);$routes[$base.'/'.$clean]=$id;$routes[$base.'/'.$clean.'.html']=$id;update_option('ian4_redirects',$routes,false);
        }
        return true;
    }
    public static function fingerprint( $id ) {
        $p = get_post( $id ); if ( ! $p ) { return ''; } $meta = array();
        foreach ( get_post_meta( $id ) as $key => $values ) { if ( str_starts_with( $key, '_ian4_' ) && ! in_array( $key, array( '_ian4_native', '_ian4_migration_hash' ), true ) || in_array( $key, array( '_sku', '_regular_price', '_sale_price', '_product_attributes', '_thumbnail_id', '_product_image_gallery', '_ian_product_data' ), true ) ) { $meta[ $key ] = $values; } }
        ksort( $meta ); $children = array();
        foreach ( get_posts( array( 'post_type' => 'product_variation', 'post_parent' => $id, 'post_status' => 'any', 'numberposts' => -1, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $child ) { $children[ $child->ID ] = self::fingerprint( $child->ID ); }
        $terms = array(); foreach ( get_object_taxonomies( $p->post_type ) as $taxonomy ) { $ids = wp_get_object_terms( $id, $taxonomy, array( 'fields' => 'ids' ) ); if ( ! is_wp_error( $ids ) ) { sort( $ids ); $terms[ $taxonomy ] = $ids; } } ksort( $terms );
        return hash( 'sha256', wp_json_encode( array( self::fields( $p ), $meta, $children, $terms ) ) );
    }
    public static function restore( $id ) {
        $backup = get_option( 'ianlm_backup_' . absint( $id ) );
        if ( ! is_array( $backup ) || empty( $backup['post'] ) ) { return new WP_Error( 'ianlm_backup', '未找到备份。' ); }
        $expected = get_post_meta( $id, '_ian4_migration_hash', true );
        if ( $expected && ! hash_equals( $expected, self::fingerprint( $id ) ) ) { return new WP_Error( 'ianlm_changed', '转换后资料已有人工修改，未自动回滚。请人工比较备份。' ); }
        foreach ( $backup['generated_variations'] as $vid ) { $v = function_exists( 'wc_get_product' ) ? wc_get_product( $vid ) : null; if ( $v ) { $v->delete( true ); } else { wp_delete_post( $vid, true ); } }
        $r = wp_update_post( wp_slash( $backup['post'] ), true ); if ( is_wp_error( $r ) ) { return $r; }
        foreach ( array_keys( get_post_meta( $id ) ) as $key ) { delete_post_meta( $id, $key ); }
        foreach ( $backup['meta'] as $key => $values ) { foreach ( $values as $value ) { add_post_meta( $id, $key, wp_slash( maybe_unserialize( $value ) ) ); } }
        foreach ( array_unique( array_merge( array( 'product_cat', 'product_type', 'ian_product_category', 'category' ), array_keys( $backup['terms'] ) ) ) as $tax ) { if ( taxonomy_exists( $tax ) ) { wp_set_object_terms( $id, array_map( 'absint', $backup['terms'][ $tax ] ?? array() ), $tax ); } }
        $routes=(array)get_option('ian4_redirects',array());foreach($routes as $path=>$target){if((int)$target===(int)$id)unset($routes[$path]);}update_option('ian4_redirects',$routes,false);
        clean_post_cache( $id ); if ( function_exists( 'wc_delete_product_transients' ) ) { wc_delete_product_transients( $id ); }
        $backup['restored'] = true; update_option( 'ianlm_backup_' . absint( $id ), $backup, false );
        return true;
    }
}
