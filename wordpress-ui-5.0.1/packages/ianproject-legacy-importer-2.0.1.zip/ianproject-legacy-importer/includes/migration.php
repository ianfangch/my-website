<?php
defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/source-v4.php';

/** One-time conversion to Woo fields and editable core blocks. Frontend never loads this. */
final class IanProject_Legacy_Migration {
    const VERSION = '5.0.0';
    private static function records() {
        return get_posts( array( 'post_type'=>array( 'page','post','product','ian_product','ian_insight','wp_template','wp_template_part' ), 'post_status'=>array( 'publish','draft','private','pending','future' ), 'numberposts'=>-1, 'fields'=>'ids', 'orderby'=>'ID', 'order'=>'ASC' ) );
    }
    public static function fingerprint( $id ) {
        $post = get_post( $id ); if ( ! $post ) { return ''; }
        $meta = get_post_meta( $id );
        foreach ( array( '_edit_lock','_edit_last','_ian5_native','_ian5_migration_hash' ) as $key ) { unset( $meta[ $key ] ); }
        ksort( $meta );
        $children = array();
        foreach ( get_posts( array( 'post_type'=>'product_variation','post_parent'=>$id,'post_status'=>'any','numberposts'=>-1,'orderby'=>'ID','order'=>'ASC' ) ) as $child ) { $children[ $child->ID ] = self::fingerprint( $child->ID ); }
        $terms = array();
        foreach ( get_object_taxonomies( $post->post_type ) as $tax ) { $ids=wp_get_object_terms( $id,$tax,array('fields'=>'ids') ); if(!is_wp_error($ids)){sort($ids);$terms[$tax]=$ids;} } ksort($terms);
        return hash( 'sha256', wp_json_encode( array( $post->post_type,$post->post_status,$post->post_title,$post->post_name,$post->post_content,$post->post_excerpt,$meta,$children,$terms ) ) );
    }
    private static function owned_template( $post ) {
        $terms = wp_get_object_terms( $post->ID, 'wp_theme', array( 'fields'=>'slugs' ) );
        if ( is_wp_error( $terms ) ) { return false; }
        foreach ( $terms as $slug ) { if ( str_starts_with( wp_get_theme( $slug )->get( 'Name' ), 'IanProject' ) ) { return true; } }
        return false;
    }
    private static function legacy_product( $id ) {
        foreach ( array_keys( get_post_meta( $id ) ) as $key ) { if ( str_starts_with( $key, '_ian4_' ) && ! in_array( $key, array( '_ian4_native','_ian4_migration_hash' ), true ) || '_ian_product_data' === $key ) { return true; } }
        foreach ( get_posts( array( 'post_type'=>'product_variation','post_parent'=>$id,'post_status'=>'any','numberposts'=>-1,'fields'=>'ids' ) ) as $vid ) { if ( self::legacy_product( $vid ) ) { return true; } }
        return false;
    }
    public static function scan() {
        $items=array();$done=0;
        foreach ( self::records() as $id ) {
            $post=get_post($id);$kind=in_array($post->post_type,array('wp_template','wp_template_part'),true)?'template':(in_array($post->post_type,array('product','ian_product'),true)?'product':('page'===$post->post_type?'page':'article'));
            if('template'===$kind&&!self::owned_template($post)){continue;}
            $owned=get_post_meta($id,'_ian_source',true)||get_post_meta($id,'_ian4_native',true)||in_array($id,array_map('absint',(array)get_option('ian3_pages',array())),true);
            $needs='product'===$kind?('ian_product'===$post->post_type||self::legacy_product($id)):('ian_insight'===$post->post_type||$owned&&get_post_meta($id,'_ian5_native',true)!==self::VERSION);
            if('template'===$kind){$needs=self::clean_content($post->post_content,$id)!==$post->post_content;}
            if(!$needs&&$owned){$needs=self::clean_content($post->post_content,$id)!==$post->post_content;}
            if(!$needs){++$done;continue;}
            $warnings=array('先备份再转换；没有明确原生单价的商品或规格保持空白，不分摊系列区间价。');
            $items[]=array('id'=>$id,'title'=>$post->post_title,'kind'=>$kind,'status'=>'pending','before_hash'=>self::fingerprint($id),'warnings'=>$warnings);
        }
        return array('items'=>$items,'already_native'=>$done,'created_at'=>current_time('mysql',true),'owner'=>get_current_user_id(),'offset'=>0);
    }
    private static function snapshot( $id ) {
        $post=get_post($id);$terms=array();
        foreach(get_object_taxonomies($post->post_type) as $tax){$v=wp_get_object_terms($id,$tax,array('fields'=>'ids'));if(!is_wp_error($v)){$terms[$tax]=$v;}}
        $children=array();foreach(get_posts(array('post_type'=>'product_variation','post_parent'=>$id,'post_status'=>'any','numberposts'=>-1)) as $child){$children[$child->ID]=self::snapshot($child->ID);}
        return array('post'=>get_object_vars($post),'meta'=>get_post_meta($id),'terms'=>$terms,'children'=>$children);
    }
    private static function save_backup( $id ) {
        $key='ianlm5_backup_'.$id;$old=get_option($key);
        $expected=get_post_meta($id,'_ian5_migration_hash',true);
        if($old&&empty($old['restored'])&&(!$expected||hash_equals($expected,self::fingerprint($id)))){return;}
        if($old){add_option($key.'_history_'.wp_generate_uuid4(),$old,'',false);}
        update_option($key,array('snapshot'=>self::snapshot($id),'before_hash'=>self::fingerprint($id),'time'=>current_time('mysql',true),'restored'=>false),false);
        wp_save_post_revision($id);
    }
    public static function group( $name, $content ) {
        return '<!-- wp:group '.wp_json_encode(array('className'=>'ian-'.$name,'layout'=>array('type'=>'default'))).' --><div class="wp-block-group ian-'.esc_attr($name).'">'.$content.'</div><!-- /wp:group -->';
    }
    public static function pairs( $pairs ) {
        $html='';foreach((array)$pairs as $name=>$value){if(is_scalar($value)&&''!==(string)$value){$html.='<tr><td>'.esc_html($name).'</td><td>'.esc_html($value).'</td></tr>';}}
        return $html?'<!-- wp:table --><figure class="wp-block-table"><table class="has-fixed-layout"><tbody>'.$html.'</tbody></table></figure><!-- /wp:table -->':'';
    }
    private static function paragraph( $value ) { return '<!-- wp:paragraph --><p>'.esc_html($value).'</p><!-- /wp:paragraph -->'; }
    private static function image( $id ) {
        if(!wp_attachment_is_image($id)){return '';}
        return '<!-- wp:image '.wp_json_encode(array('id'=>(int)$id,'sizeSlug'=>'full','linkDestination'=>'none')).' --><figure class="wp-block-image size-full"><img src="'.esc_url(wp_get_attachment_url($id)).'" alt="'.esc_attr(get_post_meta($id,'_wp_attachment_image_alt',true)).'" class="wp-image-'.absint($id).'"/></figure><!-- /wp:image -->';
    }
    public static function attachment( $source ) { return IanProject_Legacy_Source::attachment($source); }
    public static function models( $data ) { return IanProject_Legacy_Source::models($data); }
    private static function contact_url() {
        $map=(array)get_option('ian3_pages',array());$id=absint($map['contact']??0);return $id?get_permalink($id):home_url('/contact/');
    }
    private static function buttons( $html ) {
        $html=preg_replace_callback('~<a\b([^>]*)>(.*?)</a>~is',function($m){
            $label=trim(html_entity_decode(wp_strip_all_tags($m[2]),ENT_QUOTES,'UTF-8'));
            $button=preg_match('~class=["\'][^"\']*(?:\bbtn\b|\bbutton\b|ip-inline-link|wp-block-button__link)[^"\']*["\']~i',$m[1]);
            $catalogue=preg_match('~^(?:view|request|browse|download|get|ask for)\b.*\bcatalog(?:ue)?s?\b~i',$label);
            $contact=$button&&(preg_match('~href=["\'](?:mailto:|https?://(?:wa\.me|api\.whatsapp\.com)/)~i',$m[1])||preg_match('~^(?:contact(?: us)?|request (?:a )?quote|request (?:a )?quotation|send (?:an )?inquiry|discuss (?:your )?project|email(?: us)?|start (?:your )?project|check installation)$~i',$label));
            if(!$catalogue&&!$contact){return $m[0];}
            $tags=new WP_HTML_Tag_Processor($m[0]);$tags->next_tag('A');$href=(string)$tags->get_attribute('href');
            $target=self::contact_url();
            if(untrailingslashit((string)wp_parse_url($href,PHP_URL_PATH))===untrailingslashit((string)wp_parse_url($target,PHP_URL_PATH))){$parts=wp_parse_url($href);if(isset($parts['query'])){$target.='?'.$parts['query'];}if(isset($parts['fragment'])){$target.='#'.$parts['fragment'];}}
            $tags->set_attribute('href',$target);
            return preg_replace('~(<a\b[^>]*>).*?(</a>)~is','$1Contact$2',$tags->get_updated_html(),1);
        },$html);
        // Only identical Contact links within the same paragraph are duplicates.
        return preg_replace_callback('~<p\b([^>]*)>(.*?)</p>~is',function($p){$seen=array();$inside=preg_replace_callback('~<a\b([^>]*)>Contact</a>~i',function($a)use(&$seen){$t=new WP_HTML_Tag_Processor($a[0]);$t->next_tag('A');$url=html_entity_decode((string)$t->get_attribute('href'),ENT_QUOTES,'UTF-8');if(isset($seen[$url])){return '';}$seen[$url]=true;return $a[0];},$p[2]);return '<p'.$p[1].'>'.$inside.'</p>';},$html);
    }
    private static function block_cleanup( $blocks, $home, $suppress_buttons = false ) {
        $out=array();$seen=array();
        foreach($blocks as $b){
            $class=$b['attrs']['className']??'';
            $local_suppress=$suppress_buttons||(!$home&&str_contains($class,'ia-capability-footer'));
            if($local_suppress&&'core/button'===$b['blockName']){continue;}
            if(str_contains($class,'ia-owner-section')||str_contains($class,'ia-draft-slot')){continue;}
            if(!$home&&str_contains($class,'ia-capability-footer')){
                foreach($b['innerContent'] as &$piece){if(is_string($piece)){$piece=preg_replace('~<a\b[^>]*class=["\'][^"\']*(?:btn|button)[^"\']*["\'][^>]*>.*?</a>~is','',$piece);}}unset($piece);
            }
            if($b['innerBlocks']){
                $rebuilt=array();$children=array();$index=0;
                foreach($b['innerContent'] as $piece){if(null!==$piece){$rebuilt[]=$piece;continue;}$clean=self::block_cleanup(array($b['innerBlocks'][$index++]),$home,$local_suppress);foreach($clean as $child){$rebuilt[]=null;$children[]=$child;}}
                if('core/buttons'===$b['blockName']&&!$home){$unique=array();$new=array();foreach($children as $child){$markup=serialize_block($child);if(preg_match('~<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>Contact</a>~i',$markup,$m)){$url=html_entity_decode($m[1],ENT_QUOTES,'UTF-8');if(isset($unique[$url])){continue;}$unique[$url]=true;}$new[]=$child;}$children=$new;$rebuilt=array($b['innerContent'][0]??'');foreach($children as $_){$rebuilt[]=null;}$rebuilt[]=$b['innerContent'][count($b['innerContent'])-1]??'';}
                $b['innerBlocks']=$children;$b['innerContent']=$rebuilt;
            }
            if(!$home){foreach($b['innerContent'] as &$piece){if(is_string($piece)){$piece=self::buttons($piece);}}unset($piece);$b['innerHTML']=self::buttons($b['innerHTML']);}
            $out[]=$b;
        }
        return $out;
    }
    public static function clean_content( $content, $id ) {
        $content=preg_replace('~https?://[a-z0-9-]+\.hostingersite\.com(?=/)~i',untrailingslashit(home_url()),$content);
        // Company contact values remain editable through the one shared setting.
        $content=preg_replace_callback('~<a\b([^>]*)>(.*?)</a>~is',function($m){
            $t=new WP_HTML_Tag_Processor($m[0]);$t->next_tag('A');$href=html_entity_decode((string)$t->get_attribute('href'),ENT_QUOTES,'UTF-8');$field='';
            if(preg_match('~^mailto:(?:sales|info)@ianproject\.com$~i',$href)){$field='email';}
            elseif(preg_match('~^tel:[+ ()0-9.-]+$~',$href)&&preg_replace('/\D/','',$href)==='8619956229033'){$field='phone';}
            elseif(preg_match('~^https?://wa\.me/(?:8619956229033|message/A4AOHGMZ6DB6A1)/?$~i',$href)){$field='whatsapp';}
            if(!$field||preg_match('~class=["\'][^"\']*(?:button|btn)[^"\']*["\']~i',$m[1])){return $m[0];}
            $label=trim(html_entity_decode(wp_strip_all_tags($m[2]),ENT_QUOTES,'UTF-8'));
            $dynamic=preg_match('/^(?:(?:sales|info)@ianproject\.com|[+ ()0-9.-]+)$/i',$label);
            return '[ian_contact field="'.$field.'"'.($dynamic?'':' label="'.esc_attr(str_replace('"','',$label)).'"').']';
        },$content);

        $map=(array)get_option('ian3_pages',array());$home=(int)$id===(int)($map['home']??get_option('page_on_front'));
        // Contact-page channel buttons must keep their mailto / WhatsApp destinations.
        $contact=absint(get_option('ianq_contact_page',0))?:absint($map['contact']??0);$home=$home||(int)$id===$contact;
        return serialize_blocks(self::block_cleanup(parse_blocks($content),$home));
    }
    private static function set_attribute( $product, $name, $value ) {
        if(''===trim((string)$value)){return;}$attrs=$product->get_attributes();$key=sanitize_title($name);
        foreach($attrs as $existing){if(is_object($existing)&&strcasecmp($existing->get_name(),$name)===0){return;}}
        $a=new WC_Product_Attribute();$a->set_name($name);$a->set_options(array(sanitize_text_field($value)));$a->set_visible(true);$a->set_variation(false);$attrs[$key]=$a;$product->set_attributes($attrs);
    }
    private static function normalize_product( $id ) {
        $p=wc_get_product($id);if(!$p){return new WP_Error('ianlm_product','无法读取商品。');}
        foreach(array_filter(array_merge(array($p->get_image_id()),$p->get_gallery_image_ids())) as $aid){$media=self::attachment($aid);if(is_wp_error($media)){return $media;}}
        $content=$p->get_description();
        $old=array();foreach(get_post_meta($id) as $key=>$values){if(str_starts_with($key,'_ian4_')){$old[substr($key,6)]=maybe_unserialize($values[0]);}}
        // The v4 importer treated "square metre" as "metre"; recover its explicit source unit.
        $archive=get_option('ianlm_backup_'.$id,array());$source=maybe_unserialize($archive['meta']['_ian_product_data'][0]??array());
        if(is_array($source)&&str_contains(strtolower((string)($source['priceUnit']??'')),'square metre')&&'metre'===($old['unit']??'')){$old['unit']='square metre';}
        $groups=array('moq'=>'Minimum order','lead_time'=>'Production lead time','unit'=>'Pricing unit');
        foreach($groups as $key=>$name){if(!empty($old[$key])&&!$p->is_type('variation')){self::set_attribute($p,$name,$old[$key]);}}
        $extra=(array)($old['attributes']??array());
        if($p->is_type('variation')){
            if(!empty($old['model'])){$extra['Model']=$old['model'];$sku=$p->get_sku();if(!$sku||preg_match('/^IAN-[0-9]+-V[0-9]+$/',$sku)){$wanted=sanitize_text_field($old['model']);$used=wc_get_product_id_by_sku($wanted);if(!$used||$used===$id){$p->set_sku($wanted);}}}
            if($extra&&!str_contains($content,'ian-attributes')){$content.=self::group('attributes',self::pairs($extra));}
        }else{foreach($extra as $name=>$value){if(is_scalar($value)){self::set_attribute($p,$name,$value);}}}
        $pack=self::pairs($old['packaging']??array());if(!empty($old['packing_image'])){$aid=self::attachment($old['packing_image']);if(is_wp_error($aid)){return $aid;}$pack.=self::image($aid);}
        if($pack&&!str_contains($content,'ian-packing')){$content.=self::group('packing',$pack);}
        $custom='';foreach(preg_split('/\R/u',(string)($old['customisation']??'')) as $line){if(trim($line)){$custom.=self::paragraph(trim($line));}}
        if($custom&&!str_contains($content,'ian-customisation')){$content.=self::group('customisation',$custom);}
        if($p->is_type('variation')&&!empty($old['gallery'])&&!str_contains($content,'ian-model-gallery')){$gallery='';foreach((array)$old['gallery'] as $aid){$media=self::attachment($aid);if(is_wp_error($media)){return $media;}$gallery.=self::image($media);}if($gallery){$content.=self::group('model-gallery',$gallery);}}
        if(!$p->is_type('variation')){
            $attrs=$p->get_attributes();foreach($attrs as $key=>$attr){if(is_object($attr)&&in_array(strtolower($attr->get_name()),array('source reference price','reference price','series reference price'),true)){unset($attrs[$key]);}}$p->set_attributes($attrs);
        }
        // Keep confirmed native prices. Legacy quotation placeholders and zero are blank.
        if(!$p->is_type('variable')&&(''!==$p->get_regular_price('edit')&&(float)$p->get_regular_price('edit')<=0)){$p->set_regular_price('');$p->set_sale_price('');$p->set_price('');}
        $content=self::clean_content($content,$id);
        $rewritten=IanProject_Legacy_Source::content($content);if(is_wp_error($rewritten)){return $rewritten;}
        $p->set_description($rewritten);$p->save();
        foreach(array_keys(get_post_meta($id)) as $key){if(str_starts_with($key,'_ian4_')||'_ian_product_data'===$key){delete_post_meta($id,$key);}}
        foreach(get_posts(array('post_type'=>'product_variation','post_parent'=>$id,'post_status'=>'any','numberposts'=>-1,'fields'=>'ids')) as $vid){$r=self::normalize_product($vid);if(is_wp_error($r)){return $r;}}
        if($p->is_type('variable')){WC_Product_Variable::sync($id);}wc_delete_product_transients($id);
        return true;
    }
    private static function normalize_article( $id ) {
        $labels=array('region'=>'Region','location'=>'Location','project_type'=>'Project type','scope'=>'Products','materials'=>'Materials','insight_topic'=>'Topic');$pairs=array();
        foreach($labels as $key=>$label){$value=get_post_meta($id,'_ian_'.$key,true);if(is_scalar($value)&&''!==(string)$value){$pairs[$label]=$value;}}
        $content=get_post_field('post_content',$id);
        if($pairs&&!str_contains($content,'ian-project-information')){$content=self::group('project-information',self::pairs($pairs)).$content;}
        if(!empty($pairs['Region'])){wp_set_post_tags($id,array('Region: '.$pairs['Region']),true);}
        if(!empty($pairs['Topic'])){wp_set_post_tags($id,array($pairs['Topic']),true);}
        $r=wp_update_post(wp_slash(array('ID'=>$id,'post_content'=>self::clean_content($content,$id))),true);if(is_wp_error($r)){return $r;}
        foreach(array_keys($labels) as $key){delete_post_meta($id,'_ian_'.$key);}delete_post_meta($id,'_ian_v3_legacy_insight');return true;
    }
    public static function convert( $id ) {
        $id=absint($id);$post=get_post($id);if(!$post||!current_user_can('edit_post',$id)){return new WP_Error('ianlm_permission','资料不存在或没有编辑权限。');}
        if(function_exists('set_time_limit')){@set_time_limit(90);}
        self::save_backup($id);
        try{
            $is_old=in_array($post->post_type,array('ian_product','ian_insight'),true)||('product'===$post->post_type&&get_post_meta($id,'_ian_product_data',true)&&!get_post_meta($id,'_ian4_native',true));
            if($is_old){$r=IanProject_Legacy_Source::convert($id);if(is_wp_error($r)){throw new RuntimeException($r->get_error_message());}}
            $post=get_post($id);
            if('product'===$post->post_type){$r=self::normalize_product($id);}
            else{
                $featured=get_post_thumbnail_id($id);if($featured){$media=self::attachment($featured);if(is_wp_error($media)){throw new RuntimeException($media->get_error_message());}}
                $content=self::clean_content($post->post_content,$id);$content=IanProject_Legacy_Source::content($content,'post'===$post->post_type);
                $r=is_wp_error($content)?$content:wp_update_post(wp_slash(array('ID'=>$id,'post_content'=>$content)),true);
                if(!is_wp_error($r)&&'post'===$post->post_type){$r=self::normalize_article($id);}
            }
            if(is_wp_error($r)){throw new RuntimeException($r->get_error_message());}
            update_post_meta($id,'_ian5_native',self::VERSION);update_post_meta($id,'_ian5_migration_hash',self::fingerprint($id));
            return true;
        }catch(Throwable $e){$restore=self::restore($id,true);return new WP_Error('ianlm_conversion',$e->getMessage().(is_wp_error($restore)?'；自动恢复失败：'.$restore->get_error_message():'；本项已恢复。'));}
    }
    private static function restore_snapshot( $snapshot ) {
        $id=$snapshot['post']['ID'];
        foreach(get_posts(array('post_type'=>'product_variation','post_parent'=>$id,'post_status'=>'any','numberposts'=>-1,'fields'=>'ids')) as $vid){if(!isset($snapshot['children'][$vid])){wp_delete_post($vid,true);}}
        $r=wp_update_post(wp_slash($snapshot['post']),true);if(is_wp_error($r)){return $r;}
        foreach(array_keys(get_post_meta($id)) as $key){delete_post_meta($id,$key);}foreach($snapshot['meta'] as $key=>$values){foreach($values as $value){add_post_meta($id,$key,wp_slash(maybe_unserialize($value)));}}
        foreach(array_unique(array_merge(get_object_taxonomies(get_post_type($id)),array_keys($snapshot['terms']))) as $tax){if(taxonomy_exists($tax)){wp_set_object_terms($id,array_map('absint',$snapshot['terms'][$tax]??array()),$tax);}}
        foreach($snapshot['children'] as $child){$r=self::restore_snapshot($child);if(is_wp_error($r)){return $r;}}
        clean_post_cache($id);if(function_exists('wc_delete_product_transients')){wc_delete_product_transients($id);}return true;
    }
    public static function restore( $id, $failed = false ) {
        $key='ianlm5_backup_'.absint($id);$backup=get_option($key);
        if(!current_user_can('edit_post',$id)||!is_array($backup)||empty($backup['snapshot'])){return new WP_Error('ianlm_backup','没有可恢复的备份或权限。');}
        $expected=get_post_meta($id,'_ian5_migration_hash',true);
        if(!$failed&&$expected&&!hash_equals($expected,self::fingerprint($id))){return new WP_Error('ianlm_changed','转换后已有人工修改，已停止自动恢复。');}
        $r=self::restore_snapshot($backup['snapshot']);if(is_wp_error($r)){return $r;}$backup['restored']=true;update_option($key,$backup,false);return true;
    }
}
